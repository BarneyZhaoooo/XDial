module golang.org/x/text

go 1.25.0

require golang.org/x/tools v0.48.0 // tagx:ignore

require (
	golang.org/x/mod v0.38.0 // indirect; tagx:ignore
	golang.org/x/sync v0.22.0 // indirect
)
