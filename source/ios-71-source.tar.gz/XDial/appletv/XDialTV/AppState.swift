import Combine
import Foundation
import os.log
import SwiftUI

// MARK: - Engine / Tunnel abstraction (iOS / tvOS)
//
// macOS 版 AppState 直接依赖 `GoEngine.shared`（通过 UNIX socket 与特权 helper 通信）
// 和 `PrivilegeManager`（安装/校验 LaunchDaemon + helper）。iOS / tvOS 上没有特权进程概念，
// VPN 通过 NETunnelProviderManager / Packet Tunnel 扩展实现。
//
// 为了不和「引擎层」这个并行任务硬耦合，这里用两个最小协议做占位：
//   - `TunnelEngine`：AppState 实际用到的引擎表面（状态 + start/stop/syncStatus）。
//     并行任务写的具体引擎类型只要 conform 这个协议即可注入。
//   - `TunnelManaging`：替代 macOS 的 PrivilegeManager，语义是「VPN Profile 是否已安装并可用」。
//     等 NETunnelProviderManager 管理层实现后在这里对接真实状态查询。

/// AppState 用到的引擎最小表面。并行的引擎实现 conform 此协议后注入即可。
/// 注意：暴露 `objectWillChange` 让 AppState 能像 macOS 版那样订阅引擎状态变化。
struct TailscaleRuntimeExitNode: Decodable, Equatable, Hashable, Identifiable, Sendable {
    let id: String
    let name: String
    let ip: String
    let online: Bool
    let os: String?
}

struct TailscaleRuntimeStatus: Decodable, Equatable, Sendable {
    let backendState: String
    let authURL: String
    let exitNodes: [TailscaleRuntimeExitNode]

    enum CodingKeys: String, CodingKey {
        case backendState = "backend_state"
        case authURL = "auth_url"
        case exitNodes = "exit_nodes"
    }
}

struct TailscaleAuthRequest: Equatable, Identifiable, Sendable {
    let lineID: String
    let lineName: String

    var id: String { lineID }
}

@MainActor
protocol TailscaleSetupRuntime: AnyObject {
    var isActive: Bool { get }

    func start(
        profileJSON: String,
        lineID: String,
        completion: @escaping (Result<TailscaleRuntimeStatus, Error>) -> Void
    )
    func status(
        lineID: String,
        completion: @escaping (Result<TailscaleRuntimeStatus, Error>) -> Void
    )
    func beginLogin(
        lineID: String,
        completion: @escaping (Result<TailscaleRuntimeStatus, Error>) -> Void
    )
    func logout(
        lineID: String,
        completion: @escaping (Result<Void, Error>) -> Void
    )
    func stop(completion: @escaping () -> Void)
}

struct AnyConnectCredentials: Equatable, Sendable {
    let server: String
    let username: String
    let password: String
}

@MainActor
protocol TunnelEngine: AnyObject {
    var status: String { get }
    var lastError: String? { get set }
    var dataPathSummary: String? { get set }
    /// 自检没通过、连接保留期间正在补测。只有真实隧道会补测，其余实现恒为 false。
    var dataPathRechecking: Bool { get }
    var connectedAt: Date? { get }
    var isConnected: Bool { get }
    var isBusy: Bool { get }

    /// 引擎状态变化的发布器（等价于 ObservableObject.objectWillChange）。
    var objectWillChange: ObservableObjectPublisher { get }
    /// `objectWillChange` 在属性赋值前发送，不能用它读取新的状态；状态机必须订阅
    /// 这个赋值后的流，否则一次同步的 connected -> disconnected 会被合并丢失。
    var statusPublisher: AnyPublisher<String, Never> { get }
    var dataPathVerifiedPublisher: AnyPublisher<Void, Never> { get }

    func start(profileJSON: String)
    func stop()
    func syncStatus()
    func selectSubscriptionMember(
        profileJSON: String,
        subscriptionID: String,
        groupName: String,
        memberName: String,
        completion: @escaping (Result<Void, Error>) -> Void
    )
    func testSubscriptionNode(
        profileJSON: String,
        subscriptionID: String,
        nodeID: String,
        testURL: String,
        completion: @escaping (Result<Int, Error>) -> Void
    )
    func probeSubscriptionNodeAddress(
        profileJSON: String,
        subscriptionID: String,
        nodeID: String,
        completion: @escaping (Result<String, Error>) -> Void
    )
    func tailscaleStatus(
        endpointTag: String,
        completion: @escaping (Result<TailscaleRuntimeStatus, Error>) -> Void
    )
    func beginTailscaleLogin(
        endpointTag: String,
        completion: @escaping (Result<TailscaleRuntimeStatus, Error>) -> Void
    )
    func suppressNextAutomaticReconnect()
    func consumeAutomaticReconnectPermission() -> Bool
}

extension TunnelEngine {
    var dataPathVerifiedPublisher: AnyPublisher<Void, Never> { Empty().eraseToAnyPublisher() }
    var dataPathRechecking: Bool { false }
    var connectedAt: Date? { nil }
    var statusPublisher: AnyPublisher<String, Never> {
        Just(status).eraseToAnyPublisher()
    }

    func selectSubscriptionMember(
        profileJSON: String,
        subscriptionID: String,
        groupName: String,
        memberName: String,
        completion: @escaping (Result<Void, Error>) -> Void
    ) {
        completion(.failure(TunnelRuntimeError.unavailable))
    }

    func testSubscriptionNode(
        profileJSON: String,
        subscriptionID: String,
        nodeID: String,
        testURL: String,
        completion: @escaping (Result<Int, Error>) -> Void
    ) {
        completion(.failure(TunnelRuntimeError.unavailable))
    }

    func probeSubscriptionNodeAddress(
        profileJSON: String,
        subscriptionID: String,
        nodeID: String,
        completion: @escaping (Result<String, Error>) -> Void
    ) {
        completion(.failure(TunnelRuntimeError.unavailable))
    }

    func tailscaleStatus(
        endpointTag: String,
        completion: @escaping (Result<TailscaleRuntimeStatus, Error>) -> Void
    ) {
        completion(.failure(TunnelRuntimeError.unavailable))
    }

    func beginTailscaleLogin(
        endpointTag: String,
        completion: @escaping (Result<TailscaleRuntimeStatus, Error>) -> Void
    ) {
        completion(.failure(TunnelRuntimeError.unavailable))
    }

    func suppressNextAutomaticReconnect() {}
    func consumeAutomaticReconnectPermission() -> Bool { true }
}

enum TunnelRuntimeError: LocalizedError {
    case unavailable
    case invalidCatalog
    case invalidTailscaleStatus
    case missingTarget
    case requestFailed(String)

    var errorDescription: String? {
        switch self {
        case .unavailable:
            return "The connection runtime is unavailable."
        case .invalidCatalog:
            return "The runtime route catalog is invalid."
        case .invalidTailscaleStatus:
            return "The Tailscale runtime status is invalid."
        case .missingTarget:
            return "The selected runtime route is unavailable."
        case .requestFailed(let message):
            return message
        }
    }
}

/// 订阅解析结果。macOS 版是 `GoEngine.ParseResult`，这里抽成独立类型，
/// 引擎层解析订阅后回填给 `updateSubscription`。
struct ParseResult: Decodable {
    let lines: [Line]
    let proxyGroups: [SubProxyGroup]?
    let rules: [SubRule]?

    enum CodingKeys: String, CodingKey {
        case lines
        case proxyGroups = "proxy_groups"
        case rules
    }
}

/// 替代 macOS PrivilegeManager 的占位协议：查询 VPN Profile 是否已安装并可用，
/// 并负责真正把系统级 VPN 隧道拉起来/停下去。
/// TODO: 等 NETunnelProviderManager 管理层实现后，用真实的 NETunnelProviderManager
/// 状态查询实现此协议（是否已 saveToPreferences、是否 enabled 等）。
enum SystemOnDemandState: Equatable {
    case disabled
    case pending
    case active
    case failed(String)
}

extension TunnelManaging {
    func connectionTimelineSnapshot() async -> ConnectionTimeline.File? { nil }
    func recordUserAction(_ action: String) {}
}

@MainActor
protocol TunnelManaging: AnyObject {
    /// VPN Profile 是否已安装并可用（对应 macOS 的 helperInstalled 语义）。
    var isProfileInstalled: Bool { get }
    /// 系统当前是否已经接管意外断线重连；仅代表已落入系统偏好的实际状态。
    var systemOnDemandActive: Bool { get }
    var systemOnDemandState: SystemOnDemandState { get }
    var systemOnDemandStatePublisher: AnyPublisher<SystemOnDemandState, Never> { get }

    /// 从系统偏好重新读取 VPN Profile 状态。首次安装时尚未存在 Profile，
    /// 但这不妨碍用户点击连接；真正的 Profile 会在 startTunnel 里创建。
    func refreshProfileStatus(completion: @escaping @Sendable (Bool) -> Void)

    /// 把当前 profile 转成 NE 模式配置、连同 AnyConnect 凭据一起交给系统拉起隧道
    /// （NETunnelProviderManager.saveToPreferences + startVPNTunnel）。
    /// 这是唯一真正触发系统级连接的入口——`TunnelEngine.start(profileJSON:)`
    /// 走的是 sendProviderMessage，只有隧道已经在跑时才有意义，不能从冷启动拉起隧道。
    func startTunnel(profile: Profile, anyConnect: AnyConnectCredentials?,
                      allowSystemOnDemand: Bool,
                      origin: ConnectionTimeline.StartOrigin,
                      completion: @escaping @Sendable (Result<Void, Error>) -> Void)
    /// 保存用户的系统级重连意图。启用请求只会在连接验收通过且安全启动包可用后生效。
    func setSystemOnDemandEnabled(_ enabled: Bool)
    /// Tailscale 独立设置期间临时暂停系统接管。与用户开关不同，这个租约必须保留
    /// 已验收的安全启动包，并在系统偏好确认停用后才回调。
    func setSystemOnDemandSuspendedForSetup(
        _ suspended: Bool,
        completion: @escaping () -> Void
    )

    /// 停止系统级隧道（NETunnelProviderManager.connection.stopVPNTunnel()）。
    func stopTunnel()
    func removeProfile(completion: @escaping @Sendable (Result<Void, Error>) -> Void)

    /// 扩展内全线路累计上下行字节数；隧道未运行或不可读时返回 nil。
    func trafficTotals() async -> TrafficTotals?

    /// 经 Direct 线路查到的网络出口地区（两位代码）。只在隧道运行时有意义：
    /// 连着时 App 自己的请求按场景分流、域名解析也归隧道，查不到本地网络的出口。
    func directExitCountry() async -> ExitCountryProbeResult

    /// 连接保留但自检没通过时，立即从头再测一次；其余状态下什么也不做。
    func recheckDataPath()

    /// Bounded, redacted connection timeline shared with the tunnel extension.
    func connectionTimelineSnapshot() async -> ConnectionTimeline.File?
    /// Records a user action (for example an explicit disconnect) on the current session.
    func recordUserAction(_ action: String)

    #if os(iOS)
    /// 为可能被选中的场景生成启动包，连同判断规则写进场景目录；返回目录修订号。
    /// keepingOthers：只替换 inputs 里的场景，目录里其他场景保留。
    func rebuildScenarioCatalog(
        inputs: [ScenarioCatalogInput],
        policy: ScenarioAutoPolicy,
        keepingOthers: Bool
    ) async -> String?
    /// 只更新场景目录里的判断规则（例如关掉「自动」）。目录不存在时返回 false。
    func updateScenarioCatalogPolicy(_ policy: ScenarioAutoPolicy) -> Bool
    /// 请 VPN 扩展在不断开系统 VPN 的情况下切换到目录里的场景。
    func requestScenarioSwitch(to scenarioID: String, revision: String, reapply: Bool) async -> ScenarioSwitchReply
    /// 请 VPN 扩展按当前网络判断一次（必要时自动切换），返回扩展的场景状态。
    func requestScenarioEvaluation() async -> ScenarioEvaluationReply
    /// 向正在运行的 VPN 扩展读取场景状态；扩展不可用或是旧版本时返回 nil。
    func requestScenarioState() async -> TunnelScenarioState?
    /// 扩展换了场景以后，改用新场景的验收计划并重新检测数据路径。
    func adoptSwitchedScenario(_ scenarioID: String)
    #endif
}

/// 一次出口地区查询的结果；查到时 code 非空，否则 failure 说明原因。
struct ExitCountryProbeResult: Equatable, Sendable {
    let code: String?
    let failure: String?
    /// Which service answered and what failed first; diagnostics only.
    var endpoint: String? = nil
    var attempts: String? = nil
    var ms: Int? = nil
}

extension TunnelManaging {
    var systemOnDemandActive: Bool { false }
    var systemOnDemandState: SystemOnDemandState { .disabled }
    var systemOnDemandStatePublisher: AnyPublisher<SystemOnDemandState, Never> {
        Just(systemOnDemandState).eraseToAnyPublisher()
    }

    func setSystemOnDemandEnabled(_ enabled: Bool) {}
    func recheckDataPath() {}
    func setSystemOnDemandSuspendedForSetup(
        _ suspended: Bool,
        completion: @escaping () -> Void
    ) {
        completion()
    }

    func removeProfile(completion: @escaping @Sendable (Result<Void, Error>) -> Void) {
        completion(.failure(TunnelRuntimeError.unavailable))
    }

    func trafficTotals() async -> TrafficTotals? { nil }
    func directExitCountry() async -> ExitCountryProbeResult {
        ExitCountryProbeResult(code: nil, failure: "VPN 扩展不可用")
    }

    #if os(iOS)
    func rebuildScenarioCatalog(
        inputs: [ScenarioCatalogInput],
        policy: ScenarioAutoPolicy,
        keepingOthers: Bool
    ) async -> String? { nil }
    func updateScenarioCatalogPolicy(_ policy: ScenarioAutoPolicy) -> Bool { false }
    func requestScenarioSwitch(to scenarioID: String, revision: String, reapply: Bool) async -> ScenarioSwitchReply { .unsupported }
    func requestScenarioEvaluation() async -> ScenarioEvaluationReply { .unsupported }
    func requestScenarioState() async -> TunnelScenarioState? { nil }
    func adoptSwitchedScenario(_ scenarioID: String) {}
    #endif
}

#if os(iOS)
/// 场景目录里一个场景的生成输入。profileJSON 是把该场景设为当前场景后的运行配置。
struct ScenarioCatalogInput: Sendable {
    let scenarioID: String
    let scenarioName: String
    let profileJSON: String
    let anyConnect: AnyConnectCredentials?
    let allowInsecure: Bool
    let acceptancePlanJSON: String
}

/// VPN 扩展对一次判断请求的答复。
enum ScenarioEvaluationReply: Sendable, Equatable {
    case evaluated(TunnelScenarioState)
    /// 扩展是旧版本，不认识这条命令。
    case unsupported
    /// 扩展没有及时回应或暂时不可用。
    case unavailable
}

/// VPN 扩展对一次场景切换请求的答复。
enum ScenarioSwitchReply: Sendable, Equatable {
    case switched(TunnelScenarioState)
    case failed(String, TunnelScenarioState?)
    /// 扩展是旧版本，不认识这条命令。
    case unsupported
}
#endif

private let appOSLog = OSLog(subsystem: "com.kafeifei.xdial.mobile", category: "app")

func appLog(_ msg: String) {
    os_log("%{public}@", log: appOSLog, type: .info, msg)
    #if DEBUG
    print("[xdial] \(msg)")
    #endif
}

/// 内部协议或系统错误偶尔会带出旧技术名。产品界面统一使用 AnyConnect；
/// iOS 自己的授权弹窗由系统生成，不经过这个显示层。
func userFacingConnectionText(_ value: String) -> String {
    value.replacingOccurrences(of: "VPN", with: "AnyConnect", options: [.caseInsensitive])
}

// 全角 ASCII → 半角。macOS 版定义在 ASCIIField.swift（含 SwiftUI 视图），
// tvOS 这里只需要纯字符串归一化逻辑，独立复制一份，语义完全一致。
extension String {
    /// 把全角 ASCII（U+FF01-U+FF5E）转半角，全角空格转半角空格。
    /// 用于密码、URL、服务器地址等只允许 ASCII 的字段。
    func normalizedASCII() -> String {
        var out = ""
        out.reserveCapacity(self.unicodeScalars.count)
        for ch in self.unicodeScalars {
            let v = ch.value
            if v >= 0xFF01 && v <= 0xFF5E {
                if let s = Unicode.Scalar(v - 0xFEE0) {
                    out.append(Character(s))
                }
            } else if v == 0x3000 {
                out.append(" ")
            } else {
                out.unicodeScalars.append(ch)
            }
        }
        return out
    }
}

@MainActor
struct AppPersistenceContext {
    let defaults: UserDefaults
    let defaultsSuiteName: String?
    let keychain: KeychainStore.Context
    let profileKey: String
    let languageKey: String
    let autoReconnectKey: String
    let systemOnDemandKey: String
    let tailscaleSetupLineKey: String
    /// 已经应用到哪一版预置配置；用来在升级后给老配置补一次新内容。
    var seedRevisionKey: String { "xdial.preset-scenario-version" }
    /// 「打开 XDial 后自动连接」，默认关闭。
    var connectOnOpenKey: String { "xdial.connect-on-open" }
    /// 用户已确认的「数据使用说明」版本。说明内容有实质变化时把 AppState.dataUseNoticeVersion 加一。
    var dataUseNoticeKey: String { "xdial.data-use-notice-version" }

    static let production = AppPersistenceContext(
        defaults: .standard,
        defaultsSuiteName: nil,
        keychain: .production,
        profileKey: "xdial.profile",
        languageKey: "xdial.language",
        autoReconnectKey: "xdial.auto-reconnect",
        systemOnDemandKey: "xdial.system-on-demand",
        tailscaleSetupLineKey: "xdial.tailscale-setup-line"
    )

    static func testing(identifier: String) -> AppPersistenceContext {
        let safeIdentifier = identifier.replacingOccurrences(
            of: "[^A-Za-z0-9._-]",
            with: "-",
            options: .regularExpression
        )
        let suiteName = "com.kafeifei.xdial.tests.\(safeIdentifier)"
        return AppPersistenceContext(
            defaults: UserDefaults(suiteName: suiteName)!,
            defaultsSuiteName: suiteName,
            keychain: .testing(identifier: safeIdentifier),
            profileKey: "xdial.profile",
            languageKey: "xdial.language",
            autoReconnectKey: "xdial.auto-reconnect",
            systemOnDemandKey: "xdial.system-on-demand",
            tailscaleSetupLineKey: "xdial.tailscale-setup-line"
        )
    }

    static let uiTesting = testing(identifier: "ui")

    /// 只允许清理显式测试 namespace，生产 context 永不响应这个入口。
    @discardableResult
    func clearForTesting() -> Bool {
        guard let defaultsSuiteName else { return false }
        defaults.removePersistentDomain(forName: defaultsSuiteName)
        return KeychainStore.clear(context: keychain)
    }
}

struct ProfilePersistenceEnvelope: Codable {
    static let currentFormat = "xdial-profile"
    static let currentSchemaVersion = 1

    let format: String
    let schemaVersion: Int
    let revision: String
    let profile: Profile

    init(revision: String, profile: Profile) {
        format = Self.currentFormat
        schemaVersion = Self.currentSchemaVersion
        self.revision = revision
        self.profile = profile
    }

    enum CodingKeys: String, CodingKey {
        case format
        case schemaVersion = "schema_version"
        case revision
        case profile
    }

    var isValid: Bool {
        format == Self.currentFormat
            && schemaVersion == Self.currentSchemaVersion
            && !revision.isEmpty
    }
}

@MainActor
final class AppState: ObservableObject {
    @Published var profile: Profile

    /// VPN Profile 是否已安装并可用（对应 macOS 的 helperInstalled）。
    /// 由 tunnelManager.refreshProfileStatus() 刷新为真实系统状态。
    @Published var helperInstalled: Bool = false

    @Published var language: Lang {
        didSet {
            persistence.defaults.set(language.rawValue, forKey: persistence.languageKey)
            #if os(iOS)
            if persistence.defaultsSuiteName == nil {
                ConnectionNotice.preferences.set(language.rawValue, forKey: "xdial.language")
            }
            #endif
        }
    }

    @Published var autoReconnectEnabled: Bool {
        didSet {
            persistence.defaults.set(autoReconnectEnabled, forKey: persistence.autoReconnectKey)
            if !autoReconnectEnabled {
                autoReconnectTask?.cancel()
                autoReconnectTask = nil
            }
        }
    }

    /// 「打开 XDial 后自动连接」。只决定启动后是否发起一次普通连接，不接管系统层的按需连接。
    /// 当前的「数据使用说明」版本。App Store 审核指南 5.4 要求 VPN App 在用户使用服务前
    /// 说明收集哪些数据、如何使用；用户确认之前不发起连接，也不做需要联网的自动判断。
    static let dataUseNoticeVersion = 1
    @Published private(set) var dataUseNoticeAccepted: Bool

    func acceptDataUseNotice() {
        persistence.defaults.set(Self.dataUseNoticeVersion, forKey: persistence.dataUseNoticeKey)
        dataUseNoticeAccepted = true
    }

    @Published var connectOnOpenEnabled: Bool {
        didSet {
            persistence.defaults.set(connectOnOpenEnabled, forKey: persistence.connectOnOpenKey)
            if !connectOnOpenEnabled { openConnectPending = false }
        }
    }
    /// 本次启动还没处理过「打开后自动连接」。每次启动只用一次；用户先点了连接或断开就作废，
    /// 之后切换前后台、重新渲染首页都不会再发起连接。
    private var openConnectPending = false

    @Published var systemOnDemandEnabled: Bool {
        didSet {
            persistence.defaults.set(systemOnDemandEnabled, forKey: persistence.systemOnDemandKey)
            // 该开关决定系统在主 App 不运行时是否接管连接。切换后可能马上被系统
            // 挂起或终止，必须在调用系统配置前把用户意图同步落盘。
            persistence.defaults.synchronize()
            tunnelManager?.setSystemOnDemandEnabled(systemOnDemandEnabled)
        }
    }
    @Published private(set) var systemOnDemandState: SystemOnDemandState = .disabled

    /// 引擎引用。默认注入一个空实现（NoopEngine），等并行的引擎层实现好后
    /// 通过 init(engine:) 或后续绑定替换成真实引擎。
    let engine: TunnelEngine
    private var engineSub: AnyCancellable?
    private var verificationSub: AnyCancellable?
    private var engineStatusSub: AnyCancellable?

    /// 系统连接管理层必须与 AppState 同生命周期；其反向 engine 引用是 weak，不成环。
    private let tunnelManager: TunnelManaging?
    /// Tailscale 登录和节点发现运行在主 App 内，不启动系统线路。
    private let tailscaleSetupRuntime: TailscaleSetupRuntime?
    private var onDemandStateSub: AnyCancellable?

    private let persistence: AppPersistenceContext
    /// 打包时带进来的预置配置；没有时为空。「恢复默认」也回到它。
    let seed: ProfileSeed?
    /// 「恢复默认配置」用的那份：有预置用预置，没有用空白起步配置。
    var defaultProfile: Profile { seed?.profile ?? Profile.bootstrap() }
    /// 包里带着企业预置（内部分发）。公开版不带预置，界面不能假定用户有公司账号或公司默认配置。
    var hasCompanyPreset: Bool { seed != nil }
    private let keychainPrefix = "xdial-line-"
    private let subKeychainPrefix = "xdial-sub-"
    private var persistedRevision: String?
    private var persistedVault: [String: String] = [:]
    private var quarantinedLegacyValues: [String: String] = [:]
    @Published private(set) var persistenceRequiresRecovery = false
    @Published private(set) var hasPendingRuntimeChanges = false
    /// 所有编辑入口最终都调用 save()，但不少 SwiftUI 回调无法同步展示返回值。
    /// 保留最后一次确认落盘的完整配置；任何持久化失败都统一回滚，避免 UI 看似保存、
    /// 重启后才发现账号或场景消失。
    private var lastPersistedProfile = Profile.bootstrap()
    private var runningProfileSnapshot: Profile?
    @Published private(set) var tailscaleSetupLineID: String?
    /// 切到后台时为释放状态锁停下、回到前台要接着做的独立 Tailscale 设置线路。
    private var backgroundPausedTailscaleSetupLineID: String?
    /// 回到前台后重新跑起来的设置线路；配置页据此接着读登录状态，必要时再打开登录页。
    @Published private(set) var resumedTailscaleSetupLineID: String?
    @Published private(set) var isStoppingTailscaleSetup = false
    @Published private var runtimeTailscaleNeedsLoginIDs: Set<String> = []
    private var tailscaleSetupGeneration: UInt64 = 0
    private var tailscaleAuthRefreshGeneration: UInt64 = 0
    private var tailscaleSetupOwnsOnDemandSuspension = false
    private var tailscaleSetupSuspensionPending = false
    private var tailscaleSetupFinishCompletions: [() -> Void] = []
    private var reconnectAfterDisconnect = false
    private var observedEngineStatus = "disconnected"
    private var disconnectRequested = false
    private var autoReconnectAttempt = 0
    private var autoReconnectTask: Task<Void, Never>?
    private var interruptedTailscaleSetupRecoveryPending = false

    #if os(iOS)
    /// iOS 主屏提供的自动选场景规则（「自动」开关、各场景登记的 Wi-Fi、打包注入的地区表）。
    var scenarioAutoPolicyProvider: (@MainActor (Profile) -> ScenarioAutoPolicy)?
    /// 正在运行的 VPN 扩展报告的场景状态（判断经过、建议、最近一次切换）。
    @Published private(set) var tunnelScenarioState: TunnelScenarioState?
    @Published private(set) var isSwitchingScenarioInTunnel = false
    private var scenarioCatalogTask: Task<Void, Never>?
    #endif

    func tr(_ zh: String, _ en: String) -> String {
        language == .zh ? zh : en
    }

    var isConnected: Bool { engine.isConnected }
    var requiresUserAction: Bool { engine.status == "action-required" }
    var hasFormalTunnel: Bool { isConnected || requiresUserAction }

    /// 首页速率采样入口。只在已连接时向扩展发请求，避免唤醒未运行的隧道。
    func trafficTotals() async -> TrafficTotals? {
        guard isConnected, let tunnelManager else { return nil }
        return await tunnelManager.trafficTotals()
    }

    /// 首页「重新检测」：自检没通过但连接保留时，马上再测一次。
    func recheckConnection() {
        guard isConnected else { return }
        tunnelManager?.recheckDataPath()
    }

    /// 已连接时经 Direct 线路查网络出口地区；没连着时不唤醒隧道。
    /// Connection timeline for the diagnostics report; nil without a tunnel manager.
    func connectionTimelineSnapshot() async -> ConnectionTimeline.File? {
        await tunnelManager?.connectionTimelineSnapshot()
    }

    func directExitCountry() async -> ExitCountryProbeResult {
        guard dataUseNoticeAccepted else {
            return ExitCountryProbeResult(code: nil, failure: "未确认数据使用说明")
        }
        guard isConnected, let tunnelManager else {
            return ExitCountryProbeResult(code: nil, failure: "未连接")
        }
        return await tunnelManager.directExitCountry()
    }
    var isTailscaleSetupActive: Bool {
        tailscaleSetupLineID != nil && tailscaleSetupRuntime?.isActive == true
    }
    var tailscaleAuthRequests: [TailscaleAuthRequest] {
        guard requiresUserAction else { return [] }
        return (runningProfileSnapshot?.lines ?? profile.lines).compactMap { line in
            guard runtimeTailscaleNeedsLoginIDs.contains(line.id) else { return nil }
            return TailscaleAuthRequest(
                lineID: line.id,
                lineName: line.name.isEmpty ? "Tailscale" : line.name
            )
        }
    }
    var hasActiveTunnel: Bool { hasFormalTunnel || tailscaleSetupLineID != nil }
    var isBusy: Bool { engine.isBusy }
    var canMutateConfiguration: Bool { !isBusy && !hasActiveTunnel }

    var isConnectionConfigured: Bool {
        guard !persistenceRequiresRecovery else { return false }
        guard tunnelManager != nil else { return false }
        guard activeScenario != nil else { return false }
        return activeConfigurationIssues.isEmpty
    }

    var canConnect: Bool {
        !isBusy && !hasActiveTunnel && isConnectionConfigured
    }

    /// 当前数据面只有一个 AnyConnect bridge；一个场景可以多处引用同一线路，
    /// 但不能同时引用不同的 AnyConnect 线路，否则所有 tag 会被折叠到错误凭据上。
    var activeAnyConnectLineIDs: Set<String> {
        guard let scenario = activeScenario else { return [] }
        let referenced = effectiveReferencedLineIDs(in: scenario)
        return Set(profile.lines.compactMap { line in
            guard referenced.contains(line.id), line.enabled, line.type == "vpn" else { return nil }
            return line.id
        })
    }

    /// 当前场景实际引用且已启用的 Tailscale 线路，用于识别 Tailscale-only 启动。
    var activeTailscaleLineIDs: Set<String> {
        guard let scenario = activeScenario else { return [] }
        let referenced = effectiveReferencedLineIDs(in: scenario)
        return Set(profile.lines.compactMap { line in
            guard referenced.contains(line.id), line.enabled, line.type == "tailscale" else { return nil }
            return line.id
        })
    }

    /// 当前场景不能安全启动的原因。生成器会跳过无效目标并回落到 direct，移动端必须
    /// 在启动前拦住这些配置，避免 UI 显示成功而真实流量走了意外出口。
    var activeConfigurationIssues: [String] {
        if persistenceRequiresRecovery {
            return [persistenceRecoveryMessage]
        }
        guard let scenario = activeScenario else {
            return [tr("尚未选择场景", "No scenario is selected")]
        }
        return configurationIssues(for: scenario)
    }

    func configurationIssues(for scenario: Scenario) -> [String] {
        var issues: [String] = []
        appendConnectivityAcceptanceIssues(for: scenario, to: &issues)
        appendTargetIssue(
            lineID: scenario.defaultLineID,
            subscriptionID: scenario.defaultSubscriptionID,
            label: tr("默认出口", "Default route"),
            requiresPublicEgress: true,
            to: &issues
        )

        for binding in scenario.bindings {
            guard let rule = profile.ruleSets.first(where: { $0.id == binding.ruleSetID }) else {
                issues.append(tr("场景引用了已删除的规则", "The scenario references a deleted rule"))
                continue
            }
            guard rule.enabled else { continue }
            if rule.type == "url" && rule.url.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                issues.append(tr("规则“\(rule.name)”缺少地址", "Rule “\(rule.name)” has no address"))
                continue
            }
            if rule.type == "url" && !isHTTPSRemoteAddress(rule.url) {
                issues.append(tr("规则“\(rule.name)”必须使用 HTTPS 地址", "Rule “\(rule.name)” must use an HTTPS address"))
                continue
            }
            if rule.type == "url" && !["", "auto", "srs", "json", "text"].contains(rule.format) {
                issues.append(tr("规则“\(rule.name)”格式不受支持", "Rule “\(rule.name)” uses an unsupported format"))
                continue
            }
            appendTargetIssue(
                lineID: binding.lineID,
                subscriptionID: binding.subscriptionID,
                label: tr("规则“\(rule.name)”", "Rule “\(rule.name)”"),
                to: &issues
            )
        }

        let referencedLineIDs = effectiveReferencedLineIDs(in: scenario)
        // Tailscale endpoint 的子网路由能力是全局生成的，即使当前场景没有显式
        // 绑定也会随隧道启动。所有 enabled Tailscale 因而都必须先完成登录；
        // 出口节点仍只对承担默认公网出口的那一条强制要求。
        for line in profile.lines
        where line.enabled
            && line.type == "tailscale"
            && !referencedLineIDs.contains(line.id) {
            let lineIssues = routeLineConfigurationIssues(line)
            if !lineIssues.isEmpty {
                let trimmedName = line.name.trimmingCharacters(in: .whitespacesAndNewlines)
                let displayName = trimmedName.isEmpty ? line.id : trimmedName
                issues.append(tr(
                    "全局启用的 Tailscale 线路“\(displayName)”配置不完整：\(lineIssues.joined(separator: "、"))",
                    "Globally enabled Tailscale line “\(displayName)” is incomplete: \(lineIssues.joined(separator: ", "))"
                ))
            }
        }
        let anyConnectLineIDs = Set(profile.lines.compactMap { line -> String? in
            guard referencedLineIDs.contains(line.id),
                  line.enabled,
                  line.type == "vpn" else { return nil }
            return line.id
        })
        if anyConnectLineIDs.count > 1 {
            issues.append(tr(
                "当前场景一次只能使用一条 AnyConnect 线路",
                "This scenario can use only one AnyConnect line at a time"
            ))
        }
        var seen = Set<String>()
        return issues.filter { seen.insert($0).inserted }
    }

    private func appendConnectivityAcceptanceIssues(for scenario: Scenario, to issues: inout [String]) {
        let directRuleIsExact = profile.ruleSets.contains {
            $0.id == RuleSet.connectivityDirectID && $0.enabled && $0.type == "manual"
                && $0.domains.isEmpty && $0.cidrs == ["1.0.0.1/32"]
        }
        let outboundRuleIsExact = profile.ruleSets.contains {
            $0.id == RuleSet.connectivityOutboundID && $0.enabled && $0.type == "manual"
                && $0.domains.isEmpty && $0.cidrs == ["1.1.1.1/32"]
        }
        let directBindingIsValid = scenario.bindings.contains { binding in
            guard binding.ruleSetID == RuleSet.connectivityDirectID,
                  binding.subscriptionID.isEmpty else { return false }
            return profile.lines.contains {
                $0.id == binding.lineID && $0.type == "direct" && $0.enabled
            }
        }
        let expectedOutboundBinding = profile.connectivityOutboundBinding(for: scenario)
        let configuredOutboundBinding = scenario.bindings.first {
            $0.ruleSetID == RuleSet.connectivityOutboundID
        }
        let outboundBindingIsValid =
            expectedOutboundBinding?.lineID == configuredOutboundBinding?.lineID
            && expectedOutboundBinding?.subscriptionID == configuredOutboundBinding?.subscriptionID
        guard directRuleIsExact, outboundRuleIsExact,
              directBindingIsValid, outboundBindingIsValid else {
            issues.append(tr(
                "当前场景缺少完整的 Direct / 非 Direct 出口连接验收规则与绑定",
                "This scenario is missing the complete Direct / non-Direct acceptance rules and bindings"
            ))
            return
        }
    }

    private func isHTTPSRemoteAddress(_ rawValue: String) -> Bool {
        guard let components = URLComponents(string: rawValue),
              components.scheme?.lowercased() == "https",
              let host = components.host?.lowercased(), !host.isEmpty else { return false }
        return host != "localhost" && !host.hasSuffix(".localhost") && !host.hasSuffix(".local")
    }

    private func effectiveReferencedLineIDs(in scenario: Scenario) -> Set<String> {
        var ids = Set<String>()
        if !scenario.defaultLineID.isEmpty { ids.insert(scenario.defaultLineID) }
        for binding in scenario.bindings {
            guard !binding.lineID.isEmpty,
                  profile.ruleSets.first(where: { $0.id == binding.ruleSetID })?.enabled == true else { continue }
            ids.insert(binding.lineID)
        }
        return ids
    }

    /// 当前场景用到、但还没填完的线路，首页据此用一句话告诉用户去哪儿补什么。
    var incompleteActiveLineSummaries: [String] {
        guard !persistenceRequiresRecovery, let scenario = activeScenario else { return [] }
        let ids = effectiveReferencedLineIDs(in: scenario)
        return profile.lines.compactMap { line in
            guard ids.contains(line.id) else { return nil }
            let issues = routeLineConfigurationIssues(line)
            guard !issues.isEmpty else { return nil }
            let name = line.name.trimmingCharacters(in: .whitespacesAndNewlines)
            return tr(
                "「\(name.isEmpty ? line.id : name)」\(issues.joined(separator: "、"))",
                "“\(name.isEmpty ? line.id : name)”: \(issues.joined(separator: ", "))"
            )
        }
    }

    func routeLineConfigurationIssues(_ line: Line) -> [String] {
        guard line.enabled else {
            return [tr("线路已停用", "line is disabled")]
        }
        var issues: [String] = []
        if line.name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            issues.append(tr("缺少名称", "name is missing"))
        }
        switch line.type {
        case "direct":
            break
        case "vpn":
            if line.vpnServer.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                issues.append(tr("缺少服务器", "server is missing"))
            }
            if line.vpnUsername.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                issues.append(tr("缺少用户名", "username is missing"))
            }
            if line.vpnPassword.isEmpty {
                issues.append(tr("缺少密码", "password is missing"))
            }
        case "trojan":
            if line.trojanServer.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                issues.append(tr("缺少服务器", "server is missing"))
            }
            if !(1...65_535).contains(line.trojanPort) {
                issues.append(tr("端口无效", "port is invalid"))
            }
            if line.trojanPassword.isEmpty {
                issues.append(tr("缺少密码", "password is missing"))
            }
        case "shadowsocks", "ss":
            if line.ssServer.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                issues.append(tr("缺少服务器", "server is missing"))
            }
            if !(1...65_535).contains(line.ssPort) {
                issues.append(tr("端口无效", "port is invalid"))
            }
            if line.ssMethod.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                issues.append(tr("缺少加密方法", "method is missing"))
            }
            if line.ssPassword.isEmpty {
                issues.append(tr("缺少密码", "password is missing"))
            }
        case "vmess":
            if line.vmessServer.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                issues.append(tr("缺少服务器", "server is missing"))
            }
            if !(1...65_535).contains(line.vmessPort) {
                issues.append(tr("端口无效", "port is invalid"))
            }
            if UUID(uuidString: line.vmessUUID) == nil {
                issues.append(tr("UUID 无效", "UUID is invalid"))
            }
        case "tailscale":
            if !line.tailscaleAuthenticated {
                issues.append(tr(
                    "尚未完成 Tailscale 登录",
                    "Tailscale sign-in is not complete"
                ))
            }
        default:
            issues.append(tr("线路类型不受支持", "line type is unsupported"))
        }
        return issues
    }

    func isUsableRouteLine(_ line: Line) -> Bool {
        routeLineConfigurationIssues(line).isEmpty
    }

    func isUsableDefaultRouteLine(_ line: Line) -> Bool {
        guard isUsableRouteLine(line) else { return false }
        return line.type != "tailscale"
            || !line.tailscaleExitNode.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
    }

    func isUsableSubscription(_ subscription: Subscription) -> Bool {
        guard subscription.enabled else { return false }
        guard ["selector", "urltest", "url-test"].contains(subscription.strategy.lowercased()) else {
            return false
        }
        let lineNames = subscription.lines.map(\.name)
        guard lineNames.allSatisfy({ !$0.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty }),
              Set(lineNames).count == lineNames.count else { return false }
        let usableLineNames = Set(subscription.lines.compactMap { line -> String? in
            guard ["trojan", "shadowsocks", "vmess"].contains(line.type),
                  isUsableRouteLine(line) else { return nil }
            return line.name
        })
        guard !usableLineNames.isEmpty else { return false }
        let supportedRuleTypes = Set([
            "DOMAIN-SUFFIX", "DOMAIN", "DOMAIN-KEYWORD", "IP-CIDR", "IP-CIDR6", "GEOIP", "FINAL",
        ])
        guard subscription.rules.allSatisfy({ supportedRuleTypes.contains($0.type.uppercased()) }) else {
            return false
        }
        guard !subscription.proxyGroups.isEmpty else { return subscription.rules.isEmpty }

        let groupNames = subscription.proxyGroups.map(\.name)
        guard groupNames.allSatisfy({ !$0.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty }),
              Set(groupNames).count == groupNames.count,
              subscription.proxyGroups.allSatisfy({
                  ["select", "selector", "url-test", "urltest"].contains($0.type.lowercased())
              }) else { return false }

        var availableMembers = usableLineNames.union(["DIRECT", "Direct"])
        var outboundGroups = Set<String>()
        var rejectGroups = Set<String>()
        var changed = true
        while changed {
            changed = false
            for group in subscription.proxyGroups
            where !outboundGroups.contains(group.name) && !rejectGroups.contains(group.name) {
                let hasUsableMember = group.proxies.contains {
                    availableMembers.contains($0) || outboundGroups.contains($0)
                }
                if hasUsableMember {
                    outboundGroups.insert(group.name)
                    availableMembers.insert(group.name)
                    changed = true
                } else if group.proxies.contains(where: {
                    ["REJECT", "REJECT-DROP", "REJECT-TINYGIF", "BLOCK"].contains($0.uppercased())
                        || rejectGroups.contains($0)
                }) {
                    rejectGroups.insert(group.name)
                    changed = true
                }
            }
        }
        guard !outboundGroups.isEmpty else { return false }
        return subscription.rules.allSatisfy { rule in
            let target = rule.group
            return outboundGroups.contains(target) || rejectGroups.contains(target)
                || target.uppercased() == "DIRECT"
                || ["REJECT", "REJECT-DROP", "REJECT-TINYGIF", "BLOCK"].contains(target.uppercased())
        }
    }

    /// 订阅整体“有可用节点”并不代表用户当前选择可用。若已选择的节点配置
    /// 不完整，生成器会省略它并回退到其他节点；连接前必须明确拦截这种静默换线。
    private func subscriptionSelectionConfigurationIssues(
        _ subscription: Subscription
    ) -> [String] {
        let supportedLineTypes = Set(["trojan", "shadowsocks", "vmess"])
        let nodeByName = Dictionary(
            subscription.lines.map { ($0.name, $0) },
            uniquingKeysWith: { first, _ in first }
        )
        let usableNodeNames = Set(subscription.lines.compactMap { line -> String? in
            guard supportedLineTypes.contains(line.type),
                  isUsableRouteLine(line) else { return nil }
            return line.name
        })

        var availableMembers = usableNodeNames.union(["DIRECT", "Direct"])
        var outboundGroups = Set<String>()
        var rejectGroups = Set<String>()
        var changed = true
        while changed {
            changed = false
            for group in subscription.proxyGroups
            where !outboundGroups.contains(group.name) && !rejectGroups.contains(group.name) {
                let hasUsableMember = group.proxies.contains {
                    availableMembers.contains($0) || outboundGroups.contains($0)
                }
                if hasUsableMember {
                    outboundGroups.insert(group.name)
                    availableMembers.insert(group.name)
                    changed = true
                } else if group.proxies.contains(where: {
                    ["REJECT", "REJECT-DROP", "REJECT-TINYGIF", "BLOCK"].contains($0.uppercased())
                        || rejectGroups.contains($0)
                }) {
                    rejectGroups.insert(group.name)
                    changed = true
                }
            }
        }

        var issues: [String] = []
        func appendSelectionIssue(_ selected: String, context: String) {
            let selected = selected.trimmingCharacters(in: .whitespacesAndNewlines)
            guard !selected.isEmpty else { return }
            if let node = nodeByName[selected] {
                let nodeIssues = routeLineConfigurationIssues(node)
                if !nodeIssues.isEmpty {
                    let nodeName = node.name.trimmingCharacters(in: .whitespacesAndNewlines)
                    let displayName = nodeName.isEmpty ? node.id : nodeName
                    issues.append(tr(
                        "\(context)选择的节点“\(displayName)”配置不完整：\(nodeIssues.joined(separator: "、"))",
                        "Node “\(displayName)” selected by \(context) is incomplete: \(nodeIssues.joined(separator: ", "))"
                    ))
                }
                return
            }
            if ["DIRECT", "Direct"].contains(selected) || outboundGroups.contains(selected) {
                return
            }
            issues.append(tr(
                "\(context)选择的目标“\(selected)”不可用",
                "Target “\(selected)” selected by \(context) is unavailable"
            ))
        }

        if subscription.proxyGroups.isEmpty,
           subscription.strategy.lowercased() == "selector" {
            appendSelectionIssue(
                subscription.selected,
                context: tr("订阅", "the subscription")
            )
        }
        for group in subscription.proxyGroups
        where ["select", "selector"].contains(group.type.lowercased()) {
            let selected = group.selected.trimmingCharacters(in: .whitespacesAndNewlines)
            guard !selected.isEmpty else { continue }
            if !group.proxies.contains(selected) {
                issues.append(tr(
                    "策略组“\(group.name)”选择的目标“\(selected)”不在该组中",
                    "Target “\(selected)” selected by group “\(group.name)” is not a member"
                ))
                continue
            }
            appendSelectionIssue(
                selected,
                context: tr("策略组“\(group.name)”", "group “\(group.name)”")
            )
        }

        var seen = Set<String>()
        return issues.filter { seen.insert($0).inserted }
    }

    func canCreateScenario(from template: ScenarioTemplate) -> Bool {
        let hasDirect = profile.lines.contains { $0.type == "direct" && isUsableRouteLine($0) }
        let hasAnyConnect = profile.lines.contains { $0.type == "vpn" && isUsableRouteLine($0) }
        switch template {
        case .overseas, .domestic:
            return hasDirect && hasAnyConnect
        case .domesticSS:
            let hasProxy = profile.lines.contains {
                $0.type != "direct" && $0.type != "vpn" && isUsableRouteLine($0)
            }
            return hasDirect && hasAnyConnect && hasProxy
        case .blank:
            return hasDirect
        }
    }

    private func appendTargetIssue(
        lineID: String,
        subscriptionID: String,
        label: String,
        requiresPublicEgress: Bool = false,
        to issues: inout [String]
    ) {
        let hasLine = !lineID.isEmpty
        let hasSubscription = !subscriptionID.isEmpty
        guard hasLine != hasSubscription else {
            issues.append(tr("\(label)没有唯一目标", "\(label) does not have exactly one target"))
            return
        }

        if hasSubscription {
            guard let subscription = profile.subscriptions.first(where: { $0.id == subscriptionID }) else {
                issues.append(tr("\(label)引用的订阅已删除", "\(label) references a deleted subscription"))
                return
            }
            let selectionIssues = subscriptionSelectionConfigurationIssues(subscription)
            for selectionIssue in selectionIssues {
                issues.append(tr(
                    "\(label)使用的订阅“\(subscription.name)”：\(selectionIssue)",
                    "Subscription “\(subscription.name)” used by \(label): \(selectionIssue)"
                ))
            }
            if !isUsableSubscription(subscription) {
                issues.append(tr(
                    "\(label)使用的订阅“\(subscription.name)”没有可用节点",
                    "Subscription “\(subscription.name)” used by \(label) has no usable nodes"
                ))
            }
            return
        }

        guard let line = profile.lines.first(where: { $0.id == lineID }) else {
            issues.append(tr("\(label)引用的线路已删除", "\(label) references a deleted line"))
            return
        }
        let lineIssues = routeLineConfigurationIssues(line)
        if !lineIssues.isEmpty {
            let trimmedName = line.name.trimmingCharacters(in: .whitespacesAndNewlines)
            let displayName = trimmedName.isEmpty ? line.id : trimmedName
            issues.append(tr(
                "\(label)使用的线路“\(displayName)”配置不完整：\(lineIssues.joined(separator: "、"))",
                "Line “\(displayName)” used by \(label) is incomplete: \(lineIssues.joined(separator: ", "))"
            ))
        } else if requiresPublicEgress,
                  line.type == "tailscale",
                  line.tailscaleExitNode.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            issues.append(tr(
                "\(label)使用的 Tailscale 线路“\(line.name)”尚未选择出口节点",
                "Tailscale line “\(line.name)” used by \(label) has no exit node"
            ))
        }
    }

    var statusText: String {
        if tailscaleSetupLineID != nil {
            let name = profile.lines.first(where: { $0.id == tailscaleSetupLineID })?.name
                ?? "Tailscale"
            if isConnected {
                return tr(
                    "已连接 · 正在设置 \(name)",
                    "Connected · Setting Up \(name)"
                )
            }
            return tr("正在设置 \(name)", "Setting Up \(name)")
        }
        switch engine.status {
        case "connected": return tr("已连接", "Connected")
        case "connecting": return tr("正在连接…", "Connecting…")
        case "action-required": return tr("需要登录 Tailscale", "Tailscale Sign-in Required")
        case "disconnecting": return tr("正在断开…", "Disconnecting…")
        case "reconnecting": return tr("正在重连…", "Reconnecting…")
        default:
            if let err = engine.lastError { return userFacingConnectionText(err) }
            return tr("未连接", "Not Connected")
        }
    }

    var activeScenario: Scenario? {
        profile.scenarios.first { $0.id == profile.activeScenarioID }
    }

    init(
        engine: TunnelEngine = NoopTunnelEngine(),
        tunnelManager: TunnelManaging? = nil,
        tailscaleSetupRuntime: TailscaleSetupRuntime? = nil,
        persistence: AppPersistenceContext = .production,
        seed: ProfileSeed? = nil
    ) {
        self.engine = engine
        self.tunnelManager = tunnelManager
        self.tailscaleSetupRuntime = tailscaleSetupRuntime
        self.persistence = persistence
        self.seed = seed

        // 先用预置配置（没有就用 bootstrap）初始化，loadSaved 后会被覆盖
        let initialProfile = seed?.profile ?? Profile.bootstrap()
        self.profile = initialProfile
        self.lastPersistedProfile = initialProfile

        // 语言：先读已保存，没有则用系统语言
        if let savedLang = persistence.defaults.string(forKey: persistence.languageKey),
           let lang = Lang(rawValue: savedLang) {
            self.language = lang
        } else {
            self.language = .system
        }
        self.autoReconnectEnabled = persistence.defaults.object(forKey: persistence.autoReconnectKey) as? Bool ?? true
        let connectOnOpen = persistence.defaults.object(forKey: persistence.connectOnOpenKey) as? Bool ?? false
        self.dataUseNoticeAccepted =
            persistence.defaults.integer(forKey: persistence.dataUseNoticeKey) >= Self.dataUseNoticeVersion
        self.connectOnOpenEnabled = connectOnOpen
        self.openConnectPending = connectOnOpen
        self.systemOnDemandEnabled = persistence.defaults.object(
            forKey: persistence.systemOnDemandKey
        ) as? Bool ?? false
        self.systemOnDemandState = tunnelManager?.systemOnDemandState
            ?? (systemOnDemandEnabled ? .failed("系统连接管理层不可用") : .disabled)
        onDemandStateSub = tunnelManager?.systemOnDemandStatePublisher
            .removeDuplicates()
            .sink { [weak self] state in
                self?.systemOnDemandState = state
            }
        interruptedTailscaleSetupRecoveryPending =
            persistence.defaults.string(forKey: persistence.tailscaleSetupLineKey) != nil
        if interruptedTailscaleSetupRecoveryPending {
            // 主 App 已重新启动，旧的进程内 Libbox 与文件锁已经不存在；这里只需清理
            // 崩溃标记，不能再次暂停并与按需恢复产生一轮新的偏好写入竞态。
            persistence.defaults.removeObject(forKey: persistence.tailscaleSetupLineKey)
            persistence.defaults.synchronize()
        }
        tunnelManager?.setSystemOnDemandEnabled(systemOnDemandEnabled)

        observedEngineStatus = engine.status
        engineSub = engine.objectWillChange.sink { [weak self] _ in
            guard let self else { return }
            self.objectWillChange.send()
        }
        verificationSub = engine.dataPathVerifiedPublisher.sink { [weak self] in
            self?.markUsedLinesVerified()
        }
        engineStatusSub = engine.statusPublisher
            .removeDuplicates()
            .sink { [weak self] status in
                self?.handleEngineStatusChange(status)
            }
        loadSaved()
        if !persistenceRequiresRecovery {
            profile.ensureConnectivityTestConfiguration()
        }
        refreshTunnelProfileStatus()
        engine.syncStatus()
    }

    private func handleEngineStatusChange(_ current: String) {
        guard current != observedEngineStatus else { return }
        let previous = observedEngineStatus
        observedEngineStatus = current

        // A preference reload can still see the old session while stop is pending.
        if disconnectRequested && (current == "connected" || current == "action-required") { return }

        if (current == "connected" || current == "action-required"),
           runningProfileSnapshot == nil {
            // 主 App 重启时系统隧道可能仍在运行。此时没有本进程内快照，只能用
            // 已从安全存储恢复的配置重建运行态索引，否则登录入口会显示却无法操作。
            runningProfileSnapshot = profile
            updatePendingRuntimeChanges()
        }

        if current == "connected" {
            tailscaleAuthRefreshGeneration &+= 1
            runtimeTailscaleNeedsLoginIDs = []
            autoReconnectAttempt = 0
            autoReconnectTask?.cancel()
            autoReconnectTask = nil
            #if os(iOS)
            refreshScenarioCatalog()
            #endif
            return
        }

        if current == "action-required" {
            refreshRuntimeTailscaleAuthRequests()
            return
        }

        guard current == "disconnected" else { return }
        tailscaleAuthRefreshGeneration &+= 1
        runtimeTailscaleNeedsLoginIDs = []
        let hadRunningConfiguration = runningProfileSnapshot != nil
        runningProfileSnapshot = nil
        updatePendingRuntimeChanges()
        if reconnectAfterDisconnect {
            reconnectAfterDisconnect = false
            disconnectRequested = false
            Task { @MainActor [weak self] in
                try? await Task.sleep(for: .milliseconds(300))
                guard let self else { return }
                if self.canConnect {
                    self.connect(origin: .configurationChange)
                } else {
                    self.engine.lastError = self.activeConfigurationIssues.prefix(3).joined(
                        separator: self.tr("；", "; ")
                    )
                }
            }
            return
        }
        if disconnectRequested {
            disconnectRequested = false
            autoReconnectAttempt = 0
            autoReconnectTask?.cancel()
            autoReconnectTask = nil
            return
        }
        guard engine.consumeAutomaticReconnectPermission() else {
            autoReconnectAttempt = 0
            autoReconnectTask?.cancel()
            autoReconnectTask = nil
            return
        }
        let wasUnexpected = hadRunningConfiguration
            || ["connected", "action-required", "reconnecting"].contains(previous)
            || (previous == "connecting" && autoReconnectAttempt > 0)
        // 系统已经接管时不再从主 App 同时 start，避免两个恢复路径竞争同一会话。
        guard tunnelManager?.systemOnDemandActive != true else { return }
        // @Published emits during willSet, so engine.status can still expose the
        // previous "connected" value while this callback handles "disconnected".
        // Validate configuration here and let the delayed task use canConnect
        // after the new runtime status has settled.
        guard autoReconnectEnabled,
              wasUnexpected,
              !engine.isBusy,
              isConnectionConfigured,
              autoReconnectAttempt < 3 else { return }
        autoReconnectAttempt += 1
        let delaySeconds = [1, 2, 5][autoReconnectAttempt - 1]
        engine.lastError = tr(
            "连接中断，\(delaySeconds) 秒后自动重试（\(autoReconnectAttempt)/3）",
            "Connection interrupted; retrying in \(delaySeconds)s (\(autoReconnectAttempt)/3)"
        )
        autoReconnectTask?.cancel()
        autoReconnectTask = Task { @MainActor [weak self] in
            try? await Task.sleep(for: .seconds(delaySeconds))
            guard !Task.isCancelled, let self, self.autoReconnectEnabled, self.canConnect else { return }
            self.autoReconnectTask = nil
            self.connect(origin: .autoRetry)
        }
    }

    /// 打开 XDial 后自动连接一次。首页在 App 回到前台、读完系统里的连接状态并按网络选好场景后调用。
    /// 已连接、正在连接、配置或账号不完整时不发起；不重试，失败交给已有的掉线重连规则（它不重试首次连接失败）。
    @discardableResult
    func connectAfterOpeningIfWanted(while contextIsCurrent: () -> Bool = { true }) async -> Bool {
        // 还没确认数据使用说明：这次启动的连接留到确认之后。
        guard openConnectPending, dataUseNoticeAccepted else { return false }
        await refreshTunnelProfileStatusAndWait()
        // 等待期间用户可能已经点了连接或断开，那就以用户为准。
        guard openConnectPending, !Task.isCancelled, contextIsCurrent() else { return false }
        openConnectPending = false
        guard AutomaticConnectionPolicy.shouldConnectOnLaunch(
            enabled: connectOnOpenEnabled,
            initialStatusSynchronized: true,
            installationReady: !persistenceRequiresRecovery,
            runtimeStatus: engine.status,
            canConnect: canConnect
        ) else {
            appLog("connect on open skipped: status=\(engine.status) configured=\(isConnectionConfigured) "
                   + "activeTunnel=\(hasActiveTunnel) recovery=\(persistenceRequiresRecovery)")
            return false
        }
        appLog("connect on open started")
        connect(origin: .launch)
        return true
    }

    func connect(origin: ConnectionTimeline.StartOrigin = .user) {
        if origin != .launch { openConnectPending = false }
        guard dataUseNoticeAccepted else {
            engine.lastError = tr(
                "请先阅读并确认数据使用说明，再连接。",
                "Review and confirm the data use notice before connecting."
            )
            return
        }
        if origin != .autoRetry {
            autoReconnectAttempt = 0
            autoReconnectTask?.cancel()
            autoReconnectTask = nil
        }
        disconnectRequested = false
        performConnectionStart(origin: origin)
    }

    private func performConnectionStart(origin: ConnectionTimeline.StartOrigin) {
        guard canConnect else { return }
        guard save() else { return }
        // persist() normalizes and upgrades the profile (including the visible
        // acceptance bindings). Revalidate the resulting configuration instead
        // of starting with assumptions checked against the pre-save profile.
        guard activeConfigurationIssues.isEmpty else {
            engine.lastError = activeConfigurationIssues.joined(separator: "\n")
            return
        }
        let anyConnect = activeVPNCredentials()
        runningProfileSnapshot = profile
        hasPendingRuntimeChanges = false
        guard let tunnelManager else {
            engine.start(profileJSON: buildProfileJSON())
            return
        }
        tunnelManager.startTunnel(
            profile: profile,
            anyConnect: anyConnect,
            allowSystemOnDemand: true,
            origin: origin
        ) { [weak self] result in
            MainActor.assumeIsolated {
                guard let self else { return }
                switch result {
                case .success:
                    self.helperInstalled = true
                    self.engine.syncStatus()
                case .failure(let error):
                    guard !(error is CancellationError) else { return }
                    self.runningProfileSnapshot = nil
                    self.hasPendingRuntimeChanges = false
                    self.engine.lastError = error.localizedDescription
                }
            }
        }
    }

    private func markUsedLinesVerified() {
        guard !hasPendingRuntimeChanges, let s = activeScenario else { return }

        var usedIDs = Set(s.bindings.map { $0.lineID })
        if !s.defaultLineID.isEmpty { usedIDs.insert(s.defaultLineID) }
        let runningTailscaleIDs = Set((runningProfileSnapshot?.lines ?? profile.lines).compactMap {
            $0.enabled && $0.type == "tailscale" ? $0.id : nil
        })

        var changed = false
        for i in profile.lines.indices {
            if usedIDs.contains(profile.lines[i].id), !profile.lines[i].verified {
                profile.lines[i].verified = true
                changed = true
            }
            if runningTailscaleIDs.contains(profile.lines[i].id),
               !profile.lines[i].tailscaleAuthenticated {
                profile.lines[i].tailscaleAuthenticated = true
                changed = true
            }
        }
        if changed { save() }
    }

    // MARK: - Connect

    func disconnect() {
        openConnectPending = false
        if !persistenceRequiresRecovery { engine.lastError = nil }
        disconnectRequested = engine.status != "disconnected"
        autoReconnectTask?.cancel()
        autoReconnectTask = nil
        if let tunnelManager {
            tunnelManager.recordUserAction("disconnect")
            tunnelManager.stopTunnel()
        } else {
            engine.stop()
        }
    }

    func reconnectToApplyChanges() {
        guard isConnected, hasPendingRuntimeChanges else { return }
        #if os(iOS)
        let target = profile.activeScenarioID
        Task { @MainActor in
            if await switchScenarioInTunnel(to: target) == .unavailable {
                engine.lastError = tr("当前 VPN 扩展无法在连接中应用配置，请手动断开后再连接。",
                                      "The active VPN extension cannot apply these changes in place. Disconnect and connect again.")
            }
        }
        #else
        reconnectAfterDisconnect = true
        disconnectRequested = false
        disconnect()
        disconnectRequested = false
        #endif
    }

    func removeTunnelProfile(completion: @escaping @Sendable (Result<Void, Error>) -> Void) {
        guard !hasActiveTunnel, !isBusy, let tunnelManager else {
            completion(.failure(TunnelRuntimeError.unavailable))
            return
        }
        tunnelManager.removeProfile { [weak self] result in
            MainActor.assumeIsolated {
                if case .success = result {
                    self?.helperInstalled = false
                }
                completion(result)
            }
        }
    }

    /// 只有活动场景恰好引用一条可用 AnyConnect 线路时才返回凭据。
    private func activeVPNCredentials() -> AnyConnectCredentials? {
        guard !persistenceRequiresRecovery else { return nil }
        guard activeAnyConnectLineIDs.count == 1,
              let id = activeAnyConnectLineIDs.first,
              let line = profile.lines.first(where: { $0.id == id }),
              isUsableRouteLine(line) else { return nil }
        return AnyConnectCredentials(
            server: line.vpnServer,
            username: line.vpnUsername,
            password: line.vpnPassword
        )
    }

    // MARK: - Persistence

    /// Vault key 使用带长度的结构化组件，避免用户可控 ID 通过 `-` 拼接产生碰撞，
    /// 导致一条线路在重启后拿到另一条线路的密码。
    private static func vaultKey(_ components: [String]) -> String {
        "v2" + components.map { "|\($0.utf8.count):\($0)" }.joined()
    }

    private static func vaultKey(_ components: String...) -> String {
        vaultKey(components)
    }

    @discardableResult
    func save() -> Bool {
        persist(replacingConflictedState: false)
    }

    /// 导入与重置是用户明确要求丢弃冲突状态的入口；普通编辑不能越过 revision 冲突。
    @discardableResult
    func replaceProfileAndSave(_ replacement: Profile) -> Bool {
        profile = replacement
        return persist(replacingConflictedState: true)
    }

    private func persist(replacingConflictedState: Bool) -> Bool {
        guard !persistenceRequiresRecovery || replacingConflictedState else {
            engine.lastError = persistenceRecoveryMessage
            profile = lastPersistedProfile
            return false
        }

        profile.ensureConnectivityTestConfiguration()

        // 先把所有 ASCII 字段做一次全角→半角清洗（兜底）
        for i in profile.lines.indices {
            profile.lines[i].vpnServer = profile.lines[i].vpnServer.normalizedASCII()
            profile.lines[i].vpnUsername = profile.lines[i].vpnUsername.normalizedASCII()
            profile.lines[i].vpnPassword = profile.lines[i].vpnPassword.normalizedASCII()
            profile.lines[i].trojanServer = profile.lines[i].trojanServer.normalizedASCII()
            profile.lines[i].trojanPassword = profile.lines[i].trojanPassword.normalizedASCII()
            profile.lines[i].trojanSNI = profile.lines[i].trojanSNI.normalizedASCII()
            profile.lines[i].ssServer = profile.lines[i].ssServer.normalizedASCII()
            profile.lines[i].ssMethod = profile.lines[i].ssMethod.normalizedASCII()
            profile.lines[i].ssPassword = profile.lines[i].ssPassword.normalizedASCII()
            profile.lines[i].vmessServer = profile.lines[i].vmessServer.normalizedASCII()
            profile.lines[i].vmessUUID = profile.lines[i].vmessUUID.normalizedASCII()
            profile.lines[i].tailscaleExitNode = profile.lines[i].tailscaleExitNode.normalizedASCII()
        }
        for i in profile.ruleSets.indices {
            profile.ruleSets[i].url = profile.ruleSets[i].url.normalizedASCII()
        }
        // 直连恒为已验证
        for i in profile.lines.indices where profile.lines[i].type == "direct" {
            profile.lines[i].verified = true
        }

        let split = splitSensitiveValues(from: profile)
        let revision = UUID().uuidString.lowercased()
        let profileEnvelope = ProfilePersistenceEnvelope(revision: revision, profile: split.sanitized)
        guard let data = try? JSONEncoder().encode(profileEnvelope) else {
            appLog("save: profile encoding failed")
            engine.lastError = tr(
                "无法保存配置，请重试",
                "Could not save the configuration. Please try again."
            )
            profile = lastPersistedProfile
            return false
        }

        let quarantine = replacingConflictedState ? [:] : quarantinedLegacyValues
        switch KeychainStore.saveVault(
            values: split.vault,
            revision: revision,
            quarantinedLegacyValues: quarantine,
            context: persistence.keychain
        ) {
        case .success:
            break
        case .cleanupFailure:
            appLog("save: legacy secure-data cleanup failed")
            persistenceRequiresRecovery = true
            engine.lastError = persistenceRecoveryMessage
            profile = lastPersistedProfile
            return false
        case .keychainFailure(let status):
            appLog("save: secure vault write failed (status=\(status))")
            engine.lastError = tr(
                "无法安全保存连接凭据，请解锁设备后重试",
                "Could not securely save connection credentials. Unlock the device and try again."
            )
            profile = lastPersistedProfile
            return false
        case .encodingFailure:
            appLog("save: secure vault encoding failed")
            engine.lastError = tr("无法保存安全数据，请重试", "Could not save secure data. Please try again.")
            profile = lastPersistedProfile
            return false
        }

        persistence.defaults.set(data, forKey: persistence.profileKey)
        guard persistence.defaults.data(forKey: persistence.profileKey) == data else {
            // Keychain 已经写入新 revision；profile 未确认落盘时必须阻止后续普通保存，
            // 否则会把两代数据继续混合。
            appLog("save: profile envelope write verification failed")
            persistenceRequiresRecovery = true
            engine.lastError = persistenceRecoveryMessage
            profile = lastPersistedProfile
            return false
        }

        persistedRevision = revision
        persistedVault = split.vault
        quarantinedLegacyValues = quarantine
        persistenceRequiresRecovery = false
        lastPersistedProfile = profile
        updatePendingRuntimeChanges()
        return true
    }

    private func updatePendingRuntimeChanges() {
        guard let runningProfileSnapshot else {
            hasPendingRuntimeChanges = false
            return
        }
        hasPendingRuntimeChanges = runtimeProfileData(profile) != runtimeProfileData(runningProfileSnapshot)
    }

    private func runtimeProfileData(_ source: Profile) -> Data? {
        var normalized = source
        for index in normalized.lines.indices {
            normalized.lines[index].verified = false
            // 登录事实是控制面状态，不改变当前运行中的 sing-box 配置。
            normalized.lines[index].tailscaleAuthenticated = false
        }
        for subscriptionIndex in normalized.subscriptions.indices {
            for lineIndex in normalized.subscriptions[subscriptionIndex].lines.indices {
                normalized.subscriptions[subscriptionIndex].lines[lineIndex].verified = false
            }
        }
        let encoder = JSONEncoder()
        encoder.outputFormatting = [.sortedKeys]
        return try? encoder.encode(normalized)
    }

    private var persistenceRecoveryMessage: String {
        tr(
            "安全配置版本不一致，已停止使用凭据。请在设置中重新导入或重置配置。",
            "Secure configuration versions do not match. Credentials are disabled; re-import or reset in Settings."
        )
    }

    private func splitSensitiveValues(from source: Profile) -> (sanitized: Profile, vault: [String: String]) {
        var sanitized = source
        var vault: [String: String] = [:]

        func store(_ value: inout String, key: String) {
            guard !value.isEmpty else { return }
            vault[key] = value
            value = ""
        }

        func storeLine(_ line: inout Line, scope: [String]) {
            store(&line.vpnServer, key: Self.vaultKey(scope + ["vpn-server"]))
            store(&line.vpnUsername, key: Self.vaultKey(scope + ["vpn-username"]))
            store(&line.vpnPassword, key: Self.vaultKey(scope + ["vpn-password"]))
            store(&line.trojanServer, key: Self.vaultKey(scope + ["trojan-server"]))
            store(&line.trojanPassword, key: Self.vaultKey(scope + ["trojan"]))
            store(&line.trojanSNI, key: Self.vaultKey(scope + ["trojan-sni"]))
            store(&line.ssServer, key: Self.vaultKey(scope + ["ss-server"]))
            store(&line.ssPassword, key: Self.vaultKey(scope + ["ss"]))
            store(&line.vmessServer, key: Self.vaultKey(scope + ["vmess-server"]))
            store(&line.vmessUUID, key: Self.vaultKey(scope + ["vmess"]))
            store(&line.tailscaleExitNode, key: Self.vaultKey(scope + ["tailscale-exit-node"]))
        }

        for index in sanitized.ruleSets.indices where sanitized.ruleSets[index].type == "url" {
            let id = sanitized.ruleSets[index].id
            store(&sanitized.ruleSets[index].url, key: Self.vaultKey("rule", id, "url"))
        }
        for index in sanitized.lines.indices {
            let id = sanitized.lines[index].id
            storeLine(&sanitized.lines[index], scope: ["line", id])
        }
        for subscriptionIndex in sanitized.subscriptions.indices {
            let subID = sanitized.subscriptions[subscriptionIndex].id
            store(
                &sanitized.subscriptions[subscriptionIndex].url,
                key: Self.vaultKey("subscription", subID, "url")
            )
            store(
                &sanitized.subscriptions[subscriptionIndex].testURL,
                key: Self.vaultKey("subscription", subID, "test-url")
            )
            store(
                &sanitized.subscriptions[subscriptionIndex].geoIPRuleSetURLTemplate,
                key: Self.vaultKey(
                    "subscription",
                    subID,
                    "geoip-rule-set-url-template"
                )
            )
            for groupIndex in sanitized.subscriptions[subscriptionIndex].proxyGroups.indices {
                store(
                    &sanitized.subscriptions[subscriptionIndex].proxyGroups[groupIndex].url,
                    key: Self.vaultKey("subscription", subID, "group", "\(groupIndex)", "url")
                )
            }
            for ruleIndex in sanitized.subscriptions[subscriptionIndex].rules.indices
            where sanitized.subscriptions[subscriptionIndex].rules[ruleIndex].type.uppercased() == "RULE-SET" {
                store(
                    &sanitized.subscriptions[subscriptionIndex].rules[ruleIndex].value,
                    key: Self.vaultKey("subscription", subID, "rule", "\(ruleIndex)", "url")
                )
            }
            for lineIndex in sanitized.subscriptions[subscriptionIndex].lines.indices {
                let lineID = sanitized.subscriptions[subscriptionIndex].lines[lineIndex].id
                storeLine(
                    &sanitized.subscriptions[subscriptionIndex].lines[lineIndex],
                    scope: ["subscription", subID, "line", lineID]
                )
            }
        }
        return (sanitized, vault)
    }

    private enum StoredProfileState {
        case missing
        case envelope(ProfilePersistenceEnvelope)
        case legacy(Profile)
        case corrupt
    }

    private func loadSaved() {
        let profileState = loadStoredProfile()
        let vaultState = KeychainStore.loadVaultState(context: persistence.keychain)

        switch profileState {
        case .missing:
            lastPersistedProfile = profile
            switch vaultState {
            case .missing:
                break
            case .available, .legacy, .corrupt:
                // iOS 删除 App 时会清掉 UserDefaults，但钥匙串条目会保留。配置不存在而
                // 钥匙串仍有凭据，说明是上一次安装留下的孤儿数据：与之配对的配置已经没了，
                // 继续保留只会把首次启动锁死。清掉后按全新安装处理。
                guard KeychainStore.clear(context: persistence.keychain) else {
                    blockPersistence(with: profile, log: "stale secure vault from a previous install could not be cleared")
                    return
                }
                appLog("loadSaved: cleared stale secure vault left by a previous install")
            case .unavailable:
                // 设备锁定等原因暂时读不到钥匙串时无法判断，保持原来的保护。
                blockPersistence(with: profile, log: "profile missing while secure vault is unreadable")
                return
            }
            appLog("loadSaved: no saved data, using bootstrap")
            if let seed {
                persistence.defaults.set(seed.revision, forKey: persistence.seedRevisionKey)
            }

        case .corrupt:
            blockPersistence(with: profile, log: "profile envelope is corrupt")

        case .envelope(let profileEnvelope):
            var loaded = profileEnvelope.profile
            lastPersistedProfile = loaded
            guard case .available(let vaultEnvelope, let cleanupRequired) = vaultState,
                  vaultEnvelope.revision == profileEnvelope.revision else {
                blockPersistence(with: loaded, log: "profile/vault revision mismatch")
                return
            }

            let containedPlaintext = containsSensitiveValues(loaded)
            restoreStructuredValues(vaultEnvelope.values, into: &loaded)
            let profileBeforeNormalization = loaded
            normalizeLegacyProfile(&loaded)
            // 预置配置有新增时，给老配置补一次；每个 revision 只补一次，用户之后删掉的不会再回来。
            if let seed, persistence.defaults.integer(forKey: persistence.seedRevisionKey) < seed.revision {
                loaded.adding(seed: seed.profile, ruleSetHistory: seed.ruleSetHistory)
                persistence.defaults.set(seed.revision, forKey: persistence.seedRevisionKey)
            }
            let normalizationChanged = loaded != profileBeforeNormalization
            profile = loaded
            lastPersistedProfile = loaded
            persistedRevision = profileEnvelope.revision
            persistedVault = vaultEnvelope.values
            quarantinedLegacyValues = vaultEnvelope.quarantinedLegacyValues

            guard !cleanupRequired else {
                blockPersistence(with: loaded, log: "legacy secure-data cleanup is incomplete")
                return
            }
            if containedPlaintext || normalizationChanged {
                // 早期 envelope 或中断迁移可能仍把账号/URL 留在 UserDefaults；
                // revision 已匹配，可以安全地重写为严格脱敏格式，同时把旧版
                // Tailscale verified 登录事实迁移到专用字段。
                if !save() {
                    // 明文清理失败不能只提示后继续连接，否则敏感字段仍会长期留在
                    // UserDefaults。恢复入口只允许用户显式导入或重置。
                    persistenceRequiresRecovery = true
                    engine.lastError = persistenceRecoveryMessage
                }
            }

        case .legacy(var loaded):
            var legacyValues: [String: String]
            var preexistingQuarantine: [String: String] = [:]
            switch vaultState {
            case .missing:
                switch loadLegacyPerItemValues(for: loaded) {
                case .success(let result):
                    legacyValues = result.values
                    preexistingQuarantine = result.quarantine
                case .failure:
                    blockPersistence(with: loaded, log: "legacy Keychain items are unavailable or corrupt")
                    return
                }
            case .legacy(let values):
                legacyValues = values
            case .available:
                blockPersistence(with: loaded, log: "legacy profile cannot be paired with revisioned vault")
                return
            case .unavailable(let status):
                blockPersistence(with: loaded, log: "secure vault unavailable (status=\(status))")
                return
            case .corrupt:
                blockPersistence(with: loaded, log: "secure vault is corrupt")
                return
            }

            let migration = restoreLegacyValues(legacyValues, into: &loaded)
            preexistingQuarantine.merge(migration.quarantine) { current, _ in current }
            normalizeLegacyProfile(&loaded)
            profile = loaded
            lastPersistedProfile = loaded
            quarantinedLegacyValues = preexistingQuarantine
            persistenceRequiresRecovery = false
            if save(), migration.hadCollision || !preexistingQuarantine.isEmpty {
                engine.lastError = tr(
                    "旧版安全数据存在重名，相关凭据未自动迁移，请重新填写。",
                    "Some legacy secure data was ambiguous and was not migrated. Re-enter the affected credentials."
                )
            }
        }
    }

    private func loadStoredProfile() -> StoredProfileState {
        guard let data = persistence.defaults.data(forKey: persistence.profileKey) else {
            return .missing
        }
        appLog("loadSaved: found \(data.count) bytes")

        if let root = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
           root["format"] != nil || root["revision"] != nil || root["profile"] != nil {
            guard let envelope = try? JSONDecoder().decode(ProfilePersistenceEnvelope.self, from: data),
                  envelope.isValid else { return .corrupt }
            return .envelope(envelope)
        }

        guard let raw = try? JSONSerialization.jsonObject(with: data) as? [String: Any] else {
            return .corrupt
        }
        let rewritten = Self.hasLegacyMetaphorKeys(raw) ? Self.rewriteLegacyMetaphorKeys(raw) : raw
        // Profile 的 Codable 兼容层会把缺失字段默认为空。持久化恢复不能因此把任意
        // JSON（例如 `{}` 或一次截断写入）当成合法配置并覆盖现有数据。
        let sharedCollections = ["lines", "rule_sets", "subscriptions"]
        let hasSharedShape = sharedCollections.allSatisfy { rewritten[$0] is [Any] }
        let hasCurrentShape = hasSharedShape
            && rewritten["scenarios"] is [Any]
            && rewritten["active_scenario_id"] is String
        if hasCurrentShape,
           let rewrittenData = try? JSONSerialization.data(withJSONObject: rewritten),
           let decoded = try? JSONDecoder().decode(Profile.self, from: rewrittenData) {
            return .legacy(decoded)
        }
        if let migrated = Self.migrate(oldProfile: raw) {
            return .legacy(migrated)
        }
        return .corrupt
    }

    private func blockPersistence(with fallback: Profile, log message: String) {
        appLog("loadSaved: \(message)")
        profile = fallback
        lastPersistedProfile = fallback
        persistenceRequiresRecovery = true
        engine.lastError = persistenceRecoveryMessage
    }

    private func containsSensitiveValues(_ profile: Profile) -> Bool {
        func lineContainsSensitiveValue(_ line: Line) -> Bool {
            !line.vpnServer.isEmpty || !line.vpnUsername.isEmpty || !line.vpnPassword.isEmpty
                || !line.trojanServer.isEmpty || !line.trojanPassword.isEmpty || !line.trojanSNI.isEmpty
                || !line.ssServer.isEmpty || !line.ssPassword.isEmpty
                || !line.vmessServer.isEmpty || !line.vmessUUID.isEmpty
                || !line.tailscaleExitNode.isEmpty
        }
        if profile.lines.contains(where: lineContainsSensitiveValue) { return true }
        if profile.ruleSets.contains(where: { $0.type == "url" && !$0.url.isEmpty }) { return true }
        return profile.subscriptions.contains { subscription in
            !subscription.url.isEmpty || !subscription.testURL.isEmpty
                || !subscription.geoIPRuleSetURLTemplate.isEmpty
                || subscription.proxyGroups.contains(where: { !$0.url.isEmpty })
                || subscription.rules.contains(where: {
                    $0.type.uppercased() == "RULE-SET" && !$0.value.isEmpty
                })
                || subscription.lines.contains(where: lineContainsSensitiveValue)
        }
    }

    private func restoreStructuredValues(_ vault: [String: String], into profile: inout Profile) {
        func restore(_ value: inout String, key: String) {
            if let stored = vault[key] { value = stored }
        }

        func restoreLine(_ line: inout Line, scope: [String]) {
            restore(&line.vpnServer, key: Self.vaultKey(scope + ["vpn-server"]))
            restore(&line.vpnUsername, key: Self.vaultKey(scope + ["vpn-username"]))
            restore(&line.vpnPassword, key: Self.vaultKey(scope + ["vpn-password"]))
            restore(&line.trojanServer, key: Self.vaultKey(scope + ["trojan-server"]))
            restore(&line.trojanPassword, key: Self.vaultKey(scope + ["trojan"]))
            restore(&line.trojanSNI, key: Self.vaultKey(scope + ["trojan-sni"]))
            restore(&line.ssServer, key: Self.vaultKey(scope + ["ss-server"]))
            restore(&line.ssPassword, key: Self.vaultKey(scope + ["ss"]))
            restore(&line.vmessServer, key: Self.vaultKey(scope + ["vmess-server"]))
            restore(&line.vmessUUID, key: Self.vaultKey(scope + ["vmess"]))
            restore(&line.tailscaleExitNode, key: Self.vaultKey(scope + ["tailscale-exit-node"]))
        }

        for index in profile.ruleSets.indices where profile.ruleSets[index].type == "url" {
            restore(&profile.ruleSets[index].url, key: Self.vaultKey("rule", profile.ruleSets[index].id, "url"))
        }
        for index in profile.lines.indices {
            let id = profile.lines[index].id
            restoreLine(&profile.lines[index], scope: ["line", id])
        }
        for subscriptionIndex in profile.subscriptions.indices {
            let subID = profile.subscriptions[subscriptionIndex].id
            restore(&profile.subscriptions[subscriptionIndex].url, key: Self.vaultKey("subscription", subID, "url"))
            restore(
                &profile.subscriptions[subscriptionIndex].testURL,
                key: Self.vaultKey("subscription", subID, "test-url")
            )
            restore(
                &profile.subscriptions[subscriptionIndex].geoIPRuleSetURLTemplate,
                key: Self.vaultKey(
                    "subscription",
                    subID,
                    "geoip-rule-set-url-template"
                )
            )
            for groupIndex in profile.subscriptions[subscriptionIndex].proxyGroups.indices {
                restore(
                    &profile.subscriptions[subscriptionIndex].proxyGroups[groupIndex].url,
                    key: Self.vaultKey("subscription", subID, "group", "\(groupIndex)", "url")
                )
            }
            for ruleIndex in profile.subscriptions[subscriptionIndex].rules.indices
            where profile.subscriptions[subscriptionIndex].rules[ruleIndex].type.uppercased() == "RULE-SET" {
                restore(
                    &profile.subscriptions[subscriptionIndex].rules[ruleIndex].value,
                    key: Self.vaultKey("subscription", subID, "rule", "\(ruleIndex)", "url")
                )
            }
            for lineIndex in profile.subscriptions[subscriptionIndex].lines.indices {
                let lineID = profile.subscriptions[subscriptionIndex].lines[lineIndex].id
                restoreLine(
                    &profile.subscriptions[subscriptionIndex].lines[lineIndex],
                    scope: ["subscription", subID, "line", lineID]
                )
            }
        }
    }

    private struct LegacyMigrationResult {
        let quarantine: [String: String]
        let hadCollision: Bool
    }

    private func restoreLegacyValues(_ vault: [String: String], into profile: inout Profile) -> LegacyMigrationResult {
        let ownerCounts = legacyOwnerCounts(for: profile)
        let ambiguousKeys = Set(ownerCounts.compactMap { key, count in
            count > 1 && vault[key] != nil ? key : nil
        })
        var quarantine = Dictionary(uniqueKeysWithValues: ambiguousKeys.compactMap { key in
            vault[key].map { (key, $0) }
        })

        func restore(_ value: inout String, structuredKey: String, legacyKey: String?) {
            if let stored = vault[structuredKey] {
                value = stored
                return
            }
            guard value.isEmpty,
                  let legacyKey,
                  !ambiguousKeys.contains(legacyKey),
                  let stored = vault[legacyKey] else { return }
            value = stored
        }

        for index in profile.ruleSets.indices where profile.ruleSets[index].type == "url" {
            let id = profile.ruleSets[index].id
            restore(
                &profile.ruleSets[index].url,
                structuredKey: Self.vaultKey("rule", id, "url"),
                legacyKey: "rule-\(id)-url"
            )
        }
        for index in profile.lines.indices {
            let id = profile.lines[index].id
            restore(
                &profile.lines[index].vpnUsername,
                structuredKey: Self.vaultKey("line", id, "vpn-username"),
                legacyKey: nil
            )
            restore(
                &profile.lines[index].vpnPassword,
                structuredKey: Self.vaultKey("line", id, "vpn-password"),
                legacyKey: "\(id)-vpn"
            )
            for (suffix, keyPath) in [
                ("trojan", \Line.trojanPassword),
                ("ss", \Line.ssPassword),
                ("vmess", \Line.vmessUUID),
            ] {
                restore(
                    &profile.lines[index][keyPath: keyPath],
                    structuredKey: Self.vaultKey("line", id, suffix),
                    legacyKey: "\(id)-\(suffix)"
                )
            }
        }
        for subscriptionIndex in profile.subscriptions.indices {
            let subID = profile.subscriptions[subscriptionIndex].id
            restore(
                &profile.subscriptions[subscriptionIndex].url,
                structuredKey: Self.vaultKey("subscription", subID, "url"),
                legacyKey: "subscription-\(subID)-url"
            )
            restore(
                &profile.subscriptions[subscriptionIndex].testURL,
                structuredKey: Self.vaultKey("subscription", subID, "test-url"),
                legacyKey: "subscription-\(subID)-test-url"
            )
            for groupIndex in profile.subscriptions[subscriptionIndex].proxyGroups.indices {
                restore(
                    &profile.subscriptions[subscriptionIndex].proxyGroups[groupIndex].url,
                    structuredKey: Self.vaultKey("subscription", subID, "group", "\(groupIndex)", "url"),
                    legacyKey: "subscription-\(subID)-group-\(groupIndex)-url"
                )
            }
            for ruleIndex in profile.subscriptions[subscriptionIndex].rules.indices
            where profile.subscriptions[subscriptionIndex].rules[ruleIndex].type.uppercased() == "RULE-SET" {
                restore(
                    &profile.subscriptions[subscriptionIndex].rules[ruleIndex].value,
                    structuredKey: Self.vaultKey("subscription", subID, "rule", "\(ruleIndex)", "url"),
                    legacyKey: "subscription-\(subID)-rule-\(ruleIndex)-url"
                )
            }
            for lineIndex in profile.subscriptions[subscriptionIndex].lines.indices {
                let lineID = profile.subscriptions[subscriptionIndex].lines[lineIndex].id
                let prefix = "\(subID)-\(lineID)"
                restore(
                    &profile.subscriptions[subscriptionIndex].lines[lineIndex].vpnUsername,
                    structuredKey: Self.vaultKey("subscription", subID, "line", lineID, "vpn-username"),
                    legacyKey: nil
                )
                restore(
                    &profile.subscriptions[subscriptionIndex].lines[lineIndex].vpnPassword,
                    structuredKey: Self.vaultKey("subscription", subID, "line", lineID, "vpn-password"),
                    legacyKey: "\(prefix)-vpn"
                )
                for (suffix, keyPath) in [
                    ("trojan", \Line.trojanPassword),
                    ("ss", \Line.ssPassword),
                    ("vmess", \Line.vmessUUID),
                ] {
                    restore(
                        &profile.subscriptions[subscriptionIndex].lines[lineIndex][keyPath: keyPath],
                        structuredKey: Self.vaultKey("subscription", subID, "line", lineID, suffix),
                        legacyKey: "\(prefix)-\(suffix)"
                    )
                }
            }
        }

        // 未识别但已明确判定冲突的值只进隔离区，永不绑定到运行线路。
        for key in ambiguousKeys where quarantine[key] == nil {
            quarantine[key] = vault[key]
        }
        return LegacyMigrationResult(quarantine: quarantine, hadCollision: !ambiguousKeys.isEmpty)
    }

    private func legacyOwnerCounts(for profile: Profile) -> [String: Int] {
        var owners: [String: Int] = [:]
        func register(_ key: String) { owners[key, default: 0] += 1 }

        for line in profile.lines {
            for suffix in ["vpn", "trojan", "ss", "vmess"] { register("\(line.id)-\(suffix)") }
        }
        for rule in profile.ruleSets where rule.type == "url" { register("rule-\(rule.id)-url") }
        for subscription in profile.subscriptions {
            let subID = subscription.id
            register("subscription-\(subID)-url")
            register("subscription-\(subID)-test-url")
            for index in subscription.proxyGroups.indices {
                register("subscription-\(subID)-group-\(index)-url")
            }
            for index in subscription.rules.indices
            where subscription.rules[index].type.uppercased() == "RULE-SET" {
                register("subscription-\(subID)-rule-\(index)-url")
            }
            for line in subscription.lines {
                for suffix in ["vpn", "trojan", "ss", "vmess"] {
                    register("\(subID)-\(line.id)-\(suffix)")
                }
            }
        }
        return owners
    }

    private enum LegacyItemMigrationError: Error {
        case unavailable
    }

    private func loadLegacyPerItemValues(
        for profile: Profile
    ) -> Result<(values: [String: String], quarantine: [String: String]), LegacyItemMigrationError> {
        var values: [String: String] = [:]
        var quarantine: [String: String] = [:]
        let ownerCounts = legacyOwnerCounts(for: profile)

        func readAccounts(
            _ accounts: [String],
            structuredKey: String,
            legacyOwnerKey: String
        ) -> Bool {
            var found: [(String, String)] = []
            for account in accounts {
                switch KeychainStore.loadLegacyItem(account: account, context: persistence.keychain) {
                case .missing:
                    continue
                case .available(let value):
                    if !value.isEmpty { found.append((account, value)) }
                case .unavailable, .corrupt:
                    return false
                }
            }
            let distinct = Set(found.map(\.1))
            if ownerCounts[legacyOwnerKey, default: 0] > 1 {
                // 旧 account 把多个用户可控 ID 用 `-` 拼在一起；同一个 account 可能
                // 同时属于两条线路。先判冲突再读取，只保留到隔离区，绝不自动绑定。
                for (account, value) in found { quarantine["legacy-account:\(account)"] = value }
            } else if distinct.count == 1, let value = distinct.first {
                values[structuredKey] = value
            } else if distinct.count > 1 {
                for (account, value) in found { quarantine["legacy-account:\(account)"] = value }
            }
            return true
        }

        for line in profile.lines {
            for (suffix, structuredSuffix) in [
                ("vpn", "vpn-password"), ("trojan", "trojan"), ("ss", "ss"), ("vmess", "vmess"),
            ] {
                let accounts = [keychainPrefix, "xdial-port-", "xdial-exit-"].map {
                    $0 + line.id + "-" + suffix
                }
                guard readAccounts(
                    accounts,
                    structuredKey: Self.vaultKey("line", line.id, structuredSuffix),
                    legacyOwnerKey: "\(line.id)-\(suffix)"
                ) else {
                    return .failure(.unavailable)
                }
            }
        }
        for subscription in profile.subscriptions {
            for line in subscription.lines {
                for (suffix, structuredSuffix) in [
                    ("vpn", "vpn-password"), ("trojan", "trojan"), ("ss", "ss"), ("vmess", "vmess"),
                ] {
                    let account = subKeychainPrefix + subscription.id + "-" + line.id + "-" + suffix
                    guard readAccounts(
                        [account],
                        structuredKey: Self.vaultKey(
                            "subscription", subscription.id, "line", line.id, structuredSuffix
                        ),
                        legacyOwnerKey: "\(subscription.id)-\(line.id)-\(suffix)"
                    ) else {
                        return .failure(.unavailable)
                    }
                }
            }
        }
        return .success((values, quarantine))
    }

    private func normalizeLegacyProfile(_ profile: inout Profile) {
        for index in profile.lines.indices {
            if profile.lines[index].type == "ss" { profile.lines[index].type = "shadowsocks" }
            if profile.lines[index].type == "vpn", profile.lines[index].name == "VPN" {
                profile.lines[index].name = "AnyConnect"
            }
            if profile.lines[index].type == "tailscale",
               profile.lines[index].verified,
               !profile.lines[index].tailscaleAuthenticated {
                profile.lines[index].tailscaleAuthenticated = true
            }
        }
        for subscriptionIndex in profile.subscriptions.indices {
            for lineIndex in profile.subscriptions[subscriptionIndex].lines.indices
            where profile.subscriptions[subscriptionIndex].lines[lineIndex].type == "ss" {
                profile.subscriptions[subscriptionIndex].lines[lineIndex].type = "shadowsocks"
            }
        }
    }

    // MARK: - Legacy 命名 key 迁移（比喻命名 → 正式命名）
    //
    // 只做「精确 key 匹配」的重写，绝不做字符串子串替换 —— 否则会误伤 trojan_port、
    // default_subscription_id、vpn_server 这类含 "port"/"cargo"/"cruise" 子串的合法字段。

    /// 判断字典里是否存在任一比喻命名时代的顶层/内嵌 key（用于决定是否需要重写）。
    private static func hasLegacyMetaphorKeys(_ dict: [String: Any]) -> Bool {
        if dict["ports"] != nil || dict["cargoes"] != nil || dict["cruises"] != nil
            || dict["active_cruise_id"] != nil {
            return true
        }
        // 内嵌：cruises[].bindings[].{cargo_id,port_id}、cruises[].default_port_id、
        // subscriptions[].ports。逐层精确探测。
        if let cruises = dict["cruises"] as? [[String: Any]] {
            for c in cruises {
                if c["default_port_id"] != nil { return true }
                if let bs = c["bindings"] as? [[String: Any]] {
                    for b in bs where b["cargo_id"] != nil || b["port_id"] != nil { return true }
                }
            }
        }
        if let subs = dict["subscriptions"] as? [[String: Any]] {
            for s in subs where s["ports"] != nil { return true }
        }
        return false
    }

    /// 把一份比喻命名的 profile 字典按对照表精确重写成正式命名字典。
    /// 顶层：ports→lines、cargoes→rule_sets、cruises→scenarios、active_cruise_id→active_scenario_id。
    /// scenario 内嵌：default_port_id→default_line_id；binding 内嵌：cargo_id→rule_set_id、port_id→line_id。
    /// subscription 内嵌：ports→lines（其内部 Line 字段如 trojan_port 保持不变）。
    private static func rewriteLegacyMetaphorKeys(_ dict: [String: Any]) -> [String: Any] {
        var out = dict

        // 顶层 lines
        if let v = out.removeValue(forKey: "ports") { out["lines"] = v }
        // 顶层 rule_sets
        if let v = out.removeValue(forKey: "cargoes") { out["rule_sets"] = v }
        // 顶层 active_scenario_id
        if let v = out.removeValue(forKey: "active_cruise_id") { out["active_scenario_id"] = v }

        // 顶层 scenarios（含其内嵌 bindings / default_port_id 重写）
        if let cruises = out.removeValue(forKey: "cruises") as? [[String: Any]] {
            out["scenarios"] = cruises.map { rewriteLegacyScenario($0) }
        } else if let cruises = out["cruises"] {
            // 类型不是 [[String:Any]]（异常数据）也搬过去，避免丢数据
            out.removeValue(forKey: "cruises")
            out["scenarios"] = cruises
        }

        // subscriptions 内嵌 ports → lines
        if let subs = out["subscriptions"] as? [[String: Any]] {
            out["subscriptions"] = subs.map { sub -> [String: Any] in
                var ns = sub
                if let v = ns.removeValue(forKey: "ports") { ns["lines"] = v }
                return ns
            }
        }

        return out
    }

    /// 重写单个 scenario 字典：default_port_id → default_line_id，bindings 逐条重写。
    private static func rewriteLegacyScenario(_ dict: [String: Any]) -> [String: Any] {
        var m = dict
        if let v = m.removeValue(forKey: "default_port_id") { m["default_line_id"] = v }
        if let bindings = m["bindings"] as? [[String: Any]] {
            m["bindings"] = bindings.map { b -> [String: Any] in
                var nb = b
                if let v = nb.removeValue(forKey: "cargo_id") { nb["rule_set_id"] = v }
                if let v = nb.removeValue(forKey: "port_id") { nb["line_id"] = v }
                return nb
            }
        }
        return m
    }

    /// 把旧格式 profile (v0.2: exits/rules/strategies) 迁移到新格式 (lines/rule_sets/scenarios)
    static func migrate(oldProfile: [String: Any]) -> Profile? {
        var p = Profile()
        // 旧版本的 v0.2 里是 exits/rules/strategies
        if let oldExits = oldProfile["exits"] as? [[String: Any]] {
            p.lines = oldExits.compactMap { dict -> Line? in
                guard let data = try? JSONSerialization.data(withJSONObject: dict),
                      let line = try? JSONDecoder().decode(Line.self, from: data) else { return nil }
                return line
            }
        }
        if let oldRules = oldProfile["rules"] as? [[String: Any]] {
            p.ruleSets = oldRules.compactMap { dict -> RuleSet? in
                guard let data = try? JSONSerialization.data(withJSONObject: dict),
                      let c = try? JSONDecoder().decode(RuleSet.self, from: data) else { return nil }
                return c
            }
        }
        if let oldStrategies = oldProfile["strategies"] as? [[String: Any]] {
            p.scenarios = oldStrategies.compactMap { dict -> Scenario? in
                // 旧 strategy.bindings 用 rule_id/exit_id；旧 default_exit_id
                var fixed = dict
                if let oldBindings = dict["bindings"] as? [[String: Any]] {
                    fixed["bindings"] = oldBindings.map { b -> [String: Any] in
                        var nb = b
                        if let r = b["rule_id"] { nb["rule_set_id"] = r; nb.removeValue(forKey: "rule_id") }
                        if let e = b["exit_id"] { nb["line_id"] = e; nb.removeValue(forKey: "exit_id") }
                        return nb
                    }
                }
                if let de = dict["default_exit_id"] {
                    fixed["default_line_id"] = de
                    fixed.removeValue(forKey: "default_exit_id")
                }
                guard let data = try? JSONSerialization.data(withJSONObject: fixed),
                      let c = try? JSONDecoder().decode(Scenario.self, from: data) else { return nil }
                return c
            }
        }
        if let active = oldProfile["active_strategy_id"] as? String {
            p.activeScenarioID = active
        }
        return p.lines.isEmpty && p.ruleSets.isEmpty && p.scenarios.isEmpty ? nil : p
    }

    func refreshTunnelProfileStatus() {
        guard let tunnelManager else {
            helperInstalled = false
            return
        }
        tunnelManager.refreshProfileStatus { [weak self] installed in
            Task { @MainActor in
                guard let self else { return }
                self.helperInstalled = installed
                guard self.interruptedTailscaleSetupRecoveryPending else { return }
                self.interruptedTailscaleSetupRecoveryPending = false
                self.engine.lastError = self.tr(
                    "上次 Tailscale 线路设置未完成，已清理设置状态。",
                    "The interrupted Tailscale line setup state was cleared."
                )
            }
        }
    }

    /// 等待系统隧道配置加载完成。快捷指令可能在 App 冷启动后立即执行，
    /// 此时 manager 尚未加载，直接 stop / 判断状态会读到初始值。
    func refreshTunnelProfileStatusAndWait() async {
        guard let tunnelManager else {
            helperInstalled = false
            return
        }
        let installed = await withCheckedContinuation { continuation in
            tunnelManager.refreshProfileStatus { continuation.resume(returning: $0) }
        }
        helperInstalled = installed
    }

    // MARK: - Subscription Management

    func addSubscription(name: String, url: String, format: String, strategy: String,
                         lines: [Line], proxyGroups: [SubProxyGroup] = [], rules: [SubRule] = []) {
        guard canMutateConfiguration else { return }
        let sub = Subscription(
            id: "sub-" + String(UUID().uuidString.prefix(8)).lowercased(),
            name: name,
            url: url,
            format: format,
            strategy: strategy,
            lines: lines,
            proxyGroups: proxyGroups,
            rules: rules
        )
        profile.subscriptions.append(sub)
        save()
    }

    func updateSubscription(_ id: String, with result: ParseResult) {
        guard canMutateConfiguration,
              let idx = profile.subscriptions.firstIndex(where: { $0.id == id }) else { return }
        let previousDefaultSelection = profile.subscriptions[idx].selected
        var previousSelections: [String: String] = [:]
        for group in profile.subscriptions[idx].proxyGroups where previousSelections[group.name] == nil {
            previousSelections[group.name] = group.selected
        }
        var groups = result.proxyGroups ?? []
        for groupIndex in groups.indices {
            guard let selected = previousSelections[groups[groupIndex].name],
                  groups[groupIndex].proxies.contains(selected) else { continue }
            groups[groupIndex].selected = selected
        }
        profile.subscriptions[idx].lines = result.lines
        profile.subscriptions[idx].proxyGroups = groups
        profile.subscriptions[idx].selected = result.lines.contains(where: {
            $0.name == previousDefaultSelection
        }) ? previousDefaultSelection : ""
        profile.subscriptions[idx].rules = result.rules ?? []
        profile.subscriptions[idx].updatedAt = Int(Date().timeIntervalSince1970)
        save()  // vault 整体覆盖，旧条目自然消失
    }

    @discardableResult
    func updateSubscriptionSelection(subscriptionID: String, groupName: String, selected: String) -> Bool {
        guard canChangeSubscriptionSelection,
              let subscriptionIndex = profile.subscriptions.firstIndex(where: { $0.id == subscriptionID }) else {
            return false
        }
        if groupName == "__default__" {
            guard profile.subscriptions[subscriptionIndex].proxyGroups.isEmpty,
                  profile.subscriptions[subscriptionIndex].lines.contains(where: { $0.name == selected }) else {
                return false
            }
            profile.subscriptions[subscriptionIndex].selected = selected
            return save()
        }
        guard let groupIndex = profile.subscriptions[subscriptionIndex].proxyGroups.firstIndex(where: {
                  $0.name == groupName
              }),
              profile.subscriptions[subscriptionIndex].proxyGroups[groupIndex].proxies.contains(selected) else {
            return false
        }
        profile.subscriptions[subscriptionIndex].proxyGroups[groupIndex].selected = selected
        return save()
    }

    func markSubscriptionSelectionApplied(subscriptionID: String, groupName: String, selected: String) {
        guard var snapshot = runningProfileSnapshot,
              let subscriptionIndex = snapshot.subscriptions.firstIndex(where: { $0.id == subscriptionID }) else {
            return
        }
        if groupName == "__default__" {
            snapshot.subscriptions[subscriptionIndex].selected = selected
            runningProfileSnapshot = snapshot
            updatePendingRuntimeChanges()
            return
        }
        guard let groupIndex = snapshot.subscriptions[subscriptionIndex].proxyGroups.firstIndex(where: {
            $0.name == groupName
        }) else { return }
        snapshot.subscriptions[subscriptionIndex].proxyGroups[groupIndex].selected = selected
        runningProfileSnapshot = snapshot
        updatePendingRuntimeChanges()
    }

    func selectSubscriptionMember(
        subscriptionID: String,
        groupName: String,
        selected: String,
        completion: ((Result<Void, Error>) -> Void)? = nil
    ) {
        guard canChangeSubscriptionSelection else {
            completion?(.failure(TunnelRuntimeError.unavailable))
            return
        }
        guard updateSubscriptionSelection(
            subscriptionID: subscriptionID,
            groupName: groupName,
            selected: selected
        ) else {
            completion?(.failure(TunnelRuntimeError.missingTarget))
            return
        }
        guard isConnected else {
            completion?(.success(()))
            return
        }
        engine.selectSubscriptionMember(
            profileJSON: buildProfileJSON(),
            subscriptionID: subscriptionID,
            groupName: groupName,
            memberName: selected
        ) { [weak self] result in
            guard let self else { return }
            switch result {
            case .success:
                self.markSubscriptionSelectionApplied(
                    subscriptionID: subscriptionID,
                    groupName: groupName,
                    selected: selected
                )
            case .failure(let error):
                self.engine.lastError = userFacingConnectionText(error.localizedDescription)
            }
            completion?(result)
        }
    }

    /// Selector choices are runtime controls, not topology edits. They remain
    /// available for an established tunnel and are persisted as the next
    /// connection's default; all structural subscription edits stay locked.
    private var canChangeSubscriptionSelection: Bool {
        !isBusy && (!hasActiveTunnel || isConnected)
    }

    func testSubscriptionNode(
        subscriptionID: String,
        nodeID: String,
        completion: @escaping (Result<Int, Error>) -> Void
    ) {
        guard isConnected,
              let subscription = profile.subscriptions.first(where: { $0.id == subscriptionID }),
              subscription.lines.contains(where: { $0.id == nodeID }) else {
            completion(.failure(TunnelRuntimeError.unavailable))
            return
        }
        engine.testSubscriptionNode(
            profileJSON: buildProfileJSON(),
            subscriptionID: subscriptionID,
            nodeID: nodeID,
            testURL: subscription.testURL,
            completion: completion
        )
    }

    func probeSubscriptionNodeAddress(
        subscriptionID: String,
        nodeID: String,
        completion: @escaping (Result<String, Error>) -> Void
    ) {
        guard isConnected,
              let subscription = profile.subscriptions.first(where: { $0.id == subscriptionID }),
              subscription.lines.contains(where: { $0.id == nodeID }) else {
            completion(.failure(TunnelRuntimeError.unavailable))
            return
        }
        engine.probeSubscriptionNodeAddress(
            profileJSON: buildProfileJSON(),
            subscriptionID: subscriptionID,
            nodeID: nodeID,
            completion: completion
        )
    }

    static func tailscaleEndpointTag(lineID: String) -> String {
        "tailscale-" + lineID
    }

    /// `action-required` 只说明至少一条 Tailscale endpoint 需要授权。逐条读取
    /// LocalAPI 状态后再生成登录入口，避免把同一场景里已经 Running 的线路也误报。
    private func refreshRuntimeTailscaleAuthRequests() {
        tailscaleAuthRefreshGeneration &+= 1
        let generation = tailscaleAuthRefreshGeneration
        let lines = (runningProfileSnapshot?.lines ?? profile.lines).filter {
            $0.enabled && $0.type == "tailscale"
        }
        // 查询失败时保留候选入口，不能让用户在 action-required 状态下无处继续；
        // 成功读到 Running 后会立即从列表移除。
        runtimeTailscaleNeedsLoginIDs = Set(lines.map(\.id))

        for line in lines {
            engine.tailscaleStatus(
                endpointTag: Self.tailscaleEndpointTag(lineID: line.id)
            ) { [weak self] result in
                Task { @MainActor in
                    guard let self,
                          self.tailscaleAuthRefreshGeneration == generation,
                          self.observedEngineStatus == "action-required" else {
                        return
                    }
                    guard case .success(let status) = result else { return }
                    let normalized = status.backendState.lowercased()
                    if normalized == "running" {
                        self.runtimeTailscaleNeedsLoginIDs.remove(line.id)
                    } else if [
                        "needslogin",
                        "needs_login",
                        "needsmachineauth",
                        "needs_machine_auth",
                    ].contains(normalized) {
                        self.runtimeTailscaleNeedsLoginIDs.insert(line.id)
                    }
                    _ = self.applyTailscaleRuntimeStatus(
                        lineID: line.id,
                        status: status
                    )
                }
            }
        }
    }

    /// 主 App 用无 TUN 的独立 Libbox 实例完成登录和节点发现。它只运行目标
    /// Tailscale endpoint 与 Direct，不改变系统连接状态，也不执行正式场景。
    func prepareTailscaleLogin(
        lineID: String,
        completion: @escaping @Sendable (Result<Void, Error>) -> Void
    ) {
        guard canStartTailscaleSetup(lineID: lineID),
              let tailscaleSetupRuntime,
              let line = profile.lines.first(where: {
                  $0.id == lineID && $0.type == "tailscale"
              }) else {
            completion(.failure(TunnelRuntimeError.unavailable))
            return
        }
        guard save() else {
            completion(.failure(NSError(
                domain: "XDial",
                code: -40,
                userInfo: [NSLocalizedDescriptionKey: tr(
                    "保存线路失败，未启动 Tailscale 设置。",
                    "Tailscale setup was not started because the line could not be saved."
                )]
            )))
            return
        }
        tailscaleSetupLineID = lineID
        tailscaleSetupGeneration &+= 1
        let generation = tailscaleSetupGeneration
        persistence.defaults.set(lineID, forKey: persistence.tailscaleSetupLineKey)
        persistence.defaults.synchronize()

        // 正式隧道已经稳定运行且没有生成目标 lineID 时，两者使用不同的 state
        // directory，可以并存；离线设置才需要先取得系统按需接管的暂停租约。
        tailscaleSetupOwnsOnDemandSuspension = !hasFormalTunnel
        let startRuntime = { [weak self] in
            guard let self,
                  self.tailscaleSetupGeneration == generation,
                  self.tailscaleSetupLineID == lineID else {
                completion(.failure(CancellationError()))
                return
            }
            tailscaleSetupRuntime.start(
                profileJSON: self.buildProfileJSON(),
                lineID: line.id
            ) { [weak self] result in
                guard let self else { return }
                guard self.tailscaleSetupGeneration == generation,
                      self.tailscaleSetupLineID == lineID else {
                    completion(.failure(CancellationError()))
                    return
                }
                switch result {
                case .success(let status):
                    if self.applyTailscaleRuntimeStatus(
                        lineID: lineID,
                        status: status
                    ) {
                        completion(.success(()))
                    } else {
                        let error = NSError(
                            domain: "XDial",
                            code: -42,
                            userInfo: [NSLocalizedDescriptionKey: self.tr(
                                "Tailscale 登录状态无法保存。",
                                "The Tailscale sign-in state could not be saved."
                            )]
                        )
                        self.engine.lastError = error.localizedDescription
                        self.stopTailscaleSetup {
                            completion(.failure(error))
                        }
                    }
                case .failure(let error):
                    self.engine.lastError = error.localizedDescription
                    self.stopTailscaleSetup {
                        completion(.failure(error))
                    }
                }
            }
        }
        if tailscaleSetupOwnsOnDemandSuspension, let tunnelManager {
            tailscaleSetupSuspensionPending = true
            tunnelManager.setSystemOnDemandSuspendedForSetup(true) {
                self.tailscaleSetupSuspensionPending = false
                guard self.tailscaleSetupGeneration == generation,
                      self.tailscaleSetupLineID == lineID else {
                    if self.isStoppingTailscaleSetup {
                        self.completeTailscaleSetupStop()
                    }
                    completion(.failure(CancellationError()))
                    return
                }
                startRuntime()
            }
        } else {
            startRuntime()
        }
    }

    /// App 将被系统挂起。独立设置的 Libbox 在 App Group 共享容器里持有 Tailscale 状态锁，
    /// 挂起时仍持有会被 RunningBoard 以 0xdead10cc 结束进程。先停掉设置（释放锁），记下线路，
    /// 回到前台再由 resumeTailscaleSetupAfterBackground 接着做。没有设置在跑时直接完成。
    func pauseTailscaleSetupForBackground(completion: @escaping () -> Void) {
        // An explicit finish may already be releasing the lock. Join that stop
        // without marking the user-finished setup for automatic resumption.
        if isStoppingTailscaleSetup {
            stopTailscaleSetup(completion: completion)
            return
        }
        guard let lineID = tailscaleSetupLineID else {
            completion()
            return
        }
        backgroundPausedTailscaleSetupLineID = lineID
        appLog("tailscale setup paused before suspension; releasing its state lock")
        stopTailscaleSetup(completion: completion)
    }

    /// 回到前台：接着做被后台打断的设置。用户已开始别的设置、线路已删除或正式连接接管时不恢复。
    func resumeTailscaleSetupAfterBackground() {
        // The lifecycle guard retries after stop only if the app is still active.
        // Do not enqueue a resume here: another background transition can invalidate it.
        guard !isStoppingTailscaleSetup,
              let lineID = backgroundPausedTailscaleSetupLineID else { return }
        backgroundPausedTailscaleSetupLineID = nil
        guard canStartTailscaleSetup(lineID: lineID) else {
            appLog("tailscale setup not resumed after background: setup no longer applies")
            return
        }
        prepareTailscaleLogin(lineID: lineID) { [weak self] result in
            Task { @MainActor [weak self] in
                guard let self, case .success = result, self.tailscaleSetupLineID == lineID else { return }
                self.resumedTailscaleSetupLineID = lineID
            }
        }
    }

    /// 配置页已接手恢复后的设置。
    func acknowledgeResumedTailscaleSetup() {
        resumedTailscaleSetupLineID = nil
    }

    /// 用户明确结束或取消设置。后台暂停期间的停止尚未完成时也算数：回到前台不再自动恢复。
    func finishTailscaleSetup(completion: (() -> Void)? = nil) {
        backgroundPausedTailscaleSetupLineID = nil
        stopTailscaleSetup(completion: completion)
    }

    /// 停下设置并释放状态锁，不改变是否在回到前台后恢复。
    private func stopTailscaleSetup(completion: (() -> Void)? = nil) {
        if let completion {
            tailscaleSetupFinishCompletions.append(completion)
        }
        guard !isStoppingTailscaleSetup else { return }
        guard tailscaleSetupLineID != nil else {
            completeTailscaleSetupFinish()
            return
        }
        isStoppingTailscaleSetup = true
        tailscaleSetupGeneration &+= 1
        // 暂停租约尚未确认时不能立刻恢复，否则两次 saveToPreferences 会倒序。
        guard !tailscaleSetupSuspensionPending else { return }
        guard let tailscaleSetupRuntime else {
            completeTailscaleSetupStop()
            return
        }
        tailscaleSetupRuntime.stop { [weak self] in
            self?.completeTailscaleSetupStop()
        }
    }

    private func completeTailscaleSetupStop() {
        tailscaleSetupLineID = nil
        persistence.defaults.removeObject(forKey: persistence.tailscaleSetupLineKey)
        persistence.defaults.synchronize()
        updatePendingRuntimeChanges()
        let shouldResumeOnDemand = tailscaleSetupOwnsOnDemandSuspension
        tailscaleSetupOwnsOnDemandSuspension = false
        let finish = { [weak self] in
            guard let self else { return }
            self.isStoppingTailscaleSetup = false
            self.completeTailscaleSetupFinish()
        }
        if shouldResumeOnDemand, let tunnelManager {
            tunnelManager.setSystemOnDemandSuspendedForSetup(false) {
                finish()
            }
        } else {
            finish()
        }
    }

    private func completeTailscaleSetupFinish() {
        let completions = tailscaleSetupFinishCompletions
        tailscaleSetupFinishCompletions.removeAll()
        completions.forEach { $0() }
    }

    static func validTailscaleAuthURL(_ rawValue: String) -> URL? {
        guard let components = URLComponents(string: rawValue),
              components.scheme?.lowercased() == "https",
              let host = components.host, !host.isEmpty else { return nil }
        return components.url
    }

    func canStartTailscaleSetup(lineID: String) -> Bool {
        guard !isBusy,
              tailscaleSetupLineID == nil,
              tailscaleSetupRuntime?.isActive != true,
              profile.lines.contains(where: {
                  $0.id == lineID && $0.type == "tailscale"
              }) else { return false }
        if !hasFormalTunnel { return true }
        return isConnected && !isTailscaleLineGeneratedByFormalTunnel(lineID)
    }

    func canQueryTailscaleRuntime(lineID: String) -> Bool {
        if isTailscaleSetupActive && tailscaleSetupLineID == lineID {
            return true
        }
        return hasFormalTunnel && isTailscaleLineGeneratedByFormalTunnel(lineID)
    }

    func isTailscaleLineGeneratedByFormalTunnel(_ lineID: String) -> Bool {
        guard let runningProfileSnapshot else { return false }
        return runningProfileSnapshot.lines.contains {
            $0.id == lineID && $0.enabled && $0.type == "tailscale"
        }
    }

    func isTailscaleLineGeneratedByRunningProfile(_ lineID: String) -> Bool {
        if isTailscaleSetupActive {
            return tailscaleSetupLineID == lineID
        }
        return isTailscaleLineGeneratedByFormalTunnel(lineID)
    }

    func refreshTailscaleStatus(
        lineID: String,
        completion: @escaping (Result<TailscaleRuntimeStatus, Error>) -> Void
    ) {
        guard canQueryTailscaleRuntime(lineID: lineID) else {
            completion(.failure(TunnelRuntimeError.unavailable))
            return
        }
        if tailscaleSetupLineID == lineID, let tailscaleSetupRuntime {
            tailscaleSetupRuntime.status(lineID: lineID, completion: completion)
            return
        }
        engine.tailscaleStatus(
            endpointTag: Self.tailscaleEndpointTag(lineID: lineID),
            completion: completion
        )
    }

    func beginTailscaleLogin(
        lineID: String,
        completion: @escaping (Result<TailscaleRuntimeStatus, Error>) -> Void
    ) {
        if tailscaleSetupLineID == lineID,
           isTailscaleSetupActive,
           let tailscaleSetupRuntime {
            tailscaleSetupRuntime.beginLogin(lineID: lineID, completion: completion)
            return
        }
        guard hasFormalTunnel,
              isTailscaleLineGeneratedByFormalTunnel(lineID) else {
            completion(.failure(TunnelRuntimeError.unavailable))
            return
        }
        engine.beginTailscaleLogin(
            endpointTag: Self.tailscaleEndpointTag(lineID: lineID),
            completion: completion
        )
    }

    func logoutTailscale(
        lineID: String,
        completion: @escaping (Result<Void, Error>) -> Void
    ) {
        guard tailscaleSetupLineID == lineID,
              isTailscaleSetupActive,
              let tailscaleSetupRuntime,
              profile.lines.contains(where: {
                  $0.id == lineID && $0.type == "tailscale"
              }),
              save() else {
            completion(.failure(TunnelRuntimeError.unavailable))
            return
        }
        tailscaleSetupRuntime.logout(lineID: lineID) { [weak self] result in
            guard let self else { return }
            switch result {
            case .failure(let error):
                completion(.failure(error))
            case .success:
                guard let index = self.profile.lines.firstIndex(where: {
                    $0.id == lineID && $0.type == "tailscale"
                }) else {
                    completion(.failure(TunnelRuntimeError.missingTarget))
                    return
                }
                self.profile.lines[index].tailscaleAuthenticated = false
                self.profile.lines[index].tailscaleExitNode = ""
                self.profile.lines[index].verified = false
                guard self.save() else {
                    completion(.failure(NSError(
                        domain: "XDial",
                        code: -43,
                        userInfo: [NSLocalizedDescriptionKey: self.tr(
                            "已退出 Tailscale，但本地状态无法保存。",
                            "Tailscale signed out, but the local state could not be saved."
                        )]
                    )))
                    return
                }
                completion(.success(()))
            }
        }
    }

    /// Exit-node selection is a persisted runtime choice. It may change while
    /// fully connected so the UI can offer an explicit reconnect-to-apply
    /// workflow, but remains locked while the tunnel is starting/stopping or
    /// waiting for first-time Tailscale sign-in.
    @discardableResult
    func updateTailscaleExitSelection(lineID: String, selected: String) -> Bool {
        let isSetupTarget = isTailscaleSetupActive && tailscaleSetupLineID == lineID
        guard !isBusy,
              isSetupTarget || (!hasActiveTunnel || isConnected),
              let index = profile.lines.firstIndex(where: {
                  $0.id == lineID && $0.type == "tailscale"
              }),
              profile.lines[index].enabled || isSetupTarget else { return false }
        guard profile.lines[index].tailscaleExitNode != selected else { return true }
        // 旧版本只用 verified 记录“这条线路曾成功登录并跑通”。首次升级后修改
        // 出口节点会清除数据面验收结果，但不能同时丢掉已经完成的登录事实。
        if profile.lines[index].verified && !profile.lines[index].tailscaleAuthenticated {
            profile.lines[index].tailscaleAuthenticated = true
        }
        profile.lines[index].tailscaleExitNode = selected
        profile.lines[index].verified = false
        return save()
    }

    @discardableResult
    func updateTailscaleAuthentication(lineID: String, authenticated: Bool) -> Bool {
        guard let index = profile.lines.firstIndex(where: {
            $0.id == lineID && $0.type == "tailscale"
        }) else { return false }
        guard profile.lines[index].tailscaleAuthenticated != authenticated else {
            return true
        }
        profile.lines[index].tailscaleAuthenticated = authenticated
        return save()
    }

    @discardableResult
    func applyTailscaleRuntimeStatus(
        lineID: String,
        status: TailscaleRuntimeStatus
    ) -> Bool {
        let normalized = status.backendState.lowercased()
        if normalized == "running" {
            return updateTailscaleAuthentication(lineID: lineID, authenticated: true)
        }
        if normalized == "needslogin"
            || normalized == "needs_login"
            || normalized == "needsmachineauth"
            || normalized == "needs_machine_auth" {
            return updateTailscaleAuthentication(lineID: lineID, authenticated: false)
        }
        return true
    }

    func deleteSubscription(_ id: String) {
        guard canMutateConfiguration else { return }
        profile.subscriptions.removeAll { $0.id == id }
        // 保留场景里的悬空引用，让连接前校验明确报错；静默删除绑定或改为直连会改变路由语义。
        save()
    }

    // MARK: - Scenario Management

    func createScenario(from template: ScenarioTemplate, named name: String) {
        guard canMutateConfiguration, canCreateScenario(from: template) else { return }
        let direct = profile.lines.first(where: { $0.type == "direct" && isUsableRouteLine($0) })?.id ?? ""
        let vpn = profile.lines.first(where: { $0.type == "vpn" && isUsableRouteLine($0) })?.id ?? ""
        let ss = profile.lines.first(where: {
            $0.type != "direct" && $0.type != "vpn" && isUsableRouteLine($0)
        })?.id ?? ""

        let manualRules = profile.ruleSets
            .filter { $0.type == "manual" && $0.enabled && !$0.isConnectivityTestRule }
            .map { $0.id }
        let remoteRuleSet = profile.ruleSets
            .first(where: { $0.type == "url" && $0.enabled })?.id ?? ""

        var s: Scenario
        switch template {
        case .overseas:
            s = Profile.templateOverseas(
                ruleSetIDs: manualRules,
                vpnLineID: vpn,
                directLineID: direct
            )
        case .domestic:
            s = Profile.templateDomestic(
                ruleSetIDs: manualRules,
                remoteRuleSetID: remoteRuleSet,
                vpnLineID: vpn,
                directLineID: direct
            )
        case .domesticSS:
            s = Profile.templateDomesticSS(
                ruleSetIDs: manualRules,
                remoteRuleSetID: remoteRuleSet,
                vpnLineID: vpn,
                ssLineID: ss,
                directLineID: direct
            )
        case .blank:
            s = Scenario(id: UUID().uuidString, name: name, defaultLineID: direct)
        }
        s.name = name
        profile.scenarios.append(s)
        if profile.activeScenarioID.isEmpty {
            profile.activeScenarioID = s.id
        }
        save()
    }

    func deleteScenario(_ s: Scenario) {
        guard canMutateConfiguration else { return }
        profile.scenarios.removeAll { $0.id == s.id }
        if profile.activeScenarioID == s.id {
            profile.activeScenarioID = profile.scenarios.first?.id ?? ""
        }
        save()
    }

    // MARK: - Build profile JSON

    func buildProfileJSON() -> String {
        guard let data = try? JSONEncoder().encode(profile) else { return "{}" }
        return String(data: data, encoding: .utf8) ?? "{}"
    }
}

// MARK: - Noop engine (占位默认引擎)
//
// 在真实引擎层注入之前，AppState 需要一个满足 TunnelEngine 的默认引擎，
// 保证状态机语义完整（能读 status、start/stop 只切状态、不做真实拨号）。
// 并行引擎任务写好后，用 AppState(engine:) 注入真实引擎替换它。
@MainActor
final class NoopTunnelEngine: TunnelEngine, ObservableObject {
    @Published private(set) var status: String = "disconnected"
    @Published var lastError: String?
    @Published var dataPathSummary: String?
    var statusPublisher: AnyPublisher<String, Never> { $status.eraseToAnyPublisher() }

    var isConnected: Bool { status == "connected" }
    var isBusy: Bool { status == "connecting" || status == "disconnecting" || status == "reconnecting" }

    func start(profileJSON: String) {
        // TODO: 真实引擎接入后由具体实现完成拨号；占位仅记录调用点。
        appLog("NoopTunnelEngine.start called (\(profileJSON.count) bytes) — no real engine bound")
    }

    func stop() {
        appLog("NoopTunnelEngine.stop called — no real engine bound")
    }

    func syncStatus() {
        // 占位：真实引擎会查询扩展/NEVPNManager 的当前状态并回填 status。
    }
}

enum ScenarioTemplate: String, CaseIterable {
    case overseas, domestic, domesticSS, blank

    var displayName: String {
        switch self {
        case .overseas: return "海外"
        case .domestic: return "国内"
        case .domesticSS: return "国内+SS"
        case .blank: return "空白"
        }
    }
}

#if os(iOS)
// MARK: - 隧道内场景切换（iOS）

/// 请 VPN 扩展判断的结果。
enum TunnelScenarioEvaluationResult: Equatable {
    case handled
    /// 扩展是旧版本：调用方自己判断，必要时断开重连。
    case unsupported
    /// 没连接，或扩展暂时没有回应：这次什么也不做。
    case unavailable
}

/// 一次在隧道内切换场景的结果。
enum InTunnelScenarioSwitchResult: Equatable {
    case switched
    case failed
    /// 没连接、没有扩展，或扩展是旧版本：调用方改用断开重连。
    case unavailable
}

extension AppState {
    /// 连接成功后，为可能被自动选中的场景生成启动包，交给 VPN 扩展备用。
    func refreshScenarioCatalog() {
        guard let tunnelManager, let snapshot = runningProfileSnapshot,
              let policy = scenarioAutoPolicyProvider?(snapshot) else { return }
        let inputs = scenarioCatalogInputs(base: snapshot, policy: policy)
        scenarioCatalogTask?.cancel()
        scenarioCatalogTask = Task { @MainActor [weak self] in
            _ = await tunnelManager.rebuildScenarioCatalog(inputs: inputs, policy: policy, keepingOthers: false)
            guard !Task.isCancelled, let self else { return }
            self.scenarioCatalogTask = nil
            // 刚连上（含 App 冷启动时隧道已在运行、系统自动连回）：目录就绪后请扩展按当前网络判断一次。
            // 连接前 App 自己的判断可能没查到出口，或者网络在连接期间变了。
            if self.scenarioAutoPolicyProvider?(snapshot).enabled == true {
                _ = await self.requestTunnelScenarioEvaluation()
            } else {
                await self.refreshTunnelScenarioState()
            }
        }
    }

    /// 「自动」开关变了：扩展马上按新规则行事，关掉以后不会再自动切换。
    func updateScenarioAutoPolicy() {
        guard let tunnelManager,
              let policy = scenarioAutoPolicyProvider?(runningProfileSnapshot ?? profile) else { return }
        _ = tunnelManager.updateScenarioCatalogPolicy(policy)
    }

    /// 已连接时不断开系统 VPN 地切换场景。尚未应用的配置改动随新场景一起生效。
    func switchScenarioInTunnel(to id: String) async -> InTunnelScenarioSwitchResult {
        guard let tunnelManager, isConnected, runningProfileSnapshot != nil,
              !isSwitchingScenarioInTunnel,
              let policy = scenarioAutoPolicyProvider?(profile) else { return .unavailable }
        guard let scenario = profile.scenarios.first(where: { $0.id == id }) else { return .failed }
        let issues = configurationIssues(for: scenario)
        guard issues.isEmpty else {
            engine.lastError = issues.prefix(3).joined(separator: tr("；", "; "))
            return .failed
        }
        isSwitchingScenarioInTunnel = true
        defer { isSwitchingScenarioInTunnel = false }
        let base = profile
        scenarioCatalogTask?.cancel()
        scenarioCatalogTask = nil
        // 先只生成目标场景，切完再按新配置补齐其他场景。
        guard let target = scenarioCatalogInput(for: id, in: base),
              let revision = await tunnelManager.rebuildScenarioCatalog(
                  inputs: [target], policy: policy, keepingOthers: true
              ) else {
            engine.lastError = tr("无法准备新场景的连接配置", "Couldn't prepare the new scenario")
            return .failed
        }
        switch await tunnelManager.requestScenarioSwitch(to: id, revision: revision, reapply: runningProfileSnapshot?.activeScenarioID == id) {
        case .switched(let state):
            engine.lastError = nil
            adoptTunnelScenario(state, base: base)
            refreshScenarioCatalog()
            return .switched
        case .failed(let message, let state):
            if let state { tunnelScenarioState = state }
            engine.lastError = userFacingConnectionText(message)
            return .failed
        case .unsupported:
            return .unavailable
        }
    }

    /// App 回到前台、打开「自动」或网络变化时：请扩展按当前网络判断一次。
    /// 用户确认数据使用说明之前不请扩展判断：判断可能查询出口地区。确认后首页会重新判断一次。
    func requestTunnelScenarioEvaluation() async -> TunnelScenarioEvaluationResult {
        guard dataUseNoticeAccepted, isConnected, let tunnelManager else { return .unavailable }
        switch await tunnelManager.requestScenarioEvaluation() {
        case .evaluated(let state):
            adoptTunnelScenario(state, base: nil)
            return .handled
        case .unsupported:
            return .unsupported
        case .unavailable:
            return .unavailable
        }
    }

    /// 扩展通知场景状态变了，或 App 刚回到前台：向扩展读一次并同步。
    func refreshTunnelScenarioState() async {
        guard isConnected, let tunnelManager,
              let state = await tunnelManager.requestScenarioState() else { return }
        adoptTunnelScenario(state, base: nil)
    }

    /// 把扩展正在运行的场景同步到 Profile 与运行快照，并改用新场景的验收计划。
    private func adoptTunnelScenario(_ state: TunnelScenarioState, base: Profile?) {
        tunnelScenarioState = state
        guard isConnected, let running = state.runningScenarioID,
              profile.scenarios.contains(where: { $0.id == running }) else { return }
        let snapshotScenario = runningProfileSnapshot?.activeScenarioID
        if var snapshot = base ?? runningProfileSnapshot {
            snapshot.activeScenarioID = running
            runningProfileSnapshot = snapshot
        }
        if profile.activeScenarioID != running {
            profile.activeScenarioID = running
            save()
        }
        updatePendingRuntimeChanges()
        if base != nil || snapshotScenario != running {
            tunnelManager?.adoptSwitchedScenario(running)
        }
    }

    /// 目录里放哪些场景：当前场景、登记了 Wi-Fi 的场景、地区表里的场景。
    private func scenarioCatalogInputs(
        base: Profile,
        policy: ScenarioAutoPolicy
    ) -> [ScenarioCatalogInput] {
        var ids: [String] = []
        func add(_ id: String) {
            guard !id.isEmpty, !ids.contains(id), base.scenarios.contains(where: { $0.id == id }) else { return }
            ids.append(id)
        }
        add(base.activeScenarioID)
        policy.wifiRules.forEach { add($0.scenarioID) }
        policy.regionScenarios.values.sorted().forEach(add)
        return ids.prefix(ScenarioSwitchCatalog.maxEntries).compactMap {
            scenarioCatalogInput(for: $0, in: base)
        }
    }

    private func scenarioCatalogInput(for scenarioID: String, in base: Profile) -> ScenarioCatalogInput? {
        guard let scenario = base.scenarios.first(where: { $0.id == scenarioID }),
              configurationIssues(for: scenario).isEmpty else { return nil }
        var candidate = base
        candidate.activeScenarioID = scenarioID
        let referenced = effectiveReferencedLineIDs(in: scenario)
        let anyConnectLines = candidate.lines.filter {
            referenced.contains($0.id) && $0.enabled && $0.type == "vpn"
        }
        var anyConnect: AnyConnectCredentials?
        var allowInsecure = false
        if !anyConnectLines.isEmpty {
            guard anyConnectLines.count == 1, let line = anyConnectLines.first,
                  isUsableRouteLine(line) else { return nil }
            anyConnect = AnyConnectCredentials(
                server: line.vpnServer,
                username: line.vpnUsername,
                password: line.vpnPassword
            )
            allowInsecure = line.allowInsecure
        }
        guard let data = try? JSONEncoder().encode(candidate),
              let profileJSON = String(data: data, encoding: .utf8),
              let plan = try? TunnelAcceptancePlan.make(
                  profile: candidate, profileJSON: profileJSON, anyConnect: anyConnect
              ),
              let planData = try? JSONEncoder().encode(plan),
              let planJSON = String(data: planData, encoding: .utf8) else { return nil }
        _ = BundledRuleSets.seedCache(
            for: candidate,
            basePath: FileManager.default
                .containerURL(forSecurityApplicationGroupIdentifier: XDialIdentity.appGroup)?.path ?? ""
        )
        return ScenarioCatalogInput(
            scenarioID: scenarioID,
            scenarioName: scenario.name,
            profileJSON: profileJSON,
            anyConnect: anyConnect,
            allowInsecure: allowInsecure,
            acceptancePlanJSON: planJSON
        )
    }
}
#endif
