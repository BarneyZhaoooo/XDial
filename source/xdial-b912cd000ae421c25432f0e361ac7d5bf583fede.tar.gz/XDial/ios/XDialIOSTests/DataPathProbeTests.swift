import XCTest
@testable import XDial

final class DataPathProbeTests: XCTestCase {
    func testAlternateHTTPSAttributionRequiresExclusiveCounterGrowth() {
        func snapshot(_ direct: Int64, _ other: Int64) -> RoutingProbeSnapshot {
            RoutingProbeSnapshot(directTargetDirect: 0, directTargetVPN: 0, directTargetOther: 0,
                                 anyConnectTargetDirect: 0, anyConnectTargetVPN: 0, anyConnectTargetOther: 0,
                                 alternateHTTPSDirect: direct, alternateHTTPSOther: other)
        }
        let before = snapshot(3, 2)
        XCTAssertEqual(before.alternateHTTPSRoute(after: snapshot(4, 2)), "direct")
        XCTAssertEqual(before.alternateHTTPSRoute(after: snapshot(3, 3)), "other")
        for after in [before, snapshot(4, 3), snapshot(0, 0)] {
            XCTAssertEqual(before.alternateHTTPSRoute(after: after), "unknown")
        }
    }

    func testTLSFailuresKeepNumericEvidenceWithoutErrorDescription() {
        let error = URLError(.serverCertificateUntrusted)
        let check = DataPathProbe.CheckRecord.failed(error, since: ProcessInfo.processInfo.systemUptime)
        XCTAssertEqual(check.result, .tls)
        XCTAssertEqual(check.urlErrorCode, NSURLErrorServerCertificateUntrusted)
    }

    func testSnapshotReadDistinguishesMissingRejectedAndMalformedReplies() {
        typealias Read = TunnelManager.SnapshotRead
        XCTAssertEqual(Read.decode(nil).detail, "扩展返回空回包")
        XCTAssertEqual(Read.decode(Data("!".utf8)).detail, "扩展回包格式异常")
        XCTAssertEqual(Read.decode(Data("{}".utf8)).detail, "扩展回包缺少状态")
        XCTAssertEqual(Read.decode(Data(#"{"ok":false,"message":"private"}"#.utf8)).detail, "扩展报告读取失败")
        XCTAssertEqual(Read.decode(Data(#"{"ok":true,"data":"{}"}"#.utf8)).detail, "计数数据格式异常")
    }

    func testBackgroundConnectionDefersInitialAndRepeatedProbesUntilForeground() {
        var policy = DataPathRecheckPolicy(isActive: false)
        XCTAssertTrue(policy.shouldDeferProbe)
        policy.markDegraded() // connected arrives while the app is already in background
        XCTAssertNil(policy.nextDelay)
        XCTAssertFalse(policy.beginScheduledRecheck())
        policy.becameActive()
        XCTAssertFalse(policy.shouldDeferProbe)
        XCTAssertEqual(policy.nextDelay, 30)
        policy.enteredBackground()
        XCTAssertTrue(policy.shouldDeferProbe)
        XCTAssertFalse(policy.beginScheduledRecheck())
        XCTAssertEqual(policy.attempts, 0)
    }

    func testOnlyStartedRetriesConsumeBudgetAndStopAfterThree() {
        var policy = DataPathRecheckPolicy(isActive: true)
        policy.markDegraded()
        for delay: UInt64 in [30, 120, 300] {
            XCTAssertEqual(policy.nextDelay, delay)
            // Reading / scheduling / cancelling a wait never consumes a retry.
            XCTAssertEqual(policy.nextDelay, delay)
            XCTAssertTrue(policy.beginScheduledRecheck())
        }
        XCTAssertNil(policy.nextDelay)
        XCTAssertFalse(policy.beginScheduledRecheck())
        XCTAssertEqual(policy.attempts, 3)
        policy.becameActive()
        XCTAssertEqual(policy.attempts, 0)
        XCTAssertEqual(policy.nextDelay, 30)
    }

    func testBackgroundAndDisconnectResetRetryBudget() {
        var policy = DataPathRecheckPolicy(isActive: true)
        policy.markDegraded()
        XCTAssertTrue(policy.beginScheduledRecheck())
        policy.enteredBackground()
        XCTAssertNil(policy.nextDelay)
        XCTAssertFalse(policy.beginScheduledRecheck())
        XCTAssertEqual(policy.attempts, 1)
        policy.becameActive()
        XCTAssertEqual(policy.nextDelay, 30)
        XCTAssertTrue(policy.beginScheduledRecheck())
        policy.clearDegraded() // disconnect or successful verification cancels pending work
        XCTAssertEqual(policy.attempts, 0)
        XCTAssertNil(policy.nextDelay)
        XCTAssertFalse(policy.beginScheduledRecheck())
        policy.becameActive()
        XCTAssertNil(policy.nextDelay) // foreground cannot revive a disconnected connection
        policy.markDegraded() // only a new connected verification failure can enable retries
        XCTAssertEqual(policy.nextDelay, 30)
    }

    func testStandaloneAcceptancePlanUsesVisibleCurrentRouteBinding() throws {
        var profile = Profile.bootstrap()
        profile.lines.append(Line(
            id: "proxy-one",
            name: "Proxy One",
            type: "trojan",
            trojanServer: "proxy.example.com",
            trojanPassword: "secret"
        ))
        profile.scenarios = [Scenario(id: "proxy", name: "Proxy", defaultLineID: "proxy-one")]
        profile.activeScenarioID = "proxy"
        profile.ensureConnectivityTestConfiguration()
        let data = try JSONEncoder().encode(profile)
        let json = try XCTUnwrap(String(data: data, encoding: .utf8))

        let plan = try TunnelAcceptancePlan.make(
            profile: profile,
            profileJSON: json,
            anyConnect: nil
        )

        XCTAssertFalse(plan.requiresAnyConnect)
        XCTAssertEqual(plan.currentRouteTag, "proxy-proxy-one")
        XCTAssertEqual(Set(plan.targets.map(\.tag)), Set(["direct", "proxy-proxy-one"]))
    }

    func testAnyConnectAcceptancePlanPreservesTwoLineContract() throws {
        var profile = Profile.bootstrap()
        profile.lines[1].vpnServer = "gateway.example.com"
        profile.lines[1].vpnUsername = "user"
        profile.lines[1].vpnPassword = "secret"
        profile.scenarios = [Scenario(id: "ac", name: "AC", defaultLineID: "vpn")]
        profile.activeScenarioID = "ac"
        profile.ensureConnectivityTestConfiguration()
        let data = try JSONEncoder().encode(profile)
        let json = try XCTUnwrap(String(data: data, encoding: .utf8))

        let plan = try TunnelAcceptancePlan.make(
            profile: profile,
            profileJSON: json,
            anyConnect: AnyConnectCredentials(
                server: "gateway.example.com",
                username: "user",
                password: "secret"
            )
        )

        XCTAssertTrue(plan.requiresAnyConnect)
        XCTAssertEqual(plan.currentRouteTag, "vpn")
        XCTAssertEqual(Set(plan.targets.map(\.tag)), Set(["direct", "vpn"]))

        let result = ConfiguredDataPathResult(
            targetAddresses: [
                "direct": "198.51.100.1",
                "vpn": "203.0.113.2",
            ],
            targets: plan.targets,
            unavailableTargets: [],
            routedDirectEgressIP: "198.51.100.1",
            routedCurrentEgressIP: "203.0.113.2",
            hostnameOK: true,
            routingEvidenceOK: true,
            currentRouteTag: plan.currentRouteTag
        )
        XCTAssertTrue(result.diagnosticSummary.contains("AnyConnect"))
        XCTAssertFalse(result.diagnosticSummary.lowercased().contains("vpn"))
        let report = MobileDiagnosticsService.report(
            version: "test",
            status: "Connected",
            systemProfileInstalled: true,
            profile: profile,
            lastError: nil,
            dataPathSummary: result.diagnosticSummary,
            isChinese: false
        )
        XCTAssertFalse(report.lowercased().contains("vpn"))
    }

    func testMixedAcceptancePlanChecksEveryReferencedOutletAndKeepsDefaultRoute() throws {
        var profile = Profile.bootstrap()
        profile.lines[1].vpnServer = "gateway.example.com"
        profile.lines[1].vpnUsername = "user"
        profile.lines[1].vpnPassword = "secret"
        profile.lines.append(Line(
            id: "proxy-one",
            name: "Proxy",
            type: "trojan",
            trojanServer: "proxy.example.com",
            trojanPassword: "secret"
        ))
        profile.ruleSets.append(RuleSet(
            id: "proxy-rule",
            name: "Proxy Rule",
            type: "manual",
            domains: ["example.com"]
        ))
        profile.scenarios = [Scenario(
            id: "mixed",
            name: "Mixed",
            bindings: [
                RuleBinding(ruleSetID: "internal", lineID: "vpn"),
                RuleBinding(ruleSetID: "proxy-rule", lineID: "proxy-one"),
            ],
            defaultLineID: "direct"
        )]
        profile.activeScenarioID = "mixed"
        profile.ensureConnectivityTestConfiguration()
        let data = try JSONEncoder().encode(profile)
        let json = try XCTUnwrap(String(data: data, encoding: .utf8))

        let plan = try TunnelAcceptancePlan.make(
            profile: profile,
            profileJSON: json,
            anyConnect: AnyConnectCredentials(
                server: "gateway.example.com",
                username: "user",
                password: "secret"
            )
        )

        XCTAssertTrue(plan.requiresAnyConnect)
        XCTAssertEqual(plan.currentRouteTag, "vpn")
        XCTAssertEqual(
            Set(plan.targets.map(\.tag)),
            Set(["direct", "vpn", "proxy-proxy-one"])
        )
    }

    func testPureDirectPlanMarksSplitRoutingNotApplicable() throws {
        var profile = Profile.bootstrap()
        profile.scenarios = [Scenario(id: "direct-only", name: "Direct", defaultLineID: "direct")]
        profile.activeScenarioID = "direct-only"
        profile.ensureConnectivityTestConfiguration()
        let data = try JSONEncoder().encode(profile)
        let json = try XCTUnwrap(String(data: data, encoding: .utf8))

        let plan = try TunnelAcceptancePlan.make(
            profile: profile,
            profileJSON: json,
            anyConnect: nil
        )

        XCTAssertNil(plan.currentRouteTag)
        XCTAssertEqual(plan.targets.map(\.tag), ["direct"])

        let result = ConfiguredDataPathResult(
            targetAddresses: ["direct": "198.51.100.1"],
            unavailableTargets: [],
            routedDirectEgressIP: "198.51.100.1",
            routedCurrentEgressIP: nil,
            hostnameOK: true,
            routingEvidenceOK: true,
            currentRouteTag: nil
        )
        XCTAssertTrue(result.isUsable)
        XCTAssertEqual(result.splitRoutingState, .notApplicable)
        XCTAssertTrue(result.diagnosticSummary.contains(
            "公网双出口不适用；线路与域名 HTTPS 通过，未执行双出口分流验收"
        ))
        XCTAssertFalse(result.diagnosticSummary.contains("分流通过"))
    }

    func testConfiguredRoutingUsesLineReachabilityAndRouterEvidenceSeparately() {
        let targets = [
            TunnelAcceptanceTarget(tag: "direct", label: "Direct"),
            TunnelAcceptanceTarget(tag: "vpn", label: "AnyConnect"),
        ]
        let result = ConfiguredDataPathResult(
            targetAddresses: [
                "direct": "198.51.100.1",
                "vpn": "203.0.113.2",
            ],
            targets: targets,
            unavailableTargets: [],
            routedDirectEgressIP: nil,
            routedCurrentEgressIP: "203.0.113.2",
            hostnameOK: true,
            routingEvidenceOK: true,
            currentRouteTag: "vpn"
        )

        XCTAssertTrue(result.isUsable)
        XCTAssertEqual(result.splitRoutingState, .passed)
        XCTAssertTrue(result.diagnosticSummary.contains(
            "分流规则：1.0.0.1→Direct · 1.1.1.1→AnyConnect"
        ))
        XCTAssertTrue(result.diagnosticSummary.contains("路由命中：通过"))
    }

    func testAcceptancePlanMatchesGlobalGeneratedTailscaleEndpointSemantics() throws {
        var profile = Profile.bootstrap()
        profile.lines.append(Line(
            id: "overlay",
            name: "Overlay",
            type: "tailscale"
        ))
        profile.lines.append(Line(
            id: "exit",
            name: "Exit",
            type: "tailscale",
            tailscaleExitNode: "100.64.0.8"
        ))
        profile.ruleSets.append(RuleSet(
            id: "overlay-rule",
            name: "Overlay",
            type: "manual",
            cidrs: ["100.64.0.0/10"]
        ))
        profile.scenarios = [Scenario(
            id: "direct-overlay",
            name: "Direct + Overlay",
            bindings: [RuleBinding(ruleSetID: "overlay-rule", lineID: "overlay")],
            defaultLineID: "direct"
        )]
        profile.activeScenarioID = "direct-overlay"
        profile.ensureConnectivityTestConfiguration()
        let data = try JSONEncoder().encode(profile)
        let json = try XCTUnwrap(String(data: data, encoding: .utf8))

        let plan = try TunnelAcceptancePlan.make(
            profile: profile,
            profileJSON: json,
            anyConnect: nil
        )

        XCTAssertNil(plan.currentRouteTag)
        XCTAssertEqual(plan.targets.map(\.tag), ["direct"])
        XCTAssertEqual(
            Set(plan.generatedTailscaleTargets.map(\.tag)),
            Set(["tailscale-overlay", "tailscale-exit"])
        )
        XCTAssertFalse(profile.scenarios[0].bindings.contains {
            $0.ruleSetID == RuleSet.connectivityOutboundID
        })
    }

    func testRequiresBothLinesBeforeTestingRouting() {
        XCTAssertFalse(DataPathProbe.Result(
            directLineEgressIP: nil,
            anyConnectLineEgressIP: "203.0.113.2",
            routedDirectEgressIP: "198.51.100.1",
            routedAnyConnectEgressIP: "203.0.113.2",
            hostnameOK: true,
            routingEvidenceOK: true
        ).isUsable)
        XCTAssertFalse(DataPathProbe.Result(
            directLineEgressIP: "198.51.100.1",
            anyConnectLineEgressIP: nil,
            routedDirectEgressIP: "198.51.100.1",
            routedAnyConnectEgressIP: "203.0.113.2",
            hostnameOK: true,
            routingEvidenceOK: true
        ).isUsable)
    }

    func testRequiresRouterHitEvidenceInsteadOfInferringFromPublicAddresses() {
        XCTAssertFalse(DataPathProbe.Result(
            directLineEgressIP: "198.51.100.1",
            anyConnectLineEgressIP: "203.0.113.2",
            routedDirectEgressIP: "203.0.113.2",
            routedAnyConnectEgressIP: "203.0.113.2",
            hostnameOK: true,
            routingEvidenceOK: false
        ).isUsable)
        XCTAssertTrue(DataPathProbe.Result(
            directLineEgressIP: "198.51.100.1",
            anyConnectLineEgressIP: "203.0.113.2",
            routedDirectEgressIP: "192.0.2.90",
            routedAnyConnectEgressIP: "192.0.2.91",
            hostnameOK: true,
            routingEvidenceOK: true
        ).isUsable)
    }

    func testAcceptsSamePublicEgressWhenRouterEvidenceIsCorrectAndRejectsDNSFailure() {
        XCTAssertTrue(DataPathProbe.Result(
            directLineEgressIP: "198.51.100.1",
            anyConnectLineEgressIP: "198.51.100.1",
            routedDirectEgressIP: "198.51.100.1",
            routedAnyConnectEgressIP: "198.51.100.1",
            hostnameOK: true,
            routingEvidenceOK: true
        ).isUsable)
        XCTAssertFalse(DataPathProbe.Result(
            directLineEgressIP: "198.51.100.1",
            anyConnectLineEgressIP: "203.0.113.2",
            routedDirectEgressIP: "198.51.100.1",
            routedAnyConnectEgressIP: "203.0.113.2",
            hostnameOK: false,
            routingEvidenceOK: true
        ).isUsable)
    }

    func testParsesIPv4AndIPv6FromCloudflareTrace() {
        let ipv4 = Data("fl=1\nip=203.0.113.9\nts=1\n".utf8)
        let ipv6 = Data("ip=2001:db8::9\nloc=US\n".utf8)

        XCTAssertEqual(DataPathProbe.parseTraceIPAddress(ipv4), "203.0.113.9")
        XCTAssertEqual(DataPathProbe.parseTraceIPAddress(ipv6), "2001:db8::9")
    }

    func testRejectsMissingOrUnsafeTraceAddress() {
        XCTAssertNil(DataPathProbe.parseTraceIPAddress(Data("loc=US\n".utf8)))
        XCTAssertNil(DataPathProbe.parseTraceIPAddress(Data("ip=<script>\n".utf8)))
        XCTAssertNil(DataPathProbe.parseTraceIPAddress(Data("ip=not-an-address\n".utf8)))
        XCTAssertNil(DataPathProbe.parseTraceIPAddress(Data("ip=999.999.999.999\n".utf8)))
    }

    func testRoutingSnapshotRequiresOnlyExpectedOutboundDeltas() {
        let before = RoutingProbeSnapshot(
            directTargetDirect: 4,
            directTargetVPN: 1,
            directTargetOther: 0,
            anyConnectTargetDirect: 2,
            anyConnectTargetVPN: 7,
            anyConnectTargetOther: 0
        )
        let valid = RoutingProbeSnapshot(
            directTargetDirect: 5,
            directTargetVPN: 1,
            directTargetOther: 0,
            anyConnectTargetDirect: 2,
            anyConnectTargetVPN: 8,
            anyConnectTargetOther: 0
        )
        let wrongRoute = RoutingProbeSnapshot(
            directTargetDirect: 5,
            directTargetVPN: 1,
            directTargetOther: 0,
            anyConnectTargetDirect: 3,
            anyConnectTargetVPN: 7,
            anyConnectTargetOther: 0
        )

        XCTAssertTrue(before.provesConfiguredRouting(after: valid))
        XCTAssertFalse(before.provesConfiguredRouting(after: wrongRoute))
        XCTAssertFalse(valid.provesConfiguredRouting(after: before))
    }

    func testStandaloneRoutingSnapshotRequiresExactConfiguredTag() {
        let before = RoutingProbeSnapshot(
            directTargetDirect: 0,
            directTargetVPN: 0,
            directTargetOther: 0,
            anyConnectTargetDirect: 0,
            anyConnectTargetVPN: 0,
            anyConnectTargetOther: 0,
            directTargetTags: ["direct": 4],
            anyConnectTargetTags: ["proxy-main": 2]
        )
        let valid = RoutingProbeSnapshot(
            directTargetDirect: 1,
            directTargetVPN: 0,
            directTargetOther: 0,
            anyConnectTargetDirect: 0,
            anyConnectTargetVPN: 0,
            anyConnectTargetOther: 1,
            directTargetTags: ["direct": 5],
            anyConnectTargetTags: ["proxy-main": 3]
        )
        let wrongProxy = RoutingProbeSnapshot(
            directTargetDirect: 1,
            directTargetVPN: 0,
            directTargetOther: 0,
            anyConnectTargetDirect: 0,
            anyConnectTargetVPN: 0,
            anyConnectTargetOther: 1,
            directTargetTags: ["direct": 5],
            anyConnectTargetTags: ["proxy-main": 2, "proxy-other": 1]
        )

        XCTAssertTrue(before.provesConfiguredRouting(
            after: valid,
            directTag: "direct",
            currentRouteTag: "proxy-main"
        ))
        XCTAssertFalse(before.provesConfiguredRouting(
            after: wrongProxy,
            directTag: "direct",
            currentRouteTag: "proxy-main"
        ))
    }

    func testReconnectSuppressionRequiresAnActualActiveTunnelStop() {
        XCTAssertFalse(ProbeFailureReconnectPolicy.shouldSuppressAutomaticReconnect(
            shouldStop: false,
            tunnelIsActive: true
        ))
        XCTAssertFalse(ProbeFailureReconnectPolicy.shouldSuppressAutomaticReconnect(
            shouldStop: true,
            tunnelIsActive: false
        ))
        XCTAssertTrue(ProbeFailureReconnectPolicy.shouldSuppressAutomaticReconnect(
            shouldStop: true,
            tunnelIsActive: true
        ))
    }

    func testOneShotTimeoutCompletesWhenProviderNeverCallsBack() async {
        let result: String = await withCheckedContinuation { continuation in
            let oneShot = OneShotContinuation<String>(continuation)
            DispatchQueue.global().asyncAfter(deadline: .now() + 0.02) {
                oneShot.finish("timed-out")
            }
            // Intentionally never invoke a simulated provider callback.
        }
        XCTAssertEqual(result, "timed-out")
    }

    func testOneShotCancellationCanFinishBeforeContinuationIsInstalled() async {
        let oneShot = OneShotContinuation<String>()
        oneShot.finish("cancelled")
        let result: String = await withCheckedContinuation { continuation in
            oneShot.install(continuation)
        }
        XCTAssertEqual(result, "cancelled")
    }
}
