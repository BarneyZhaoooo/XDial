package main

import (
	"os"
	"path/filepath"
	"reflect"
	"regexp"
	"testing"
)

func TestRuntimeIdentityForDebug(t *testing.T) {
	got := runtimeIdentityForFlavor("debug")
	want := runtimeIdentity{
		hostBundleIdentifier:   "com.xd.xdial.debug",
		helperBundleIdentifier: "com.xd.xdial.debug.helper",
		daemonLabel:            "com.xd.xdial.debug.daemon",
		socketPath:             "/tmp/xdial-debug.sock",
		engineBasePath:         "/tmp/xdial-debug-engine",
		rootStatePath:          "/Library/Application Support/XDial Debug",
		userStateDirectoryName: ".xdial-debug",
		sharedAppGroup:         "SX9RG894L5.com.xd.xdial.debug.network",
		registrationIntentPath: "/tmp/xdial-debug-registration-maintenance",
		logPath:                "/tmp/xdial-debug.log",
		tailscaleDeviceChannel: "debug",
	}
	if !reflect.DeepEqual(got, want) {
		t.Fatalf("debug runtime identity = %#v, want %#v", got, want)
	}
	if got.userStatePath("/Users/test") != "/Users/test/.xdial-debug" {
		t.Fatalf("debug user state path = %q", got.userStatePath("/Users/test"))
	}
}

func TestRuntimeIdentityDefaultsToExistingProductionIdentity(t *testing.T) {
	want := runtimeIdentity{
		hostBundleIdentifier:   "com.xd.xdial.app",
		helperBundleIdentifier: "com.xd.xdial.app.helper",
		daemonLabel:            "com.xd.xdial.app.daemon",
		socketPath:             "/tmp/xdial.sock",
		engineBasePath:         filepath.Join(os.TempDir(), "xdial-engine"),
		rootStatePath:          "/Library/Application Support/XDial",
		userStateDirectoryName: ".xdial",
		sharedAppGroup:         "SX9RG894L5.com.xd.xdial.network",
		registrationIntentPath: "/tmp/xdial-registration-maintenance",
		logPath:                "/tmp/xdial.log",
		tailscaleDeviceChannel: "stable",
	}
	// Beta is a formal build, and the retired Next flavor must not regain an
	// identity of its own.
	for _, flavor := range []string{"", "release", "unexpected", "beta", "stable", "next"} {
		t.Run(flavor, func(t *testing.T) {
			got := runtimeIdentityForFlavor(flavor)
			if !reflect.DeepEqual(got, want) {
				t.Fatalf("runtime identity for %q = %#v, want %#v", flavor, got, want)
			}
			if got.userStatePath("/Users/test") != "/Users/test/.xdial" {
				t.Fatalf("production user state path = %q", got.userStatePath("/Users/test"))
			}
		})
	}
}

func TestFormalAndDebugRuntimeResourcesAreDisjoint(t *testing.T) {
	formal := runtimeIdentityForFlavor("")
	debug := runtimeIdentityForFlavor("debug")
	for name, values := range map[string][2]string{
		"host":                {formal.hostBundleIdentifier, debug.hostBundleIdentifier},
		"helper":              {formal.helperBundleIdentifier, debug.helperBundleIdentifier},
		"daemon label":        {formal.daemonLabel, debug.daemonLabel},
		"socket":              {formal.socketPath, debug.socketPath},
		"engine directory":    {formal.engineBasePath, debug.engineBasePath},
		"root state":          {formal.rootStatePath, debug.rootStatePath},
		"user state":          {formal.userStateDirectoryName, debug.userStateDirectoryName},
		"App Group":           {formal.sharedAppGroup, debug.sharedAppGroup},
		"registration intent": {formal.registrationIntentPath, debug.registrationIntentPath},
		"log":                 {formal.logPath, debug.logPath},
		"Tailscale channel":   {formal.tailscaleDeviceChannel, debug.tailscaleDeviceChannel},
	} {
		if values[0] == "" || values[0] == values[1] {
			t.Errorf("formal and Debug share the %s %q", name, values[0])
		}
	}
}

func TestOrphanSingBoxPatternsAreFlavorScoped(t *testing.T) {
	formal := runtimeIdentityForFlavor("")
	debug := runtimeIdentityForFlavor("debug")
	formalPattern := regexp.MustCompile(formal.orphanSingBoxPattern())
	debugPattern := regexp.MustCompile(debug.orphanSingBoxPattern())

	formalCommand := "sing-box run -c /tmp/xdial-engine/sing-box.json -D /tmp/xdial-engine"
	debugCommand := "sing-box run -c /tmp/xdial-debug-engine/sing-box.json -D /tmp/xdial-debug-engine"
	if !formalPattern.MatchString(formalCommand) || formalPattern.MatchString(debugCommand) {
		t.Fatalf("formal cleanup pattern %q is not isolated", formal.orphanSingBoxPattern())
	}
	if !debugPattern.MatchString(debugCommand) || debugPattern.MatchString(formalCommand) {
		t.Fatalf("debug cleanup pattern %q is not isolated", debug.orphanSingBoxPattern())
	}
}
