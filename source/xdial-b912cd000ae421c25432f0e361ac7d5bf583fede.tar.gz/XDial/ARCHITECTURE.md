# XDial 架构与边界

## 1. 所有权

**XDial 表达、编译和托管；sing-box 独占 DNS、规则匹配、出口选择与转发。**

| 层 | 所有权 | 边界 |
|---|---|---|
| Go 控制面 | Profile 校验、配置与计划编译、运行目录及配置身份 | 不在 sing-box 之外裁决逐流路由或 DNS |
| Swift 宿主与 UI | 用户意图、平台生命周期、结构化状态展示 | 不复制 Go 的 tag、schema、依赖闭包或指纹算法 |
| 平台 Ingress | 系统 flow / TUN 接入、系统网络事实 | 不理解 Line、RuleSet、Scenario，不选择 resolver 或出口 |
| sing-box | 同一份配置内的解析、裁决与转发 | 不向系统散落产品级 DNS、路由或接口策略 |
| 协议适配器 | 将 sslcon 等能力暴露为盒内出口 | 不反向控制其他线路或全局状态机 |

XDial 对系统增加一个网络叠加层。外部已有的 Wi-Fi、网线、VPN
共同组成不透明 Underlay，不能被 XDial 按产品名拆解、关闭或重排。

## 2. 领域与供给（D28）

| 维度 | 项目中的职责 |
|---|---|
| Ingress | 流量如何进入盒内；与出口裁决正交 |
| Line | 出口协议、凭据、传输与解析能力；声明本身不生效 |
| RuleSet | 匹配内容与远程资源；不携带用户流量出口 |
| Scenario | 绑定 RuleSet → Line、指定默认 Line；用户流量裁决的唯一连接点 |

配置库 schema 3 中，Profile 只持有来源线路与规则，线路组与 Scenario 由配置库全局持有。
稳定引用保留来源身份；同名对象不合并，旧 ID 冲突在迁移时重映射并保存翻译表。
宿主将资源目录、全局组与场景投影为一个临时 Profile 交给既有 Go 编译入口，只有一份持久资源。
Go 继续决定有效依赖、协议身份路径与运行指纹。Tailscale 的来源 Profile ID / hostname
随线路进入临时快照，Go 从活动场景选择原来源的身份目录；复制和导出移除这两个运行字段。
旧库升级前保留加密原件，格式不支持、迁移冲突或引用失效均拒绝写回，不能回退成空配置。

用户流量依赖方向为 `Scenario → {RuleSet, Line}`。只有 active Scenario 的有效依赖进入
运行配置；未引用对象不因浏览或保存配置而创建流量规则、活会话或网络请求。限时 Tailscale
配置会话、`URL RuleSet → fetch Line` 和用户显式发起的限时线路测速是独立资源会话，均无系统
Ingress。测速只创建指定普通代理/Direct 的 sing-box 出口并执行一次 HTTPS HEAD，不创建
TUN、系统代理、系统 DNS、默认路由或持久状态；不启动未连接的 AnyConnect/Tailscale 身份。
批量测速最多并发 3 条，每条限时 5 秒，可取消排队；完成即关闭其独立 Box。它不选择或应用
场景出口，也不把独立测试结果当作当前连接的原生 URLTest 选线事实。

供给规则是可见、可禁用、可排序、可不用的申报，不是隐式注入。Scenario 显式绑定优先于
订阅供给；MagicDNS 的 DNS 优先级是 [单独限定的例外](#32-tailscale-与-magicdnsd33)。
引用悬空、重复 outbound tag 或单例冲突在生成阶段失败；主动禁用产生可见 warning，
不静默跳过无法生成的规则。

生成的 route 只来自 Scenario、显式系统规则（`sniff`、`hijack-dns`、桌面诊断 selector）
或已启用的动态 MagicDNS 能力。裁决相关的 resolver、缓存隔离、接口与 TUN stack 配置
显式生成，不依赖上游默认值维持产品边界。

入口：[配置生成](core/config/generator.go)、[ConnectionPlan](core/config/connection_plan.go)、
[不变量](core/config/invariants_test.go)。

## 3. 平台接入与 Line

### 3.1 macOS 与 Underlay（D31–D35、D-UNDERLAY、D-INGRESS）

macOS 主入口为 `NETransparentProxyProvider`，以随机凭据保护的回环 SOCKS 将 TCP/UDP
flow 交给同进程 sing-box。iOS / tvOS 使用 Packet Tunnel；系统 HTTP/SOCKS 代理与 PAC 不是当前入口。
Transparent Proxy 不接管 ICMP。link-local、multicast、limited broadcast 留在 Underlay；
RFC1918、IPv6 ULA、Tailnet 与企业单播地址仍由 Scenario 裁决，排除集合不按应用或产品扩展。

Underlay 来自宿主请求连接前同一时刻的内核默认接口、完整 `NWPath.availableInterfaces`
与系统 DNS；同一样本另取默认接口的 IPv4 地址与主服务 IPv4 / IPv6 默认路由器，只用于比较。
IPv6 接口地址（临时地址在稳定网络上轮换）不进入比较；Provider 只收到默认路径的不透明身份，
不收到这些地址。Provider 内的 `NWPath` 可能隐藏既有全流量 VPN，只用于诊断。
`route.default_interface` 原样采用内核结果；接口快照仅补齐系统 MTU、标志与地址，
只排除当前 XDial 会话自己登记的接口，不按名称前缀筛选、不取首候选、不生成 outbound
`bind_interface`。缺失或不一致的快照不能启动连接。

macOS 已绑定 flow 的接口是系统既有裁决，经认证且有长度上限的 metadata 传给 sing-box；
Scenario 先选 Line，仅最终属于 Direct 的 flow 恢复该绑定，其他 Line 不继承它。

本机 SOCKS5 由 Provider 持有 `127.0.0.1:<port>`，只接受本机无认证 TCP CONNECT，不设置
系统代理、不监听其他地址。每条连接在接入时取得当前 generation 的会话入口，与系统 flow
共用 relay 登记、换代排空和停止关闭；端口不随 Switch 重建。客户端主机名只放行可打印字节，
不能携带 Provider 的 flow metadata；该入口没有应用身份，只命中 Scenario 的非应用规则。

连接方式是 `ConnectionReport.ingress`，由宿主在完整连接开始时按 App 偏好写入，Switch 沿用
已提交连接的入口，候选报告入口不同即拒绝。它不进入 Profile 或运行指纹；偏好与当前连接
不同时以待应用状态提示，应用时完整重连，不用保留旧连接的 Switch 改变系统接管。

| 入口 | 系统接管 | 本机端口 |
|---|---|---|
| `system`（默认） | 提交完整 flow 与 DNS 捕获规则 | 可选附加入口，经 Provider IPC 即时开关；失败只在设置中提示 |
| `local-socks` | 提交不含任何捕获规则的设置，系统流量与 DNS 不经过 XDial | 唯一入口，Commit 前建立监听；失败即本次连接失败，回滚时关闭 |

入口：[宿主](macos/Sources/XDial/TransparentProxyManager.swift)、
[Provider](macos/TransparentProxyExtension/TransparentProxyProvider.swift)、
[flow metadata](macos/Shared/TransparentProxyFlowMetadata.swift)、
[本机 SOCKS5](macos/TransparentProxyExtension/LocalSOCKSShareListener.swift)。

### 3.2 Tailscale 与 MagicDNS（D33）

内置 Tailscale 是盒内 endpoint，不创建系统接口、不接管系统 DNS、不接受或发布系统路由。
每个安装身份内，每个 Profile 共用一份持久身份；不同 Line 可选择不同 exit node，但 active Scenario 至多
使用一条 Tailscale Line。未登录、需要认证或指定节点不可用产生结构化失败，不自动换节点。

Tailscale 设备名在运行快照中按安装身份添加前缀：Debug 为 `xdial-debug-`，正式版（含 beta）为
`xdial-stable-`；共享 Profile 里残留的旧前缀 `xdial-next-` 同样被替换。不回写共享 Profile，
不改变身份内的状态目录或 node key。

登录管理按持久身份确定所有者，而不是用整个 XDial 的连接状态禁用操作。已提交的 Provider
通过带事务 ID 的独立控制 IPC 提供当前身份的状态与登录续期；不在当前连接中的身份可启动
无系统入口的限时 setup session。Provider 拒绝或事务变化不能推断为“身份空闲”；只有明确
`identity-not-active` 才转到 setup，持久目录的独占锁继续防止两个实例同时使用同一身份。
退出正在承载流量的身份必须先由用户停止使用它，不隐式断开当前连接。

setup 状态刷新复用现有实例和登录 URL；删除线路、空闲超时、连接交接或 daemon 退出即停止。
完整连接和场景切换先阻止新登录操作，等待已接受的操作结束，再确认 setup 已释放，才创建
候选数据面。场景切换的旧连接在此期间保持运行；释放失败不启动候选、不破坏旧连接。
Auth Key 仅作为单次注册输入，请求返回后 UI 清空，不进入 Profile、Keychain、订阅、日志、
Debug 或运行配置；已持久化 node key 的有效性不取决于该 Auth Key 是否过期。

MagicDNS 默认关闭，仅在该 Line 被引用且用户开启时生效。macOS Transparent Proxy 的契约为：

- 同一 endpoint 就绪后、Commit 前读取一次 NetMap `DNS Config`，会话中不持续追踪。
  快照原子注入 sing-box 内存 hosts；缺少可用配置或注入失败阻止 Commit。
- `Hosts` 提供完整名与地址，`SearchDomains` 展开已知单标签别名；只有无 resolver 的
  `Routes` 是本地权威命名空间。带 resolver 的 split-DNS route 不冒充本地权威。
- DNS 与 peer route 成对启用：DNS 权威范围优先于 Scenario DNS，范围内未知名直接
  NXDOMAIN；peer / subnet route 晚于 Scenario 显式 route。归属来自实时 `AllowedIPs`，
  排除 Exit Node 的 `0.0.0.0/0`、`::/0`，不硬编码 Tailnet 网段、域名或默认路由。
- 成员记录只存在于本次 Provider 的 sing-box 内存，不进入 Profile、持久 Provider 配置、
  缓存、日志或 Debug。解析与 route resolve 均不缓存，不调用 Tailscale DNS transport
  或默认 resolver；会话结束清空。
- 平台 Ingress 只取得同一 Libbox 事务返回的有界捕获名称，用于优先的 port 53 host rules；
  不取得成员 IP 映射或自行派生 DNS 归属。捕获集合为空、畸形或超限时不 Commit。

该快照契约不自动扩展到 iOS / tvOS 的现有 DNS 路径。

Tailscale 的 endpoint 在 delta 后必须标记已变异；即使下一张 full map 等于旧快照，也要先
upsert endpoint 并重算 relay candidate，避免 `A → delta(B) → full(A)` 留下旧运行状态。
LocalAPI 状态、control 接受、远端 map、fresh handshake 和真实出口是独立事实。
握手失败归因到该 Line，不靠重启远端、固定 DERP、轮换身份或 Direct 回落解决。
Home DERP 重选是显式维护能力，不是连接准备条件。

入口：[Tailscale 运行能力](core/libbox/tailscale_runtime_gvisor.go)、
[认证](core/tailscalesetup/)、[结构化证据](docs/verification/tailscale.md)。

### 3.3 AnyConnect（D30）

sslcon 是进程级单例；active Scenario 的有效依赖中至多有一条 AnyConnect Line，多条直接生成失败。
同配置的运行能力可以被新旧 Box 共享，认证与恢复由 Line 自己持有，不因 Scenario 切换重做。
不同配置的单例不能并发准备：Switch 候选拒绝后，宿主断开旧连接并完整连接目标场景，
期间短暂断流，不伪装成无中断切换。

局部恢复的三次预算只计宿主报告“已完整唤醒且 Underlay 可用”时的尝试。系统休眠
（含 Dark Wake）或宿主 NWPath 不可用期间，线路保持不可用（REJECT / SERVFAIL）并等待，
不尝试、不计次、不提升为完整恢复；跨越关闭期的尝试不计次，其失败也不按终止错误归类。
门由宿主经 Provider IPC 报告，Provider 不自行判断；关闭态是有界租约（休眠 15 分钟、
无 Underlay 5 分钟，按不计休眠的单调时钟），宿主在条件持续期间续约，宿主消失则租约
到期后恢复正常计数。宿主报告重新可用或新 epoch 是新的网络条件，重新获得预算；
可用网络上耗尽预算或凭据、配置等终止错误仍提升为完整恢复。

sslcon 的 socket 不绑定接口，停留在连接时内核默认路由所在的接口上。只有该接口已不在
新 epoch 的接口集合中，会话才必然失效，就绪证明经同一恢复 owner 立即重建，不等探测
超时或 DPD。该接口仍在时（默认路由移到新接口，或同名同序号接口换了地址），候选准备
期间旧会话继续承载已提交事务，不主动重连；仍只由经现有会话的就绪探测在结构化瞬态失败
时强制重连。门关闭时也不替换会话。

入口：[AnyConnect 运行能力](core/libbox/anyconnect_runtime.go)、
[恢复门](core/libbox/line_recovery_gate.go)、[宿主报告](macos/Shared/LineRecoveryConditionsIPC.swift)。

## 4. DNS

### 4.1 名字、线路与地址（D-DNS）

**已知目标先确定 Line，再按该 Line 的解析视角取地址并连接。** 目标已由域名或字面 IP
明确命中绑定时，预解析、探测、失败回退都不能先经过无关 Line。解析能力由 Line 提供，
使用权由 Scenario 决定；同一 Line 的内网名与公网名也不一定使用同一 resolver。

域名 binding 的 DNS 与 route 从同一 Scenario 同源编译，保持彼此顺序。纯 IP 与不可安全
拆分的 mixed 分支不生成 DNS 规则，也不截断后续明确的域名分支。
需要地址才能分类的 IP 规则可先采用 Underlay 解析；未命中后，默认分支仍按 Scenario 默认
Line 重新解析，不把分类答案或其他解析视角的缓存带入最终出口。
Application binding 的 `auth_user` 归属同样贯穿 DNS 与 route resolve。

### 4.2 Direct 原生解析

Direct 使用完整 Underlay 的解析语义，不寻找绕过既有 VPN 的“物理 DNS”。盒内有两条不同路径：

| 输入 | 解析路径 |
|---|---|
| 已捕获的系统 / 应用 DNS flow | sing-box 裁决为 Direct 后，经 Direct dialer 转发原 UDP/TCP 查询字节到原 resolver endpoint；响应校验事务 ID、问题和目标 |
| 无原始 flow 的盒内主动解析 | 使用 Apple `DNSServiceGetAddrInfo`，保留系统 scoped resolver、搜索域与既有叠加 |

已被接管、等待 Provider 应答的查询不能再次交给 mDNSResponder。
缺少原始上下文或校验失败不回落到重建查询、首选 resolver 裸 UDP 或公共 DNS。
Provider 不读域名、不执行第二次 DNS 裁决。

入口：[DNS transport](core/libbox/mobile_dns_transport.go)、
[原查询与系统解析补丁](patches/sing-box/)。

Linux 透明服务的系统 DNS 后端与上述 Apple 接口分开适配：当系统明确使用
systemd-resolved 的标准 stub 时，Direct/服务器 bootstrap 经带 bypass mark 的
sing-box transport 查询该 stub，保留 resolved 的 per-link/split DNS。代理应用 DNS
仍绑定原精确 Line；不启用会拍平默认接口 DNS 的上游 `local` 实现。此模式关闭盒内
第二层 DNS cache，避免系统域路由变化后继续返回旧视角；系统 resolver 自己拥有缓存。

系统 resolver 的依赖套接字只按已验证的服务 cgroup v2 豁免：系统总线、PID 1 的
MainPID/非委托 cgroup、内核进程和实际 stub socket 所有权必须一致。pidfd、总线
owner 与持有的 cgroup handle 限定租约；退出/身份变化先撤捕获，不能用客户端自报
PID/UID 或宽泛 root UID 豁免。这个保护不等于应用原生解析 IPC 已接管：`nss-resolve`
与 nscd 会丢失原应用网络身份，当前服务拒绝这些配置，变化时断开。未来需要带内核
调用者身份的原生解析入口；不能把 DNS socket 证据称为所有 D-Bus/Varlink API 已覆盖。
入口：[Linux resolver 租约](core/linuxresolver/resolved_linux.go)、
[系统验收](docs/verification/linux-resolved.md)。

### 4.3 就绪与地址族

Direct 的就绪证明是当前 Underlay 上下文与配置归属，**不依赖固定外部 DNS、TLS 或出口
展示服务**，也不声称由此证明整个 IPv4 / IPv6 可达。其他 Line 的实际服务依赖经该 Line
的精确出口验证；诊断和展示失败不升级为无关 Line 或整个 Scenario 的连接门槛。
固定 IP、公共 resolver、TLS 或单个目标失败均不足以判定整个网络或地址族不可用。

能力属于具体 Line、network epoch、运行 revision 与候选 Box；旧结果不能跨事务复用或
传播到其他 Line。已有有效地址族限制时，同一 Line 的 DNS、Application binding 与 route
resolve 使用一致策略；合法单栈不等于整条 Line 失败，双栈也不因单点失败全局降为 IPv4。

入口：[就绪证明](core/libbox/line_network_readiness.go)、
[Direct 无强制 TLS 测试](core/libbox/line_network_readiness_test.go)。

### 4.4 应用自带的地址

应用拿来连接的地址不一定来自 XDial：可能是旧缓存，也可能是绕过接管的解析结果，例如
mDNSResponder 在接管前建立的 querier、应用内置的解析器或接管前的缓存。这类结果是 Underlay
视角，甚至可能被篡改。所以 DNS 是否被完整接管，不能决定连接的正确性；名字决定了 Line，
地址也必须来自该 Line。选定 Line 后，盒内按 flow 已归属的名字核对地址：

| 条件 | 处理 |
|---|---|
| endpoint 地址族不符合所属 Line 的有效能力 | 按该 Line 重新解析 |
| 非 Direct Line 的 resolver（经该 Line 的 DoH、AnyConnect 企业 DNS）应答不含应用给出的公网地址 | 改按该应答连接 |
| 应答包含该地址、为空或解析失败 | 保持应用的地址 |
| Direct、启动前系统 DNS、当前选中 Direct 的选择器组 | 不核对，应用的答案就是它们的视角 |
| 私网、本机、链路本地、`100.64.0.0/10`、`198.18.0.0/15` 地址 | 视为应用的有意选择，不核对 |
| 没有名字的字面 IP flow | 不存在安全的重解析路径，保持原样 |

名字来源只有两种：系统随 flow 提供的原始域名；应用按地址连接时，从 TLS / QUIC / HTTP
嗅探到的名字，也就是 route 求值所用的名字。两者都存在但不一致时不核对。嗅探到的名字
本来就决定 Line；核对只会把流量送到该名字在这条 Line 视角下的地址，不会扩大应用能够
到达的范围。证书校验仍在应用与服务端之间完成。
DEBUG 路由探针只返回本窗口内被纠正的 flow 数，不返回原地址或名字。

connect-by-name UDP 在 SOCKS 边界保留域名；这不代表支持 unconnected 多目标 UDP 或 QUIC 迁移。

入口：[地址核对补丁](patches/sing-box/0017-correct-flow-address-from-matched-line.patch)、
[生成器标记](core/config/generator.go)（`markLineOwnedFlowAddressCorrection`）。

### 4.5 fake IP（D-FAKEIP）

当前不启用 fake IP。预留地址段与 TUN 的 `198.18.0.0/15` 分离，避免与基础设施地址及旧 DNS
残留识别混淆；未来启用也只保留域名关联，不改变同一 Scenario 的出口裁决。

## 5. 连接、切换与恢复（D35、D36、D40）

### 5.1 连接事务

`ConnectionPlan` 由 active Scenario 的有效依赖闭包编译，包含真实任务和依赖，不是按协议
排列的固定流程。跨语言合同使用 `schema_version: 3` 与 `scenario`，无旧领域名别名。

| 阶段 | 边界 |
|---|---|
| `planning` | 校验引用与依赖图，无网络副作用 |
| `preparing → readyToCommit` | 准备所需 Line、规则缓存和完整 sing-box，不提交系统网络设置 |
| `committing → committed` | 所有所需任务 ready 后，首次连接以 `setTunnelNetworkSettings` 接管系统流量 |
| `rollingBack → rolledBack → failed/cancelled` | 任一步失败或取消时逆序、幂等、有界撤销已完成的会话副作用 |

Profile、持久身份与有效 RuleSet 缓存不回滚；本次会话、Box、relay、monitor 和已提交网络
设置被回收。原始失败与回滚失败分别保留，报告明确记录系统接管是否移除。
接管中的转发失败关闭 flow；Line 暂时不可用时对应流量 REJECT、DNS SERVFAIL，不静默回落
Direct、公共 DNS 或其他 Line。启动阶段构造成功不代表数据面已启动或系统 Commit 成功。

### 5.2 状态所有权

运行事实来自带 transaction ID 的 `ConnectionReport`，宿主、UI、Debug 与测试消费同一份
任务、错误、时间和回滚结果。日志不驱动状态机，Network Extension 的 `connected` 也不是
事务或真实出口成功的替代。打开设置、展开 Line 或刷新 UI 不产生探测、刷新线路或网络请求。

Provider 诊断限定当前事务的 active Line。短时 route watch 只返回有界归属与 sequence，
不返回目标、规则、URL、凭据或浏览记录；超时或事务结束即失效，结果不参与流量裁决。

Provider 是运行报告的权威写入者。root 与用户 App Group 是不同容器：初始报告随启动
options 传入，Provider 原子 journal 由文件锁串行写入，helper 只读转发，宿主镜像给 UI。
残留半完成事务先与系统状态协调清理；残留按所有权判定，只有此前 Host 进程遗留的事务才会被
回收，本进程发起或接管的事务归实时状态机，迟到的状态同步不能凭报告形状撤销它。
journal 无法可靠写入时不能 Commit。入口：[事务处置](macos/Shared/PersistedTransactionReconciliation.swift)。

配置指纹由 Go 与计划同源生成：包含实际 binding 顺序、默认 Line、有效依赖及 fetch Line；
排除显示名称、图标、SSID 和顶层视觉排序。Swift 只比较指纹判断 `configDirty`。
指纹及其投影可能受凭据影响，不进入日志或 Debug，外部只看到比较结果。

入口：[配置指纹](core/config/runtime_fingerprint.go)、
[Provider 报告](macos/TransparentProxyExtension/ConnectionTransactionReporter.swift)。

### 5.3 Switch 与 Line 租约

已连接时的场景切换、重连和自动选择创建候选 Switch；旧 generation 在候选准备期间继续
承载流量。候选重新编译完整计划和 Box，不先停止旧 Line、移除系统接管或原地热改规则。

- 配置身份完全相同的 Line 取得同一能力的租约，变更身份另行准备。身份由 Go 同源生成，
  包含协议、endpoint 与凭据因素，排除展示字段；身份材料不对外暴露。
- 能力池仅供当前 committed 与唯一候选计划持有。恢复归 Line 的唯一 owner；候选取消
  或旧 Box 退役只释放自己的租约，最后一个租约释放才停止能力，不并发创建第二个握手任务。
- 当前 epoch、revision 与 generation 的就绪证明有效后才 Commit。迟到成功不能恢复旧
  ready；同一 Line 的新成功不能清除其他 Line 的失败或 Box 结构错误。
- 提交原子切换新 flow 的 relay generation 与完整 DNS / route 配置；旧 flow 有界排空，
  默认 1 秒后关闭。仅当手动重连或 network epoch 重编译同一 Scenario 与配置指纹、默认路径身份
  （默认接口、其 IPv4 地址与默认路由器）也未变时，旧 generation 已接入的 TCP flow 留在
  旧 Box 直至结束，最长 10 分钟；下一候选开始准备（路径变化即下一 epoch）或停止先使其
  退役，UDP association 仍 1 秒换代。保留期间租约仍只属于 committed 与另一个 generation
  ——候选或保留的旧源，二者不并存。规则、DNS 和默认出口不能分成多个可见提交。
- 候选失败只清理候选，保留旧场景、网络设置和连接时长；提交中失败恢复旧 relay。
  无法证明旧 generation 健康时才进入全局回滚。报告同时保留 from、to、候选与仍承载流量的事务。
- 任意时刻最多一个候选，latest-wins；重复选择同一场景且配置与网络均相同时复用原事务。点击重新连接始终启动候选。显式断开优先取消候选
  和恢复意图，再释放全部租约与系统接管。单例身份变化不能伪装成可复用的无中断切换。
- 同场景应用已保存配置与切换场景共用候选事务。Mac 候选可在旧连接上经 Direct 获取规则，
  或用无系统入口的独立获取会话。遇到无法并存的单例协议身份时，报告候选失败并保留已提交场景。
  更改系统接管方式仍需要重新建立入口。

入口：[Line 能力池](core/libbox/line_runtime_pool.go)、[Switch 测试](core/libbox/switch_test.go)。

**iOS Packet Tunnel。** 只有一个 packetFlow，没有可按代转发的 relay。候选 Box 摘下 TUN inbound
启动，与旧代并存准备和探测，不接触用户流量；Commit 在原有验证之后关闭旧代 TUN inbound，
用同一 fd 为候选创建，候选打不开时还给旧代，两边都失败才结束隧道。旧 gVisor 栈终结的连接
随之重置，不排空；NE 会话、路由与 DNS 设置不变，切换期间没有流量绕过隧道。iOS 的 Tailscale
仍归各代 Box 所有；AnyConnect 身份不同或两代都含 Tailscale 而不能并存时，Provider 在同一 NE
会话里换引擎（先停旧引擎，新引擎失败时以旧启动包重起），不停系统 VPN。已连接期间场景由 Provider 判断与切换，启动包与判断规则来自
App 写入共享 Keychain 的场景目录。入口：[TUN 交接](core/libbox/tun_handover.go)、
[Provider](appletv/XDialTVTunnel/PacketTunnelProvider.swift)、
[计划](docs/plans/ios-in-tunnel-scenario-switch.md)。
Android packet ingress 显式独立拥有单一 TUN/gVisor，数据 Box 与候选 Box 不再拥有
packet reader；候选系统 TUN 设置必须与已建立入口一致。TCP/UDP 在完整 flow router
入口绑定代际，DNS 与 ICMP native Port/FlowTracker 也归同一代际，退役关闭旧流与
迟到句柄。新流的 DNS/route 一次切换，默认 1 秒退休源；停止先阻止接新流再关闭代际
和入口。Apple 的既有入口不自动启用此模式。见
[稳定入口](core/libbox/packet_ingress.go)、[Android 事务](core/libbox/android_switch.go)。


Windows/Linux 的原生流适配使用同一 generation 管理，显式选择无 listener 的数据
Box 与候选 Box；平台只提供原始端点和 OS 进程事实，出口/DNS/规则始终在 sing-box
裁决。普通 IPC 客户端自报的 PID、路径或 UID 不是可信事实。新流在提交点换代，
旧流等待平台的有界排空/退休操作；停止先禁止接流，再关闭代际。接流 worker 不持
系统回调锁，不能从关闭回调同步重入等待该流退出的生命周期操作。此接口的存在
不代表 OS 拦截器或安装事务已就绪。见 [原生流入口](core/libbox/native_flow.go)。

Linux TProxy 适配独立持有稳定 sing-box listener/UDP NAT，内核原目标进入同一
generation Router；进程事实由 sing-box 从 OS 查询。捕获 mark 与核心/透明回包的
绕过 mark 必须由权限事务独立预留，配置和候选均验证完整保护；协议自建 socket
未具备受保护租约时拒绝，不回退其他线路。监听器 API 不自动改系统规则；撤销捕获
必须先于关闭入口。隔离来宾已证明 IPv4 TCP/UDP/DNS 与真实进程规则，独立权限
服务已接线，完整安装、多发行版和 IPv6 验收仍缺。见 [Linux 透明入口验收](docs/verification/linux-transparent-guest.md)。

Linux 捕获安装组件由可信服务持有：先就绪核心/listener，再以显式预留的 mark、table、
priority 安装系统接管；拒绝冲突，不改 Underlay 的已有顺序。捕获 nft 表绑定持久
netlink socket 的内核所有权，进程死亡自动撤销；路由/规则用私有持久记录恢复，核对
boot/netns 与完整对象身份，不按表号或优先级批量清理。正常断开先撤销捕获再停核心。
该组件没有 DNS/出口策略，由独立 Linux 服务持有；详见
[安装恢复边界](docs/verification/linux-capture-transaction.md)。


Linux 独立服务仅接收有界 Profile 与有限连接操作，不接受裸 sing-box、系统规则或
任意 root 文件路径。Unix seqpacket 每条消息核验内核 UID，客户端先固定服务 UID；
安装策略/路径/资源由 root 私有策略控制。实例 nonce 与 revision 共同约束提交，
客户端的 PID/UID 不参与流量归因。marked egress 由内核按目标使用完整 Underlay，
Linux 显式模式允许无默认网卡；Apple/Android 的默认接口校验不变。系统 DNS 事实
尚无受保护后端时拒绝连接，不改公共 DNS；事实变化退出捕获，不能沿用过期配置。
见 [服务边界与当前限制](docs/agent/linux-service.md)。

### 5.4 网络变化与恢复

NWPath、默认路由、DNS 与 SSID 的同次物理变化合并为一个不含 SSID 的 network epoch；
稳定样本只形成最终 `(epoch, desired Scenario, Underlay fingerprint)` 的一笔 Switch。
Underlay fingerprint 由默认接口、接口集合、系统 DNS、默认接口 IPv4 地址与默认路由器组成，
NWPath 更新与 configd 对相应键的只读通知都触发重新采样；日志分别标注 `default-interface`、
`interface-set`、`system-dns`、`gateway`、`address`；
同一接口、同一 DNS 地址的两个网络也因网关或地址不同而换代。XDial 的 Provider 不创建接口、
不发布 IPv4 / IPv6 服务状态或 DNS 设置，其启停不改变指纹。
旧 epoch 的候选和退避回调失效，网络稳定不等于 Line 登录、握手或真实出口已恢复。

休眠至完整 `didWake` 之间只积累变化，Dark Wake 不停止已提交事务或创建候选。
唤醒后与 committed generation 实际所用 Underlay 等价才保留旧 generation；未能提交的
新样本不证明旧 generation 仍是当前事实，真实指纹变化才换代。Provider 仍 connected 时，
Line 自己处理协议恢复，不能仅凭路径不可用 / 恢复边沿重复连接。

同代 Line 局部恢复保持其他 Line、Ingress、Box 与 transaction ID 不变；局部预算耗尽、
Provider 掉线或共享组件失败才提升为完整恢复。休眠或无可用 Underlay 期间局部恢复只等待，
不消耗预算、不提升（见 [AnyConnect](#33-anyconnectd30)）。完整恢复在 Rollback 与系统接管移除后进行，
预算属于恢复 epoch `(desired Scenario, Underlay 指纹, 连通性代数)`：每个 epoch 按
2 / 5 / 10 / 20 / 30 秒最多五次，等待可用 Underlay 不计次；短暂连上不重置，同一事务
稳定五分钟后才清零。只看结构化失败码：凭据、登录、认证、配置引用与未分类错误立即结束。

网络相关失败耗尽预算后进入停泊：运行状态是已报告的断开，系统接管已移除，连接意图保留，
宿主从耗尽后重新捕获的 Underlay 起只读观察，不建数据面、不发网络请求。经沉降的新
epoch 交给恢复账本，不变成手动连接：指纹或 Scenario 变化立即授予新预算；同指纹仅有
连通性恢复边沿时，距该指纹上次授予满五分钟才授予，否则延后而不丢弃；自动授予每小时
最多六次，休眠期间不授予。XDial 自己的尝试与重复通知不产生授予；完整唤醒后 epoch 未变
只保留一次尝试；同一 epoch 另有 +2 / +5 / +10 / +20 / +30 分钟的单次慢尾，至多五次，
新 epoch 以完整预算取代它。每一步只由它等待的 transaction（开启恢复的失败或该尝试自己的
事务）落定的报告裁决；尝试排队、采样 Underlay 或准备期间，状态回调重读到的旧失败报告
不能结束或重新停泊它。尝试的成功只由它自己的事务证明：该事务 committed 且系统会话
connected，开启恢复的事务永远不能证明。系统会话状态不带事务，`startVPNTunnel` 返回后
可能过数秒才变化：Host 既没经 daemon 读到 Provider 写入的该事务副本、也没见到会话进入
活动态时读到的 inactive，不判定这次尝试；见过活动态而 Provider 日志应答却不含该事务，
按启动被拒落定（日志探测无应答时不判定）；读到副本之后的 inactive，按本事务会话结束落定。
至少 45 秒仍未证明时，活动的会话被停掉并以超时收尾，预算用完时仍 inactive 的以超时失败
落定并撤回 start；会话已 inactive 而 Host 无法再确认回滚的失败报告也作为结果。用户连接或
重试是新意图并获得新预算；显式断开、退出或删除目标 Scenario 立即结束停泊。

自动场景意图的瞬态失败保留 desired Scenario，按 2 / 5 / 10 秒最多重试三次，同 epoch
重复事件不重置。自动 epoch 的 Switch 最终失败后，若 committed generation 的默认接口
（名称与 index）已不在当前 Underlay 中，它无法被证明健康，升级为完整回滚与自动恢复，
结果可能是停泊；旧默认接口仍在时保留旧 generation。显式连接 / 切换失败与终止错误
不自动循环；显式断开立即取消所有恢复。重试进度、停泊、授予、延后、原始失败与断线历史
均为结构化事实，Underlay 指纹不对外暴露。

入口：[epoch 协调](macos/Shared/NetworkEpochSwitchCoordinator.swift)、
[恢复账本](macos/Shared/AutomaticRecoveryLedger.swift)。

## 6. 安装与更新（D37）

安装是持久平台前置条件，由 `InstallationReport` 表达，与 Scenario 的 `ConnectionPlan`
独立。首次启动和升级共用 bundle → helper → System Extension 流程；人工批准暂停在准确
步骤并在批准后继续。连接与 Tailscale 配置消费安装结果，不另行补注册组件。

安装可以替换 App、注册 helper、激活扩展，但不建立 Line、下载 RuleSet、启动 sing-box、
读取或改写 Underlay、创建 / 启用 Transparent Proxy 网络配置或提交 DNS / 路由。
安装成功不代表连接就绪；替换过程可能终止旧进程，[安装命令的实际副作用](docs/agent/development-builds.md)
与“安装不接管流量”是不同边界。

Linux 独立服务的管理员安装事务使用固定 binary/unit/摘要路径、root 私有 journal
与备份；连接事务只共享维护锁，不接受安装路径或脚本。升级先停止捕获与核心，
原来运行的服务在新进程 READY 后才提交；启动失败还原旧包，服务恢复仍保持未连接。
强杀后的显式恢复按提交记录选择旧/新版，归属冲突保留现场；不把摘要校验当作发行签名。
该入口尚非自动更新器，具体边界见 [Linux 升级验收](docs/verification/linux-upgrade.md)。

同通道替换要求身份与签名匹配，保留临时旧包，二次验签后清理；失败恢复旧包，下载原件保留。
helper / 扩展失败停在对应安装步骤，幂等重试以 macOS 结构化状态为依据。
退出在任何时候都成立，安装不能阻止退出：等待用户批准时直接退出；其他步骤先取消，
最多等 5 秒到达可恢复位置后仍退出。用户已开始的安装留有记录，下次启动（包括被新版替换后）自动续接。否则等待批准的旧版既退不出，
也会让替换它的新版一直等待。替换同样不依赖旧版配合：新版先请求退出，20 秒内未退出即强制结束，
按崩溃恢复接管遗留的连接事务与维护记录。等待批准的步骤在安装窗口给出具体位置和打开系统设置的入口。

Debug 与正式版的 App、嵌套组件、签名、运行目录、App Group、IPC 和维护标记独立。
发布通道不改变身份：beta 用正式版的 Release 配置、签名和发布合约构建，只在标签、源分支和
写入的清单上不同。
支持新版格式的构建共用 `~/.xdial/configuration/profiles.enc` 和
`com.xd.xdial.configuration` 的配置库密钥。仅当共享库不存在时，只读复制历史库或
转换旧配置为默认 Profile；原文件不修改，也不把新版修改回写旧版。现存库损坏或不可解密
时停止加载和保存，不能回退为空配置。跨进程写入通过文件锁和读取快照校验防止覆盖。
卸载不勾选删除数据时保留配置；明确勾选时删除共享库、已知旧配置和对应凭据，须先退出
其他版本以防重新写回。系统组件只由各自卸载事务维护。
FormalDevelopment 保留正式身份，仅用于正式身份验证。
签名 profile 与 entitlement 属于对应身份，不以移除能力或借用正式身份填补 Debug 签名缺口。
独立安装不代表两个数据面同时接管已被证明兼容。

更新候选来自固定 Pages 地址的完整、版本化清单，归档由 GitHub Releases 托管；
客户端不通过匿名 API 或 HTML 拼装候选。检查、下载和验证不改变当前连接，安装点击后才交接。
缓存不是安装许可：下载与安装前重新确认候选，撤回、变化或无法确认即停止；归档大小、摘要、
实际版本 / build 与嵌套签名共同绑定同一候选。验收包的固定 acceptance ID 与正式更新隔离。

通道不改变身份：beta 与正式版是同一个正式身份的 App，区别只在多读的 beta.json。stable.json
始终是结论的基准；用户开启 beta，或已装 beta 尚未被 stable 超过时才再读 beta.json，两份清单
各自保持缓存与修订链，取标签更高者。关闭开关不降级，已装 beta 只接收本 X.Y.Z 线的修复；
它尚未被 stable 超过时，beta.json 读取失败即无结论。新旧按发布标签的 SemVer 比较，候选
构建号必须高于当前；构建号倒序不是“已是最新”，而是失败。包内发布标签只用来认出已装 beta，
从而决定所在的线、新旧比较和是否多读 beta.json；它不替换或锁定 stable.json，不参与签名包
授权。更低构建号的宿主不覆盖已装 App：自行安装和 `--install-only` 在安装锁内拒绝；Finder
拖拽覆盖拦不住，之后扩展检查发现仍登记着更高构建号的扩展时不再激活，提示先卸载（不删数据）。
两道门禁都由被装进来的更旧 App 执行，只有带门禁的构建才会拦截；装回不带门禁的构建（v0.9.6
及更早）宿主仍被替换、与扩展失配，只能先卸载再安装。

入口：[安装状态机](macos/Shared/InstallationTransaction.swift)、
[构建与身份](docs/agent/development-builds.md)、[更新协议与发布](docs/agent/updates.md)。

## 7. RuleSet 资源（D28、D38）

URL RuleSet 的 `fetch_line_id` 默认 Direct，仅拥有资源的 DNS、HTTPS、重定向与下载路径；
解析和连接经过同一精确 Line。它不是 Scenario binding，不生成用户 route、普通 DNS 分域
或默认出口。只有 active Scenario 引用该 RuleSet 时才产生获取会话或请求。

有效缓存按 RuleSet 身份、URL 与格式寻址，连接直接使用；过期缓存在 Commit 后刷新，
当前运行保持启动快照，新副本下次连接生效，新鲜缓存无网络请求。
无有效缓存时，Commit 前建立限时、无系统 Ingress 或 Scenario binding 的获取会话，
完成所需出口、DNS、HTTPS / 重定向 / 全地址 SSRF、内容语义校验与原子落盘后停止。
失败归因对应 RuleSet，不静默换 Direct。

后台刷新可复用正式数据面已有的同一获取 Line，否则建立同类隔离会话；进程级单例冲突时
保留有效缓存、延后刷新，不破坏已提交连接。
旧 Subscription 的 GEOIP 资源仅来自显式 `geoip_rule_set_url_template`，含 `{code}` 且为 HTTPS
或规范化绝对 `file://` 路径；缺失或非法时生成失败，运行时无内置公共源或回退源。
整份配置导入适配可将 GEOIP 转成具名、显式 URL RuleSet：导入预览说明来源，
用户保存后按普通 RuleSet 的获取事务执行，来源可在本地配置中修改。此转换不为运行时
添加隐式 GEOIP 兜底，也不把凭据或用户实际配置烘入应用与仓库。

## 8. SSID 激活（D39）

`match_ssids` 精确、区分大小写且不跨 Scenario 重复，空列表仅手动选择。SSID 变化经与点击
相同的意图激活场景：已有连接意图则 Switch，已显式断开则只改变选择；无匹配保持当前场景。
手动选择持续到 SSID 下次变化。

SSID 只是触发条件，不证明网络可信，也不进入计划、日志、Debug、DNS、route 或 Underlay
快照。macOS 宿主在位置权限允许时读取，不进入 Provider；拒绝、Wi-Fi 关闭或读取失败不触发
自动动作，UI 显示权限状态，手动切换仍可用。iOS 已连接期间 App 可能被挂起，由 Packet Tunnel
Provider 读取并只在内存中用于选择场景，不写进共享存储或诊断（见 5.3）。

## 9. 历史兼容边界（D29、D31、D32、D34、D-CRASH）

- macOS 全流量 Packet Tunnel 会与既有 Enterprise Tunnel 互相取代，因此不作桌面入口；
  此限制不适用于 iOS / tvOS 当前入口。
- 旧原生 TUN 只保留在 CLI；helper 拒绝数据面命令，只恢复历史版本留下的 DNS 接管残留。
  默认接口只能来自启动前系统路由；`RTF_GLOBAL` Underlay 在建立 Line、获取规则或接管
  流量前被拒绝，避免入口绕过。
- 旧 DNS 接管地址为 TUN 地址 +1；原地址是本机 `RTF_LOCAL`，不能把查询送进 TUN。
  DNS 接管路径未就绪即连接失败。已记录地址与保留网段共同识别历史残留，清理能力仍保留。
- 旧 TUN 崩溃语义为清理接管、恢复 Underlay 并强通知；不能据此推断 Transparent Proxy
  的 Provider 崩溃与系统自动拉起已经具有相同保证。
- D29 移除的是旧内置 Tailscale 的越界实现；D33 重新引入盒内 Line，不恢复产品级 Underlay 特例。

历史路径入口：[DNS 接入与自愈](core/engine/dns_takeover.go)、
[Underlay](core/engine/underlay.go)、[Transparent Proxy 证据](docs/incidents/d35-transparent-proxy-evidence.md)。

## Android 接入（开发验收阶段）

Android 原生 VpnService 持有系统建立的 TUN fd，Go dup 后交给 sing-tun；
宿主和核心分别关闭自己持有的 fd。PlatformInterface 在 Android 不声明自身为
NetworkExtension。SocketProtector 在拨号前同步 protect 并绑定系统选定的
Underlay Network；失败返回错误，候选 Box 与复用 Line 继承相同保护契约。

Android 沙箱限制 Go 的 netlink 接口查询，宿主通过 NetworkInterface 与
LinkProperties 提供 name/index/type 与可选 facts（MTU/flags/addresses）。
有 facts 时采用系统快照，缺失时沿用 Apple 原有补齐路径；无效快照原子拒绝。
Android 同时将 LinkProperties 的 DNS 顺序传给 Go 编译器，Go 用它生成移动
DNS fallback transport，平台不自行解析或裁决。禁止把固定公共 DNS 的可达性
当作所有 Underlay 的前提。

当前仅完成隔离模拟器 Direct 的 DNS/HTTPS 接入验收；协议自建 socket、登录、
自动场景、网络恢复与 Apple 控制面迁移尚未交付，详见
[全平台计划](docs/plans/cross-platform.md)与[Android 验收](docs/verification/android-checkpoint.md)。
