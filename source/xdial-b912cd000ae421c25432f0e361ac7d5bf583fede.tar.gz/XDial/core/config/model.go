package config

import (
	"encoding/json"
)

// LineType 线路类型（流量出口）
type LineType string

const (
	LineTypeDirect      LineType = "direct"
	LineTypeSelector    LineType = "selector"
	LineTypeURLTest     LineType = "urltest"
	LineTypeVPN         LineType = "vpn"
	LineTypeTrojan      LineType = "trojan"
	LineTypeShadowsocks LineType = "shadowsocks"
	LineTypeVMess       LineType = "vmess"
	LineTypeAnyTLS      LineType = "anytls"
	LineTypeTailscale   LineType = "tailscale"
)

// Line 线路：流量从哪个通道出去
type Line struct {
	// Runtime ownership supplied by the global library; never an outbound choice.
	IdentityProfileID string          `json:"identity_profile_id,omitempty"`
	IdentityHostname  string          `json:"identity_hostname,omitempty"`
	GroupMembers      []string        `json:"group_members,omitempty"`
	GroupDefault      string          `json:"group_default,omitempty"`
	GroupURL          string          `json:"group_url,omitempty"`
	GroupInterval     string          `json:"group_interval,omitempty"`
	NativeOptions     json.RawMessage `json:"native_options,omitempty"`
	ID                string          `json:"id"`
	Name              string          `json:"name"`
	Type              LineType        `json:"type"`
	Enabled           bool            `json:"enabled"`

	// VPN (AnyConnect via sslcon)
	VPNServer   string `json:"vpn_server,omitempty"`
	VPNUsername string `json:"vpn_username,omitempty"`
	VPNPassword string `json:"vpn_password,omitempty"`

	// Trojan
	TrojanServer   string `json:"trojan_server,omitempty"`
	TrojanPort     int    `json:"trojan_port,omitempty"`
	TrojanPassword string `json:"trojan_password,omitempty"`
	TrojanSNI      string `json:"trojan_sni,omitempty"`

	// Shadowsocks
	SSServer string `json:"ss_server,omitempty"`
	SSPort   int    `json:"ss_port,omitempty"`
	SSMethod string `json:"ss_method,omitempty"`
	SSPass   string `json:"ss_password,omitempty"`

	// VMess
	VMessServer string `json:"vmess_server,omitempty"`
	VMessPort   int    `json:"vmess_port,omitempty"`
	VMessUUID   string `json:"vmess_uuid,omitempty"`
	VMessAltID  int    `json:"vmess_alt_id,omitempty"`

	// AnyTLS
	AnyTLSServer                   string   `json:"anytls_server,omitempty"`
	AnyTLSPort                     int      `json:"anytls_port,omitempty"`
	AnyTLSPassword                 string   `json:"anytls_password,omitempty"`
	AnyTLSSNI                      string   `json:"anytls_sni,omitempty"`
	AnyTLSClientFingerprint        string   `json:"anytls_client_fingerprint,omitempty"`
	AnyTLSALPN                     []string `json:"anytls_alpn,omitempty"`
	AnyTLSIdleSessionCheckInterval int      `json:"anytls_idle_session_check_interval,omitempty"`
	AnyTLSIdleSessionTimeout       int      `json:"anytls_idle_session_timeout,omitempty"`
	AnyTLSMinIdleSession           int      `json:"anytls_min_idle_session,omitempty"`

	// Tailscale
	//
	// 身份（设备名、登录态、state 目录）不在这里 —— 它是整个 Profile 全局唯一的一份，
	// 见 Profile.Tailscale。Line 上只留“这条线路怎么用那个 tailnet”：
	// 选哪个出口，以及是否显式启用这条线路的 MagicDNS 与节点路由。
	// 两者都只在 Line 被 active Scenario 引用时进入数据面。
	TailscaleExitNode string `json:"tailscale_exit_node,omitempty"`
	TailscaleMagicDNS bool   `json:"tailscale_magic_dns,omitempty"`

	// TailscaleAuthKey 仅为旧移动端 Profile 兼容字段。D33 桌面控制面不得持久化它；
	// Auth Key 只在用户显式注册请求里瞬时进入 setup session，日常桌面配置生成会忽略
	// 这个字段。
	//
	// 只能用可复用的持久 key，不要 ephemeral key：ephemeral 节点在会话关闭后
	// 被控制面立刻回收，下次复用 state 会被要求重新登录（见 buildTailscaleEndpoint）。
	//
	// 敏感值：与 VPNPassword 同级，任何对外暴露 profile 的地方（调试接口、日志）
	// 都必须脱敏。
	TailscaleAuthKey string `json:"tailscale_auth_key,omitempty"`

	// 通用传输选项
	TFO bool `json:"tfo,omitempty"` // TCP Fast Open
	UDP bool `json:"udp,omitempty"` // UDP relay / over TCP

	// AllowInsecure 跳过 TLS 证书验证（自签场景显式 opt-in）。默认 false=验证：
	// 之前 VPN 硬编码跳过验证、trojan 按 SNI!=server 启发式跳过，都是不安全默认，
	// 公开仓库里对全世界暴露 MITM 窃取凭据的面。
	AllowInsecure bool `json:"allow_insecure,omitempty"`
}

// RuleSetType 规则类型（流量匹配规则）
type RuleSetType string

const (
	RuleSetTypeURL         RuleSetType = "url"
	RuleSetTypeNative      RuleSetType = "native"
	RuleSetTypeManual      RuleSetType = "manual"
	RuleSetTypeApplication RuleSetType = "application"
	RuleSetTypeGroup       RuleSetType = "group"
)

// RuleSetMatchKind 是 NetworkExtension 在严格下载并解析远程规则集后写入的
// 单次生成元数据。它不属于用户配置，也不会持久化；Transparent Proxy 用它
// 区分“先按 Line 解析域名”和“先按系统 DNS 得到 IP”这两个阶段。
type RuleSetMatchKind string

const (
	RuleSetMatchUnknown RuleSetMatchKind = ""
	RuleSetMatchDomain  RuleSetMatchKind = "domain"
	RuleSetMatchIP      RuleSetMatchKind = "ip"
	RuleSetMatchMixed   RuleSetMatchKind = "mixed"
)

// ApplicationMatch 是一个由用户选择的 macOS App Bundle。BundleIdentifier
// 匹配系统直接提供的 source-app 身份；Path 对 audit-token 解析出的可执行路径
// 做边界匹配。旧 Profile 里的 identities 字段由 JSON 解码器忽略。
type ApplicationMatch struct {
	Name             string `json:"name,omitempty"`
	Path             string `json:"path"`
	BundleIdentifier string `json:"bundle_identifier,omitempty"`
}

// RuleSet 规则：匹配哪些流量
type RuleSet struct {
	// Conditions are ordered, private matching resources of one user RuleSet.
	// Each retains its DNS behavior; only the Scenario supplies an outbound.
	Conditions []RuleSet `json:"conditions,omitempty"`
	// NoResolve keeps imported IP rules from initiating a DNS lookup to match.
	NoResolve  bool            `json:"no_resolve,omitempty"`
	NativeRule json.RawMessage `json:"native_rule,omitempty"`
	ID         string          `json:"id"`
	Name       string          `json:"name"`
	Type       RuleSetType     `json:"type"`
	Enabled    bool            `json:"enabled"`

	// URL 规则（远程规则集）
	URL         string `json:"url,omitempty"`
	Format      string `json:"format,omitempty"`
	FetchLineID string `json:"fetch_line_id,omitempty"`
	// Invert 取反整个 RuleSet 的匹配条件，不改变 Scenario 中的线路绑定。
	// 例如“海外 IP”可以复用国内 IP 列表并取反，避免维护补集。
	Invert bool `json:"invert,omitempty"`

	// 手动规则
	Domains []string `json:"domains,omitempty"`
	CIDRs   []string `json:"cidrs,omitempty"`

	// 应用规则。Applications 保存根 Bundle ID 与 App Bundle 前缀；Processes 保存用户显式输入的
	// Surge PROCESS-NAME 表达式（文件名/通配符、完整路径或末尾带 / 的路径前缀）。
	// 二者都只描述匹配内容，不携带任何 Line 或 Scenario 信息；只有 active Scenario 的
	// binding 才会把它们编译为数据面规则。
	Applications []ApplicationMatch `json:"applications,omitempty"`
	Processes    []string           `json:"processes,omitempty"`

	RuntimeMatchKind RuleSetMatchKind `json:"-"`
}

// EffectiveFetchLineID returns the explicitly selected source Line. Legacy
// RuleSets without the field retain Direct as their acquisition path.
func (r RuleSet) EffectiveFetchLineID() string {
	if r.FetchLineID != "" {
		return r.FetchLineID
	}
	return builtinDirectLineID
}

// RuleBinding 场景中的一条绑定：规则→线路（或订阅）
type RuleBinding struct {
	ConditionIDs   []string `json:"condition_ids,omitempty"`
	RuleSetID      string   `json:"rule_set_id"`
	LineID         string   `json:"line_id,omitempty"`
	SubscriptionID string   `json:"subscription_id,omitempty"`
}

// Scenario 场景：一组规则→线路的绑定
type Scenario struct {
	// MatchOrder preserves imported interleaving while the editor groups by destination.
	// Empty means execute complete rules in Bindings order.
	MatchOrder            []string      `json:"match_order,omitempty"`
	ID                    string        `json:"id"`
	Name                  string        `json:"name"`
	Icon                  string        `json:"icon,omitempty"`
	MatchSSIDs            []string      `json:"match_ssids,omitempty"`
	Bindings              []RuleBinding `json:"bindings"`
	DefaultLineID         string        `json:"default_line_id"`
	DefaultSubscriptionID string        `json:"default_subscription_id,omitempty"`
}

// ProxyGroup 订阅内的策略组
type ProxyGroup struct {
	Name     string   `json:"name"`
	Type     string   `json:"type"`    // select / urltest / fallback
	Proxies  []string `json:"proxies"` // 节点名或其他组名
	Selected string   `json:"selected,omitempty"`
	URL      string   `json:"url,omitempty"`
	Interval int      `json:"interval,omitempty"`
}

// SubscriptionRule 订阅内的规则
type SubscriptionRule struct {
	// SourceID is a parse-time boundary for an expanded remote rule set.
	SourceID   string `json:"-"`
	SourceName string `json:"-"`
	Options    string `json:"options,omitempty"`
	Type       string `json:"type"`  // RULE-SET / DOMAIN-SUFFIX / DOMAIN / IP-CIDR / GEOIP / FINAL
	Value      string `json:"value"` // URL 或匹配值
	Group      string `json:"group"` // 策略组名
}

// Subscription 订阅：通过 URL 批量导入的完整配置
type Subscription struct {
	ID                      string             `json:"id"`
	Name                    string             `json:"name"`
	URL                     string             `json:"url"`
	Format                  string             `json:"format"`
	Enabled                 bool               `json:"enabled"`
	Strategy                string             `json:"strategy"`
	Selected                string             `json:"selected,omitempty"`
	Lines                   []Line             `json:"lines"`
	ProxyGroups             []ProxyGroup       `json:"proxy_groups,omitempty"`
	Rules                   []SubscriptionRule `json:"rules,omitempty"`
	GeoIPRuleSetURLTemplate string             `json:"geoip_rule_set_url_template,omitempty"`
	UpdatedAt               int64              `json:"updated_at"`
	TestURL                 string             `json:"test_url,omitempty"`
	TestInterval            int                `json:"test_interval,omitempty"`
}

// TailscaleIdentity 是本机在 tailnet 中的身份，整个 Profile 全局唯一一份。
//
// 一个 tsnet 实例就是 tailnet 里的一台设备，两个实例不能共用同一份 state
// （node key 不能同时活跃在两处），所以身份必须是全局的：所有 Tailscale 线路
// 共享同一次登录、同一个 state 目录，退出登录一次全部失效。
type TailscaleIdentity struct {
	// Hostname 注册到 tailnet 的设备名，首次登录时自动生成后固定不变
	// （见 GenerateTailscaleHostname）。不由用户填写 —— 手填既容易和官方
	// 客户端注册的同名设备混淆，也无法保证唯一。
	Hostname string `json:"hostname,omitempty"`
}

// ImportAdjustment records a bounded compatibility adaptation. Unlike an
// unsupported rule, it does not discard a route or require a missing capability.
type ImportAdjustment struct {
	Code  string `json:"code"`
	Count int    `json:"count"`
}

// Profile 完整配置
type Profile struct {
	ImportAdjustments []ImportAdjustment `json:"import_adjustments,omitempty"`
	// ImportWarnings retains source rules with no equivalent in sing-box. They
	// are shown for review, never compiled as if they were supported matches.
	ImportWarnings   []SubscriptionRule `json:"import_warnings,omitempty"`
	ID               string             `json:"profile_id,omitempty"`
	Lines            []Line             `json:"lines"`
	RuleSets         []RuleSet          `json:"rule_sets"`
	Scenarios        []Scenario         `json:"scenarios"`
	Subscriptions    []Subscription     `json:"subscriptions,omitempty"`
	ActiveScenarioID string             `json:"active_scenario_id"`
	Tailscale        TailscaleIdentity  `json:"tailscale,omitempty"`
}

// ParseProfile 从 JSON 解码当前正式 Profile 契约。
func ParseProfile(data []byte) (*Profile, error) {
	var p Profile
	if err := json.Unmarshal(data, &p); err != nil {
		return nil, err
	}
	return &p, nil
}

func (p *Profile) ActiveScenario() *Scenario {
	for i := range p.Scenarios {
		if p.Scenarios[i].ID == p.ActiveScenarioID {
			return &p.Scenarios[i]
		}
	}
	return nil
}

func (p *Profile) FindLine(id string) *Line {
	for i := range p.Lines {
		if p.Lines[i].ID == id {
			return &p.Lines[i]
		}
	}
	return nil
}

func (p *Profile) FindRuleSet(id string) *RuleSet {
	for i := range p.RuleSets {
		if p.RuleSets[i].ID == id {
			return &p.RuleSets[i]
		}
	}
	return nil
}

func (p *Profile) FindSubscription(id string) *Subscription {
	for i := range p.Subscriptions {
		if p.Subscriptions[i].ID == id {
			return &p.Subscriptions[i]
		}
	}
	return nil
}

// VPNLine 返回第一个 VPN 类型的线路（用于获取 VPN 服务器地址）
func (p *Profile) VPNLine() *Line {
	for i := range p.Lines {
		if p.Lines[i].Type == LineTypeVPN {
			return &p.Lines[i]
		}
	}
	return nil
}

// ActiveVPNLine 返回活动场景实际引用的 VPN 线路。
func (p *Profile) ActiveVPNLine() *Line {
	scenario := p.ActiveScenario()
	if scenario == nil {
		return nil
	}
	for _, binding := range scenario.Bindings {
		line := p.FindLine(binding.LineID)
		if line != nil && line.Enabled && line.Type == LineTypeVPN {
			return line
		}
	}
	line := p.FindLine(scenario.DefaultLineID)
	if line != nil && line.Enabled && line.Type == LineTypeVPN {
		return line
	}
	return nil
}
