package config

import (
	"fmt"
	"path/filepath"
	"strings"
)

// 本文件实现 INV6：场景引用的完整性检查，把"引用解析不了"这件事分成两类处理。
//
//	INV6a 悬空引用（FindLine/FindRuleSet/FindSubscription 返回 nil，
//	      或绑定压根没写出口）—— 配置已经损坏，生成直接失败。
//	      绝不允许"整条规则蒸发"式的静默降级：用户以为绑定生效了，
//	      实际流量落到 final，正是架构约束禁止的静默降级到 direct。
//
//	INV6b 显式禁用（对象存在但 Enabled=false）—— 这是用户自己的选择，
//	      允许跳过，但必须结构化上报，让 daemon/UI 能把"这条绑定当前没生效"
//	      展示出来，而不是悄悄少一条规则。
//
// 注意 INV6a 的检查不受 Enabled 影响：一条绑定即使当前被禁用，
// 它指向的 line/subscription 也必须真实存在。否则用户哪天一勾选，
// 悬空引用就变成静默错路由。

// builtinDirectLineID 是保留的线路 ID：direct outbound 由生成器无条件产出，
// 所以场景引用 "direct" 时即使 profile 的 Lines 里没有对应条目也不算悬空。
// 这是既有约定（默认 profile 里有这条线路，但大量精简配置直接引用它）。
const builtinDirectLineID = "direct"

// ProfileWarningKind 标识一条降级警告的类别。字符串值会进 JSON，
// 供 daemon/UI 直接消费，不要随意改名。
type ProfileWarningKind string

const (
	// WarningDisabledRuleSet 绑定引用的规则存在但被禁用，整条绑定不生效。
	WarningDisabledRuleSet ProfileWarningKind = "disabled_rule_set"
	// WarningDisabledLine 绑定引用的线路存在但被禁用，该绑定不产生路由规则。
	WarningDisabledLine ProfileWarningKind = "disabled_line"
	// WarningDisabledSubscription 绑定引用的订阅存在但被禁用。
	WarningDisabledSubscription ProfileWarningKind = "disabled_subscription"
	// WarningDisabledDefaultLine 场景默认出口线路被禁用，默认出口回落 direct。
	WarningDisabledDefaultLine ProfileWarningKind = "disabled_default_line"
	// WarningDisabledDefaultSubscription 场景默认出口订阅被禁用，默认出口回落 direct。
	WarningDisabledDefaultSubscription ProfileWarningKind = "disabled_default_subscription"
	// WarningUnavailableLine 仅为旧 JSON/API 兼容保留。active Scenario 直接引用的 enabled
	// Line 无法生成 outbound 时现在必须返回 error，不再产生此 warning。
	WarningUnavailableLine ProfileWarningKind = "unavailable_line"
	// WarningUnavailableSubscription 仅为旧 JSON/API 兼容保留。active Scenario 直接引用的
	// enabled Subscription 无法生成主 outbound 时现在必须返回 error。
	WarningUnavailableSubscription ProfileWarningKind = "unavailable_subscription"
)

// ProfileWarning 是一条"配置能生成，但某个绑定实际不生效"的结构化提示。
// 与 error 的区别：error 表示拒绝生成配置，warning 表示配置照生成但用户必须知情。
type ProfileWarning struct {
	Kind           ProfileWarningKind `json:"kind"`
	ScenarioID     string             `json:"scenario_id,omitempty"`
	RuleSetID      string             `json:"rule_set_id,omitempty"`
	LineID         string             `json:"line_id,omitempty"`
	SubscriptionID string             `json:"subscription_id,omitempty"`
	Message        string             `json:"message"`
}

func (w ProfileWarning) String() string {
	return w.Message
}

// CollectProfileWarnings 校验活动场景的引用完整性。
//
// 返回 error = 配置里有悬空引用（INV6a），GenerateSingBox* 也一定会用同一份逻辑拒绝生成。
// 返回 warnings = 有对象存在但被显式禁用（INV6b），生成会继续，但调用方
// （daemon / UI）必须把这些提示展示给用户。
//
// active Scenario 直接引用的 enabled Line / Subscription 若生成不出 outbound 则返回
// error。它不是用户主动禁用，而是无法兑现 Scenario 已声明的出口；继续生成会让绑定消失
// 或让默认出口落到 direct，违反 fail-closed。
//
// 这是一个独立的只读入口，刻意不改 GenerateSingBox / GenerateSingBoxFor /
// GenerateSingBoxDesktop 的签名，现有调用方（core/engine、core/libbox）零改动。
func CollectProfileWarnings(profile *Profile) ([]ProfileWarning, error) {
	var groupErr error
	profile, groupErr = ExpandRuleSetGroups(profile)
	if groupErr != nil {
		return nil, groupErr
	}
	if profile == nil {
		return nil, fmt.Errorf("profile is nil")
	}
	scenario := profile.ActiveScenario()
	if scenario == nil {
		return nil, fmt.Errorf("no active scenario")
	}
	return inspectScenarioReferences(profile, scenario)
}

// inspectScenarioReferences 是 INV6 的唯一实现点：generateSingBox 与
// CollectProfileWarnings 都走它，保证"能不能生成"和"为什么某条没生效"的判定一致。
func inspectScenarioReferences(profile *Profile, scenario *Scenario) ([]ProfileWarning, error) {
	var warnings []ProfileWarning
	active, _ := effectiveActiveTargetIDs(profile, scenario)
	for id := range active {
		if line := profile.FindLine(id); line.IsGroup() {
			if err := validateGroupDependencies(profile, line); err != nil {
				return nil, err
			}
		}
	}
	for _, binding := range scenario.Bindings {
		if rule := profile.FindRuleSet(binding.RuleSetID); rule != nil && rule.Type == RuleSetTypeNative {
			if err := validateNativeRule(rule.NativeRule); err != nil {
				return nil, err
			}
		}
	}
	warn := func(w ProfileWarning) {
		w.ScenarioID = scenario.ID
		warnings = append(warnings, w)
	}

	for index := range scenario.Bindings {
		binding := scenario.Bindings[index]

		if binding.RuleSetID == "" {
			return nil, fmt.Errorf("scenario %q binding #%d has no rule set reference", scenario.ID, index+1)
		}
		ruleSet := profile.FindRuleSet(binding.RuleSetID)
		if ruleSet == nil {
			return nil, fmt.Errorf("scenario %q references missing rule set %q", scenario.ID, binding.RuleSetID)
		}

		// 先把出口引用的"存在性"验掉（不看 Enabled）——见文件头注释。
		var (
			line         *Line
			subscription *Subscription
		)
		switch {
		case binding.SubscriptionID != "":
			subscription = profile.FindSubscription(binding.SubscriptionID)
			if subscription == nil {
				return nil, fmt.Errorf("scenario %q binds rule set %q to missing subscription %q",
					scenario.ID, binding.RuleSetID, binding.SubscriptionID)
			}
		case binding.LineID == builtinDirectLineID:
			// 内建直连：不需要 profile 里有对应 Line，也没有可禁用的对象。
		case binding.LineID != "":
			line = profile.FindLine(binding.LineID)
			if line == nil {
				return nil, fmt.Errorf("scenario %q binds rule set %q to missing line %q",
					scenario.ID, binding.RuleSetID, binding.LineID)
			}
		default:
			return nil, fmt.Errorf("scenario %q binds rule set %q to neither a line nor a subscription",
				scenario.ID, binding.RuleSetID)
		}

		switch ruleSet.Type {
		case RuleSetTypeURL, RuleSetTypeManual, RuleSetTypeApplication, RuleSetTypeNative:
		default:
			return nil, fmt.Errorf(
				"scenario %q references rule set %q with unsupported type %q",
				scenario.ID,
				ruleSet.ID,
				ruleSet.Type,
			)
		}

		// 规则被禁用时整条绑定不生效，出口那侧就不再重复提示。
		if !ruleSet.Enabled {
			warn(ProfileWarning{
				Kind:           WarningDisabledRuleSet,
				RuleSetID:      ruleSet.ID,
				LineID:         binding.LineID,
				SubscriptionID: binding.SubscriptionID,
				Message: fmt.Sprintf("规则 %q 已禁用，场景 %q 里绑定它的分流不生效",
					ruleSetLabel(ruleSet), scenarioLabel(scenario)),
			})
			continue
		}
		if ruleSet.Type == RuleSetTypeURL && strings.TrimSpace(ruleSet.URL) == "" {
			return nil, fmt.Errorf("enabled rule set %q requires a URL before connection", ruleSet.ID)
		}
		if ruleSet.Type == RuleSetTypeURL && ruleSet.FetchLineID != "" {
			if ruleSet.FetchLineID != builtinDirectLineID {
				fetchLine := profile.FindLine(ruleSet.FetchLineID)
				if fetchLine == nil {
					return nil, fmt.Errorf(
						"scenario %q updates rule set %q through missing line %q",
						scenario.ID,
						ruleSet.ID,
						ruleSet.FetchLineID,
					)
				}
				if !fetchLine.Enabled || !lineHasUsableOutbound(fetchLine) {
					return nil, fmt.Errorf(
						"scenario %q updates rule set %q through unavailable line %q",
						scenario.ID,
						ruleSet.ID,
						ruleSet.FetchLineID,
					)
				}
			}
		}
		if ruleSet.Type == RuleSetTypeApplication {
			if err := validateApplicationRuleSet(ruleSet); err != nil {
				return nil, fmt.Errorf("scenario %q references invalid application rule set %q: %w",
					scenario.ID, ruleSet.ID, err)
			}
		}

		if subscription != nil {
			if !subscription.Enabled {
				warn(ProfileWarning{
					Kind:           WarningDisabledSubscription,
					RuleSetID:      ruleSet.ID,
					SubscriptionID: subscription.ID,
					Message: fmt.Sprintf("订阅 %q 已禁用，规则 %q 绑定的流量回落到场景默认出口",
						subscriptionLabel(subscription), ruleSetLabel(ruleSet)),
				})
				continue
			}
			if !subscriptionHasUsableOutbound(subscription) {
				return nil, fmt.Errorf(
					"scenario %q binds enabled rule set %q to enabled subscription %q, but the subscription cannot generate an outbound",
					scenario.ID,
					ruleSet.ID,
					subscription.ID,
				)
			}
			if err := validateSubscriptionGeoIPRuleSetResources(subscription); err != nil {
				return nil, fmt.Errorf(
					"scenario %q uses an invalid subscription %q: %w",
					scenario.ID,
					subscription.ID,
					err,
				)
			}
			continue
		}
		if line == nil {
			// 内建直连，恒可用。
			continue
		}

		if !line.Enabled {
			warn(ProfileWarning{
				Kind:      WarningDisabledLine,
				RuleSetID: ruleSet.ID,
				LineID:    line.ID,
				Message: fmt.Sprintf("线路 %q 已禁用，规则 %q 绑定的流量回落到场景默认出口",
					lineLabel(line), ruleSetLabel(ruleSet)),
			})
			continue
		}
		if !lineHasUsableOutbound(line) {
			return nil, fmt.Errorf(
				"scenario %q binds enabled rule set %q to enabled line %q (type %q), but the line cannot generate an outbound",
				scenario.ID,
				ruleSet.ID,
				line.ID,
				line.Type,
			)
		}
	}

	// 默认出口：悬空同样报错；禁用则回落 direct 并告警（generateSingBox 里
	// defaultTag 的解析结果与这里一一对应）。
	switch {
	case scenario.DefaultSubscriptionID != "":
		subscription := profile.FindSubscription(scenario.DefaultSubscriptionID)
		if subscription == nil {
			return nil, fmt.Errorf("scenario %q default subscription %q does not exist",
				scenario.ID, scenario.DefaultSubscriptionID)
		}
		if !subscription.Enabled {
			warn(ProfileWarning{
				Kind:           WarningDisabledDefaultSubscription,
				SubscriptionID: subscription.ID,
				Message: fmt.Sprintf("场景 %q 的默认出口订阅 %q 已禁用，默认出口回落直连",
					scenarioLabel(scenario), subscriptionLabel(subscription)),
			})
		} else if !subscriptionHasUsableOutbound(subscription) {
			return nil, fmt.Errorf(
				"scenario %q uses enabled subscription %q as its default, but the subscription cannot generate an outbound",
				scenario.ID,
				subscription.ID,
			)
		} else if err := validateSubscriptionGeoIPRuleSetResources(subscription); err != nil {
			return nil, fmt.Errorf(
				"scenario %q uses an invalid default subscription %q: %w",
				scenario.ID,
				subscription.ID,
				err,
			)
		}
	case scenario.DefaultLineID == builtinDirectLineID:
		// 内建直连默认出口，恒可用。
	case scenario.DefaultLineID != "":
		line := profile.FindLine(scenario.DefaultLineID)
		if line == nil {
			return nil, fmt.Errorf("scenario %q default line %q does not exist",
				scenario.ID, scenario.DefaultLineID)
		}
		if !line.Enabled {
			warn(ProfileWarning{
				Kind:   WarningDisabledDefaultLine,
				LineID: line.ID,
				Message: fmt.Sprintf("场景 %q 的默认出口线路 %q 已禁用，默认出口回落直连",
					scenarioLabel(scenario), lineLabel(line)),
			})
		} else if !lineHasUsableOutbound(line) {
			return nil, fmt.Errorf(
				"scenario %q uses enabled line %q (type %q) as its default, but the line cannot generate an outbound",
				scenario.ID,
				line.ID,
				line.Type,
			)
		}
	default:
		// An empty Scenario is a valid persisted editing state, but it is not
		// connectable. Treating an omitted default as Direct would turn an
		// unfinished declaration into effective traffic policy.
		return nil, fmt.Errorf(
			"scenario %q has no default line or subscription",
			scenario.ID,
		)
	}

	return warnings, nil
}

func validateApplicationRuleSet(ruleSet *RuleSet) error {
	if len(ruleSet.Applications) == 0 && len(ruleSet.Processes) == 0 {
		return fmt.Errorf("application process selectors are empty")
	}
	for applicationIndex, application := range ruleSet.Applications {
		if _, ok := canonicalApplicationBundlePath(application.Path); !ok {
			return fmt.Errorf("application #%d bundle path is invalid", applicationIndex+1)
		}
		if application.BundleIdentifier != "" {
			if _, ok := canonicalApplicationBundleIdentifier(application.BundleIdentifier); !ok {
				return fmt.Errorf("application #%d bundle identifier is invalid", applicationIndex+1)
			}
		}
	}
	for processIndex, process := range ruleSet.Processes {
		if _, ok := canonicalApplicationProcessSelector(process); !ok {
			return fmt.Errorf("process #%d selector is invalid", processIndex+1)
		}
	}
	return nil
}

// canonicalApplicationBundlePath validates the persisted Surge-style App
// Bundle selector without consulting the live filesystem. Planning remains
// side-effect free, while the Provider can compare the exact same lexical path
// against the audit-token-derived executable path at flow time.
func canonicalApplicationBundlePath(raw string) (string, bool) {
	if raw == "" || len(raw) > 4096 || strings.TrimSpace(raw) != raw ||
		strings.IndexByte(raw, 0) >= 0 || !filepath.IsAbs(raw) {
		return "", false
	}
	cleaned := filepath.Clean(raw)
	base := filepath.Base(cleaned)
	if cleaned != raw || len(base) <= len(".app") ||
		!strings.HasSuffix(strings.ToLower(base), ".app") {
		return "", false
	}
	return cleaned, true
}

// lineHasUsableOutbound 判断一条 enabled 线路能不能真的生成出 outbound。
// direct / vpn / tailscale 由生成器直接构造，恒可用；代理类线路参数不全时
// buildProxyOutbound 返回 nil。active Scenario 直接引用这种线路时必须拒绝规划和生成，
// 不能把缺失 outbound 降为 warning。
func lineHasUsableOutbound(line *Line) bool {
	switch line.Type {
	case LineTypeDirect, LineTypeVPN, LineTypeTailscale:
		return true
	default:
		return buildProxyOutbound(line) != nil
	}
}

// LineHasUsableOutbound exposes the generator's exact Line capability check to
// control-plane consumers. Callers must not reimplement protocol validation:
// accepting a node here that buildProxyOutbound later drops would make a
// subscription look ready while its actual outbound is absent.
func LineHasUsableOutbound(line *Line) bool {
	return lineHasUsableOutbound(line)
}

// subscriptionHasUsableOutbound 判断订阅能否生成出可被规则引用的主 tag。
// 平台只影响 urltest 的探测 URL，不影响 mainTag 是否存在，故固定用 PlatformMacOS。
func subscriptionHasUsableOutbound(subscription *Subscription) bool {
	_, mainTag, _ := buildSubscriptionOutbounds(subscription, PlatformMacOS)
	return mainTag != ""
}

func scenarioLabel(scenario *Scenario) string {
	if scenario.Name != "" {
		return scenario.Name
	}
	return scenario.ID
}

func lineLabel(line *Line) string {
	if line.Name != "" {
		return line.Name
	}
	return line.ID
}

func ruleSetLabel(ruleSet *RuleSet) string {
	if ruleSet.Name != "" {
		return ruleSet.Name
	}
	return ruleSet.ID
}

func subscriptionLabel(subscription *Subscription) string {
	if subscription.Name != "" {
		return subscription.Name
	}
	return subscription.ID
}
