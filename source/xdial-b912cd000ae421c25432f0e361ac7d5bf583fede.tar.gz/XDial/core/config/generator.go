package config

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"net/netip"
	"path"
	"strings"
	"unicode"
	"unicode/utf8"

	"github.com/google/uuid"
)

type SingBoxConfig struct {
	Log          map[string]interface{}   `json:"log"`
	DNS          map[string]interface{}   `json:"dns"`
	Endpoints    []map[string]interface{} `json:"endpoints,omitempty"`
	Inbounds     []map[string]interface{} `json:"inbounds"`
	Outbounds    []map[string]interface{} `json:"outbounds"`
	Route        map[string]interface{}   `json:"route"`
	Experimental map[string]interface{}   `json:"experimental,omitempty"`
}

// 桌面端“逐线路查公网地址”使用的域名；移动端不使用 Clash API/
// test-out，也不应该暗中改写这些域名的路由。
var testDomains = []string{"ip.sb", "ipinfo.io", "ip-api.com"}

const (
	testSelectorTag               = "test-out"
	clashAPIController            = "127.0.0.1:9090"
	connectivityDirectRuleSetID   = "xdial-connectivity-direct"
	connectivityOutboundRuleSetID = "xdial-connectivity-anyconnect"
	mobilePublicDNSTag            = "xdial-public-dns"
	mobileDispatcherDNSTag        = "xdial-mobile-dns"
	transparentSystemDNSTag       = "xdial-system-dns"
	transparentEnterpriseDNSTag   = "xdial-anyconnect-dns"
	transparentProxyDoHIPv4Server = "1.1.1.1"
	transparentProxyDoHIPv6Server = "2606:4700:4700::1111"
	// MobilePublicDNSTag is exported because it is also how Direct resolves its
	// own hostnames in the Network Extension (route default_domain_resolver).
	MobilePublicDNSTag = mobilePublicDNSTag
	// TransparentNativeDNSTag is exported so isolated Direct RuleSet refresh
	// sessions use the same macOS-native resolver contract as Direct traffic.
	TransparentNativeDNSTag       = "xdial-native-dns"
	tailnetSingleLabelDomainRegex = `^[^.]+$`
	minAnyTLSDurationSeconds      = 6
	maxAnyTLSDurationSeconds      = 3600
	maxAnyTLSMinIdleSession       = 64
	maxAnyTLSALPNProtocols        = 8
	maxAnyTLSALPNProtocolBytes    = 255
)

var anyTLSClientFingerprints = map[string]struct{}{
	"chrome_psk":                 {},
	"chrome_psk_shuffle":         {},
	"chrome_padding_psk_shuffle": {},
	"chrome_pq":                  {},
	"chrome_pq_psk":              {},
	"chrome":                     {},
	"firefox":                    {},
	"edge":                       {},
	"safari":                     {},
	"360":                        {},
	"qq":                         {},
	"ios":                        {},
	"android":                    {},
	"random":                     {},
	"randomized":                 {},
}

// Platform 决定 sing-box 配置生成的目标运行环境。
//
// PlatformMacOS(零值)= 桌面场景:sing-box 作为外部子进程运行,靠 tun +
// auto_route 抓包、route.default_interface 绑定到宿主在启动前从系统默认路由
// 读取的 Underlay，
// clash_api 暴露 controller、cache_file 用相对路径(子进程 cwd 下)。
//
// PlatformNE = tvOS/iOS 的 Packet Tunnel 场景:sing-box 作为库跑在扩展进程内,
// 无 root、无子进程、路由由 NEPacketTunnelNetworkSettings 在 Swift 侧接管,读包来源
// 是系统 packetFlow。因此 tun inbound 只保留最小字段(type/address/mtu),不生成
// auto_route/strict_route/stack/route_exclude_address,也不开
// clash_api;cache_file 必须用调用方传入的沙盒内绝对路径(basePath)。
//
// PlatformTransparentProxy = macOS Transparent Proxy 系统扩展：sing-box 同样作为库
// 跑在扩展进程内，但入口是只监听 loopback、带随机会话凭据的 SOCKS5 inbound。
// Swift 只把 NEAppProxyFlow 的字节搬到该入口；TCP/UDP/DNS 仍由同一份 sing-box
// 配置裁决。该平台把宿主在启动前从系统默认路由读取的接口写入
// route.default_interface；这让 Provider 进程里的出站 socket 延续既有 Underlay，
// 而不是依赖 Network Extension 进程可能退化到物理接口的默认视角。
type Platform int

const (
	PlatformMacOS Platform = iota
	PlatformNE
	PlatformTransparentProxy
)

func (p Platform) isNetworkExtension() bool {
	return p == PlatformNE || p == PlatformTransparentProxy
}

func (p Platform) isDesktop() bool {
	return p == PlatformMacOS
}

func (p Platform) isTransparentProxy() bool {
	return p == PlatformTransparentProxy
}

// GenerateSingBox 保留原有签名供配置单测与兼容调用。真实桌面连接必须走
// GenerateSingBoxDesktop，并传入启动前的系统默认接口快照。
func GenerateSingBox(profile *Profile, socksPort int, vpnServerIP string) ([]byte, error) {
	return GenerateSingBoxDesktop(profile, socksPort, vpnServerIP, "", nil, "en0")
}

// GenerateSingBoxDesktop 是桌面连接路径的入口：AnyConnect 隧道先建立、拿到
// 服务端下发的企业 DNS 后才生成配置，绑定到 VPN 线路的内网域名（如 oa.corp.example）
// 只在企业 DNS 有记录，必须经隧道向它查询，公共 DoH 上是 NXDOMAIN。
// underlayInterface 不是用户配置，也不是产品识别结果；它只能来自数据面启动前
// 操作系统默认路由的接口。空值必须报错，不能回落到 sing-tun 在 macOS 上会跳过
// 无网关 utun 的 auto_detect_interface。
func GenerateSingBoxDesktop(profile *Profile, socksPort int, vpnServerIP, basePath string, enterpriseDNS []string, underlayInterface string) ([]byte, error) {
	return generateSingBox(profile, socksPort, vpnServerIP, PlatformMacOS, basePath, enterpriseDNS, nil, underlayInterface, nil)
}

// GenerateSingBoxFor 生成 sing-box JSON 配置,platform 决定平台相关字段的取舍。
//
// basePath 是运行状态目录。NetworkExtension 用它生成 cache_file 的绝对路径；
// 两个平台的内置 Tailscale endpoint 都用它保存同一份持久身份。PlatformMacOS
// 的 cache_file 仍沿用相对路径 "cache.db"。
func GenerateSingBoxFor(profile *Profile, socksPort int, vpnServerIP string, platform Platform, basePath string, underlayInterfaces ...string) ([]byte, error) {
	if len(underlayInterfaces) > 1 {
		return nil, fmt.Errorf("expected at most one underlay interface snapshot")
	}
	var underlayInterface string
	if len(underlayInterfaces) == 1 {
		underlayInterface = underlayInterfaces[0]
	}
	return generateSingBox(profile, socksPort, vpnServerIP, platform, basePath, nil, nil, underlayInterface, nil)
}

// GenerateSingBoxAndroid uses the OS-provided Underlay DNS for the existing
// mobile fallback transport. DNS dispatch remains entirely inside sing-box.
func GenerateSingBoxAndroid(profile *Profile, basePath string, systemDNS []string) ([]byte, error) {
	if _, err := validateTransparentProxySystemDNS(systemDNS); err != nil {
		return nil, err
	}
	return generateSingBox(profile, 0, "", PlatformNE, basePath, nil, systemDNS, "", nil)
}

type transparentProxyIngress struct {
	port          int
	username      string
	password      string
	addressFamily transparentProxyAddressFamilyPolicy
	// A compiler-owned acquisition capability reuses exact-Line DNS policy,
	// but has no listener and receives Android's OS-selected network via callbacks.
	androidResource bool
	// Apple resource sessions run where XDial capture cannot see their sockets
	// (the app with no transaction, or the transparent-proxy Provider). They
	// keep the OS's complete Underlay routing: auto_detect_interface would skip
	// a gateway-less utun default route and bypass an external VPN.
	osRoutedResource bool
	// Native desktop ingress has no SOCKS listener/metadata credentials. Its
	// compiler lowers application selectors to sing-box OS process predicates.
	nativeFlow bool
}

// LineAddressFamilyCapability is one Provider-measured, transaction-scoped
// Line capability. It is intentionally absent from Profile: a network epoch
// change invalidates the measurement without changing the user's Line.
type LineAddressFamilyCapability struct {
	IPv4Available bool `json:"ipv4_available"`
	IPv6Available bool `json:"ipv6_available"`
}

// TransparentProxyLineCapabilities carries the address-family measurements
// for the active ConnectionPlan, keyed by the stable Line ID rather than a
// generated outbound tag.
type TransparentProxyLineCapabilities map[string]LineAddressFamilyCapability

type transparentProxyAddressFamilyPolicy struct {
	strategiesByLineID map[string]string
}

func (policy transparentProxyAddressFamilyPolicy) strategy(lineID string) string {
	return policy.strategiesByLineID[lineID]
}

// GenerateSingBoxTransparentProxy 生成 macOS Transparent Proxy 扩展内的配置。
// 会话凭据只保护本机 loopback SOCKS 入口，不属于用户配置，不得持久化。
func GenerateSingBoxTransparentProxy(
	profile *Profile,
	listenPort int,
	username string,
	password string,
	basePath string,
	underlayInterface string,
	systemDNS []string,
) ([]byte, error) {
	return GenerateSingBoxTransparentProxyWithCapabilities(
		profile,
		listenPort,
		username,
		password,
		basePath,
		underlayInterface,
		systemDNS,
		true,
	)
}

// GenerateSingBoxTransparentProxyWithCapabilities compiles facts measured by
// older Providers that only measured Direct. Active non-Direct Lines retain
// their historical dual-stack behavior until the caller adopts the Line-keyed
// API below.
func GenerateSingBoxTransparentProxyWithCapabilities(
	profile *Profile,
	listenPort int,
	username string,
	password string,
	basePath string,
	underlayInterface string,
	systemDNS []string,
	directIPv6Available bool,
) ([]byte, error) {
	capabilities := legacyTransparentProxyLineCapabilities(profile, directIPv6Available)
	return GenerateSingBoxTransparentProxyWithLineCapabilities(
		profile,
		listenPort,
		username,
		password,
		basePath,
		underlayInterface,
		systemDNS,
		capabilities,
	)
}

// GenerateSingBoxTransparentProxyWithLineCapabilities compiles immutable
// address-family facts measured for this exact connection transaction into
// the DNS and route data plane. Every active Line must have one measurement.
func GenerateSingBoxTransparentProxyWithLineCapabilities(
	profile *Profile,
	listenPort int,
	username string,
	password string,
	basePath string,
	underlayInterface string,
	systemDNS []string,
	capabilities TransparentProxyLineCapabilities,
) ([]byte, error) {
	if listenPort < 1 || listenPort > 65535 {
		return nil, fmt.Errorf("transparent proxy listen port is invalid")
	}
	username = strings.TrimSpace(username)
	password = strings.TrimSpace(password)
	if username == "" || password == "" || len(username) > 255 || len(password) > 255 {
		return nil, fmt.Errorf("transparent proxy session credentials are invalid")
	}
	addressFamily, err := compileTransparentProxyAddressFamilyPolicy(profile, capabilities)
	if err != nil {
		return nil, err
	}
	return generateSingBox(
		profile,
		0,
		"",
		PlatformTransparentProxy,
		basePath,
		nil,
		systemDNS,
		underlayInterface,
		&transparentProxyIngress{
			port:          listenPort,
			username:      username,
			password:      password,
			addressFamily: addressFamily,
		},
	)
}

func legacyTransparentProxyLineCapabilities(
	profile *Profile,
	directIPv6Available bool,
) TransparentProxyLineCapabilities {
	capabilities := TransparentProxyLineCapabilities{
		builtinDirectLineID: {
			IPv4Available: true,
			IPv6Available: directIPv6Available,
		},
	}
	if profile == nil {
		return capabilities
	}
	scenario := profile.ActiveScenario()
	if scenario == nil {
		return capabilities
	}
	activeLineIDs, _ := effectiveActiveTargetIDs(profile, scenario)
	for lineID := range activeLineIDs {
		if lineID == "" || lineID == builtinDirectLineID {
			continue
		}
		capabilities[lineID] = LineAddressFamilyCapability{
			IPv4Available: true,
			IPv6Available: true,
		}
	}
	return capabilities
}

func compileTransparentProxyAddressFamilyPolicy(
	profile *Profile,
	capabilities TransparentProxyLineCapabilities,
) (transparentProxyAddressFamilyPolicy, error) {
	policy := transparentProxyAddressFamilyPolicy{
		strategiesByLineID: make(map[string]string),
	}
	if err := ValidateTransparentProxyLineCapabilities(capabilities); err != nil {
		return policy, err
	}
	strategies := make(map[string]string, len(capabilities))
	for lineID, capability := range capabilities {
		strategy, _ := transparentProxyAddressFamilyStrategy(capability)
		strategies[lineID] = strategy
	}
	plan, err := BuildConnectionPlan(profile)
	if err != nil {
		return policy, err
	}
	for _, task := range plan.Tasks {
		if task.Kind != ConnectionTaskLine {
			continue
		}
		lineID := strings.TrimSpace(task.ResourceID)
		strategy, ok := strategies[lineID]
		if !ok {
			return policy, fmt.Errorf(
				"transparent proxy active Line %q is missing an address-family capability",
				lineID,
			)
		}
		policy.strategiesByLineID[lineID] = strategy
	}
	return policy, nil
}

// ValidateTransparentProxyLineCapabilities validates the transport-neutral
// JSON contract before a concrete traffic or RuleSet-bootstrap profile is
// selected. Whether every active Line is present is checked while compiling
// that concrete profile.
func ValidateTransparentProxyLineCapabilities(
	capabilities TransparentProxyLineCapabilities,
) error {
	if capabilities == nil {
		return fmt.Errorf("transparent proxy Line address-family capabilities are unavailable")
	}
	for lineID, capability := range capabilities {
		if strings.TrimSpace(lineID) == "" {
			return fmt.Errorf("transparent proxy Line address-family capability has an empty Line ID")
		}
		if lineID == builtinDirectLineID && !capability.IPv4Available {
			return fmt.Errorf("transparent proxy pure IPv6 Direct capability is unsupported")
		}
		_, err := transparentProxyAddressFamilyStrategy(capability)
		if err != nil {
			return fmt.Errorf("transparent proxy Line %q address-family capability: %w", lineID, err)
		}
	}
	return nil
}

func transparentProxyAddressFamilyStrategy(
	capability LineAddressFamilyCapability,
) (string, error) {
	switch {
	case capability.IPv4Available && capability.IPv6Available:
		return "", nil
	case capability.IPv4Available:
		return "ipv4_only", nil
	case capability.IPv6Available:
		return "ipv6_only", nil
	default:
		return "", fmt.Errorf("neither IPv4 nor IPv6 is available")
	}
}

func generateSingBox(
	profile *Profile,
	socksPort int,
	vpnServerIP string,
	platform Platform,
	basePath string,
	enterpriseDNS []string,
	systemDNS []string,
	underlayInterface string,
	transparentIngress *transparentProxyIngress,
) ([]byte, error) {
	var groupErr error
	profile, groupErr = ExpandRuleSetGroups(profile)
	if groupErr != nil {
		return nil, groupErr
	}
	scenario := profile.ActiveScenario()
	if scenario == nil {
		return nil, fmt.Errorf("no active scenario")
	}
	// INV6a：悬空引用（场景指向不存在的规则/线路/订阅）在这里就拒绝，
	// 绝不让它变成"整条规则蒸发、流量静默落到 final"。存在但被禁用的对象
	// （INV6b）只产生 warning，由 CollectProfileWarnings 供 daemon/UI 读取。
	if _, err := inspectScenarioReferences(profile, scenario); err != nil {
		return nil, err
	}
	activeApplicationSelectors := activeApplicationRuleSetSelectors(profile, scenario)
	if len(activeApplicationSelectors) > 0 && !platform.isTransparentProxy() {
		// 只有 macOS Transparent Proxy 能取得系统交付的 source app 归因。
		// 其他入口若跳过规则会让受约束应用静默落到 Scenario 默认出口，必须拒绝。
		return nil, fmt.Errorf("active application rule sets require the macOS transparent proxy ingress")
	}
	if platform.isTransparentProxy() && transparentIngress == nil {
		return nil, fmt.Errorf("transparent proxy ingress is unavailable")
	}
	if len(activeApplicationSelectors) > 0 &&
		len(transparentIngress.username)+1+sha256.Size*2 > 255 {
		return nil, fmt.Errorf("transparent proxy session username is too long for application rules")
	}
	activeLineIDs, activeSubscriptionIDs := effectiveActiveTargetIDs(profile, scenario)
	expandGroupLineIDs(profile, activeLineIDs)
	activeVPNIDs := effectiveActiveVPNLineIDs(profile, scenario)
	activeTailscaleIDs := effectiveActiveTailscaleLineIDs(profile, scenario)
	activeMagicDNSTags := effectiveActiveMagicDNSEndpointTags(profile, scenario)
	// D30：sslcon 是包级单例，一个进程只能维持一条 AnyConnect 隧道，而所有 VPN
	// 线路共享 "vpn" 这一个 outbound tag。两条不同的 active VPN 线路会让第二条的
	// 流量静默钻进第一条的隧道（违反 Line 隔离）。所有平台一律硬校验报错，
	// 不区分桌面/NE —— 桌面同样只有一份 VPNBridge。
	if len(activeVPNIDs) > 1 {
		return nil, fmt.Errorf("only one active AnyConnect line is supported: %d active lines would share one tunnel", len(activeVPNIDs))
	}
	// D33：所有 Tailscale Line 共享一份 node key/state，不能同时创建两个 endpoint
	// 实例。未被 active Scenario 引用的 Line 不计入，也绝不能为了登录或探测进入数据面。
	if len(activeTailscaleIDs) > 1 {
		return nil, fmt.Errorf("only one active Tailscale line is supported: %d active lines would share one identity", len(activeTailscaleIDs))
	}

	directOutbound := map[string]interface{}{"type": "direct", "tag": "direct"}
	if platform.isTransparentProxy() {
		strategy := transparentIngress.addressFamily.strategy(builtinDirectLineID)
		if strategy != "" {
			directOutbound["domain_resolver"] = map[string]interface{}{
				"server":   TransparentNativeDNSTag,
				"strategy": strategy,
			}
		}
	}
	outbounds := []map[string]interface{}{directOutbound}
	if len(activeVPNIDs) > 0 {
		vpnOutbound := map[string]interface{}{
			"type":        "socks",
			"tag":         "vpn",
			"server":      "127.0.0.1",
			"server_port": socksPort,
		}
		if platform.isNetworkExtension() {
			// NE 模式下 sing-box 是库,跑在同一进程里,"vpn" 出口是
			// core/libbox/vpn_outbound.go 注册的自研 outbound(直接拨
			// VPNBridge,不经本地 SOCKS5 中转);macOS 模式下 sing-box 是
			// 外部子进程,只能通过 127.0.0.1 socks 中转回 app 进程里的 VPNBridge。
			vpnOutbound = map[string]interface{}{
				"type": "vpn",
				"tag":  "vpn",
			}
		}
		outbounds = append(outbounds, vpnOutbound)
	}

	var endpoints []map[string]interface{}
	var activeTailscaleTags []string
	if len(activeTailscaleIDs) > 0 && (basePath == "" || !path.IsAbs(basePath)) {
		return nil, fmt.Errorf("Tailscale state directory is unavailable")
	}
	for index := range profile.Lines {
		line := &profile.Lines[index]
		if !activeTailscaleIDs[line.ID] {
			continue
		}
		// 旧移动端 Profile 仍可携带 Auth Key；桌面 D33 明确禁止把持久 Profile
		// 中的秘密带入日常运行配置。桌面首次注册只走 helper 的瞬时 setup 请求。
		authKey := ""
		if platform == PlatformNE {
			authKey = line.TailscaleAuthKey
		}
		endpoint, err := buildTailscaleEndpoint(line, profile.Tailscale, basePath, authKey)
		if err != nil {
			return nil, err
		}
		endpoints = append(endpoints, endpoint)
		activeTailscaleTags = append(activeTailscaleTags, tailscaleEndpointTag(line))
	}

	for _, line := range profile.Lines {
		if !activeLineIDs[line.ID] || !line.Enabled || line.Type == LineTypeDirect || line.Type == LineTypeVPN || line.Type == LineTypeTailscale {
			continue
		}
		ob := buildProxyOutbound(&line)
		if ob == nil {
			// inspectScenarioReferences 使用同一能力判据，正常情况下会更早返回错误。
			// 这里仍保留生成器自身的最后防线，避免未来两处判据漂移后又把 active
			// Line 静默丢掉，让绑定或默认出口落到 direct。
			return nil, fmt.Errorf(
				"active enabled line %q (type %q) cannot generate an outbound",
				line.ID,
				line.Type,
			)
		}
		outbounds = append(outbounds, ob)
	}

	// 订阅 outbound：节点 + 策略组（或默认 urltest/selector）
	subTagMap := make(map[string]string)
	subGroupTagMap := make(map[string]map[string]string) // subID -> groupName -> tag
	for _, sub := range profile.Subscriptions {
		if !activeSubscriptionIDs[sub.ID] || !sub.Enabled || len(sub.Lines) == 0 {
			continue
		}
		obs, mainTag, groupTags := buildSubscriptionOutbounds(&sub, platform)
		if mainTag != "" {
			outbounds = append(outbounds, obs...)
			subTagMap[sub.ID] = mainTag
			subGroupTagMap[sub.ID] = groupTags
		}
	}

	// 代理服务器域名属于 Line 的启动端点，不是用户流量的目标域名。Transparent
	// Proxy 的全局 resolver 必须继续保持启动前 Underlay 的系统 DNS 视角；但把代理
	// 端点也交给它，会让一个对公网域名返回 SERVFAIL 的下层 resolver 阻断整条 Line。
	// 这里只覆盖 active Scenario 实际生成的域名型代理 outbound，并使用盒内、IP 直连的
	// public-dns 做唯一的启动解析主路径。它不参与 Scenario DNS 分域，也绝不能 detour
	// 回正在启动的代理（否则形成 resolver → outbound → resolver 自循环）。
	needsProxyEndpointBootstrap := false
	if platform.isTransparentProxy() {
		needsProxyEndpointBootstrap = configureTransparentProxyEndpointBootstrap(outbounds)
	}

	if platform == PlatformMacOS {
		// 桌面端通过 Clash API 临时切换 selector 做逐线路地址探测。
		// NetworkExtension 不启 Clash API，不生成这个诊断专用出口。
		selectorMembers := []string{"direct"}
		for _, ob := range outbounds {
			tag, _ := ob["tag"].(string)
			if tag == "direct" {
				continue
			}
			selectorMembers = append(selectorMembers, tag)
		}
		selectorMembers = append(selectorMembers, activeTailscaleTags...)
		outbounds = append(outbounds, map[string]interface{}{
			"type":      "selector",
			"tag":       testSelectorTag,
			"outbounds": selectorMembers,
			"default":   "direct",
		})
	}

	// 收集所有已生成的 outbound tag，规则引用前要校验，避免引用不存在 tag 导致 sing-box 启动失败。
	// 顺带做唯一性断言：重复 tag 会让 sing-box 在解析阶段直接拒绝启动（而 helper 只确认
	// 进程 spawn 成功，用户看到"已连接但流量全断"的假连接），故在生成阶段就 fail-fast。
	validTags := map[string]bool{}
	for _, ob := range outbounds {
		if tag, _ := ob["tag"].(string); tag != "" {
			if validTags[tag] {
				return nil, fmt.Errorf("duplicate outbound tag: %q", tag)
			}
			validTags[tag] = true
		}
	}
	for _, endpoint := range endpoints {
		if tag, _ := endpoint["tag"].(string); tag != "" {
			if validTags[tag] {
				return nil, fmt.Errorf("duplicate outbound tag: %q", tag)
			}
			validTags[tag] = true
		}
	}

	// 两个平台的系统 DNS 包都走 hijack-dns：桌面交给 buildDNS 的解析链，
	// NE 交给 xdial-mobile dispatcher。
	routeRules := buildSystemRouteRules(platform == PlatformMacOS)
	if platform.isNetworkExtension() {
		routeRules = buildNESystemRouteRules()
	}
	ruleSetResources := sbCollectRuleSets(profile, scenario, subTagMap, validTags)
	acceptanceScenarioRules, ordinaryScenarioRules := buildScenarioRouteRules(
		profile,
		scenario,
		subTagMap,
		validTags,
	)
	if platform.isTransparentProxy() {
		// Transparent Proxy 必须逐条保留 Scenario 顺序：域名条件先用目标 Line
		// 的解析视角，只有轮到 IP 条件时才用启动前系统 DNS。不能再在所有
		// Scenario 规则之前做一次固定 resolver 的全局 resolve。
		acceptanceScenarioRules = nil
		ordinaryScenarioRules = buildTransparentProxyScenarioRouteRules(
			profile,
			scenario,
			subTagMap,
			validTags,
			transparentIngress.username,
			transparentIngress.addressFamily,
		)
	}

	// 两条锁定验收规则来自用户可见 profile，不是生成器暗中注入；但它们必须
	// 先于订阅规则匹配，否则订阅里的大网段（如 1.0.0.0/8）会吞掉 /32，
	// 让路由验收测到订阅语义而不是两条显式绑定。
	routeRules = append(routeRules, acceptanceScenarioRules...)
	// 场景的普通规则排在订阅自带规则之前。
	//
	// 架构约束：Scenario 是唯一裁决者，订阅只是"自带规则的供给源"（D28）。订阅那几百条
	// 宽匹配（GEOIP,CN→DIRECT 之类）一旦排在前面，就会把用户在场景里显式绑定的
	// 规则整个遮蔽掉 —— 用户明明把 example.com 绑到了某条线路，流量却被订阅的
	// 兜底规则抢走，这正是"隐式抢注"。改为：用户显式绑定优先，订阅规则退为兜底。
	routeRules = append(routeRules, ordinaryScenarioRules...)

	// 用户在 active Tailscale Line 上勾选 MagicDNS 后，才加入
	// endpoint 根据当前 NetMap 动态申报的 peer 路由归属。这里只是
	// route 优先级：Scenario 显式绑定仍在前，MagicDNS 路由在订阅供给
	// 规则之前。DNS 快照的最高优先级由 buildTransparentProxyDNS
	// 独立表达，不得从本段 route 顺序反推。
	routeRules = append(routeRules, buildMagicDNSRouteRules(
		activeMagicDNSTags,
		platform.isTransparentProxy(),
	)...)

	// 订阅自带规则：以一等公民身份进入裁决，但排在用户显式绑定之后。
	for _, sub := range profile.Subscriptions {
		if !activeSubscriptionIDs[sub.ID] || !sub.Enabled {
			continue
		}
		groupTags := subGroupTagMap[sub.ID]
		if groupTags == nil {
			continue
		}
		subRules, subSets, err := buildSubscriptionRules(&sub, groupTags)
		if err != nil {
			return nil, fmt.Errorf("compile subscription %q rules: %w", sub.ID, err)
		}
		if platform.isTransparentProxy() {
			subRules, subSets, err = buildTransparentProxySubscriptionRules(&sub, groupTags)
			if err != nil {
				return nil, fmt.Errorf("compile subscription %q transparent proxy rules: %w", sub.ID, err)
			}
		}
		routeRules = append(routeRules, subRules...)
		for _, s := range subSets {
			tag := s["tag"].(string)
			dup := false
			for _, existing := range ruleSetResources {
				if existing["tag"].(string) == tag {
					dup = true
					break
				}
			}
			if !dup {
				ruleSetResources = append(ruleSetResources, s)
			}
		}
	}

	// 默认出口。悬空引用和 enabled 但生成不出 outbound 的线路已在
	// inspectScenarioReferences 里报错拒绝；这里能走到 direct 的只剩用户显式禁用
	// 对象的 INV6b 语义，并且已经产生对应 ProfileWarning。
	defaultTag := "direct"
	defaultLineID := builtinDirectLineID
	if scenario.DefaultSubscriptionID != "" {
		if tag, ok := subTagMap[scenario.DefaultSubscriptionID]; ok && validTags[tag] {
			defaultTag = tag
			defaultLineID = ""
		}
	} else if scenario.DefaultLineID != "" {
		if l := profile.FindLine(scenario.DefaultLineID); l != nil && l.Enabled {
			candidate := resolveOutboundTag(l)
			if validTags[candidate] {
				defaultTag = candidate
				defaultLineID = l.ID
			}
		}
	}

	// 未被更具体规则接管的域名与未被更具体规则接管的流量，都归 Scenario 的
	// 默认线路。IP 规则仍可在前面用启动时系统 DNS 做保守判断；如果没有命中，
	// 这里再从默认线路的解析视角求值，避免把 Underlay DNS 的地址带到另一个
	// 出口。direct 的默认 resolver 本来就是 Underlay 系统 DNS。
	if platform.isTransparentProxy() {
		defaultResolve := map[string]interface{}{
			"action": "resolve",
			"server": transparentProxyResolverForOutbound(defaultTag),
		}
		if strategy := transparentIngress.addressFamily.strategy(defaultLineID); strategy != "" {
			defaultResolve["strategy"] = strategy
		}
		routeRules = append(routeRules, defaultResolve)
	}

	route := map[string]interface{}{
		"rules": routeRules,
		"final": defaultTag,
	}
	if platform == PlatformTransparentProxy {
		route["default_domain_resolver"] = transparentSystemDNSTag
	} else if platform.isNetworkExtension() {
		// 节点域名和 Tailscale 控制面必须能在首次登录前解析，不能递归进入
		// 尚未就绪的企业或 Tailscale 分域 resolver。
		route["default_domain_resolver"] = mobilePublicDNSTag
	} else {
		// 桌面出站域名统一交给盒内公共解析器，避免依赖 XDial 启动前的
		// 系统 resolver 状态。
		route["default_domain_resolver"] = desktopPublicDNSTag
	}
	// Underlay 选择仍属于操作系统与 sing-box 数据面。桌面宿主只把启动前系统
	// 默认路由已经选定的接口原样转交给 sing-box；它不识别 Wi-Fi、网线或任何
	// VPN 产品。不能在桌面回落 auto_detect_interface：sing-tun 0.8.9 的 darwin
	// 实现会跳过没有 RTF_GATEWAY 的 utun 默认路由，破坏自然叠加。
	if platform == PlatformTransparentProxy && transparentIngress.nativeFlow {
		// Linux bypass-mark sockets retain the kernel's complete destination-
		// specific Underlay routing, rather than binding all destinations to one NIC.
	} else if platform == PlatformTransparentProxy && transparentIngress.androidResource && transparentIngress.osRoutedResource {
		// The OS routing table selects the Underlay for every destination.
	} else if platform == PlatformTransparentProxy && transparentIngress.androidResource {
		route["auto_detect_interface"] = true
	} else if platform == PlatformMacOS || platform == PlatformTransparentProxy {
		underlayInterface = strings.TrimSpace(underlayInterface)
		if underlayInterface == "" {
			return nil, fmt.Errorf("desktop underlay interface snapshot is unavailable")
		}
		route["default_interface"] = underlayInterface
	} else if platform == PlatformNE {
		// Apple 移动端由 NWPathMonitor 经 PlatformInterface 提供系统网络变化。
		route["auto_detect_interface"] = true
	}
	if len(ruleSetResources) > 0 {
		route["rule_set"] = ruleSetResources
	}
	dnsConfig := buildNEDNS(activeMagicDNSTags)
	if platform.isTransparentProxy() {
		var dnsErr error
		dnsConfig, dnsErr = buildTransparentProxyDNS(
			profile,
			scenario,
			subTagMap,
			subGroupTagMap,
			validTags,
			activeMagicDNSTags,
			systemDNS,
			defaultTag,
			needsProxyEndpointBootstrap,
			transparentIngress.username,
			defaultLineID,
			transparentIngress.addressFamily,
		)
		if dnsErr != nil {
			return nil, dnsErr
		}
		markLineOwnedFlowAddressCorrection(routeRules, dnsConfig)
	} else if !platform.isNetworkExtension() {
		dnsConfig = buildDNS(
			enterpriseDNS,
			collectVPNBoundDomains(profile, scenario),
			collectProxyBoundDNSTargets(profile, scenario, subTagMap, validTags),
			activeMagicDNSTags,
		)
	}

	if platform == PlatformNE && systemDNS != nil {
		primary, err := validateTransparentProxySystemDNS(systemDNS)
		if err != nil {
			return nil, err
		}
		// This is the OS snapshot in its original priority order, not an
		// interface/product heuristic or platform-side DNS query.
		for _, server := range dnsConfig["servers"].([]map[string]interface{}) {
			if server["tag"] == mobilePublicDNSTag {
				server["server"] = primary
			}
		}
	}

	inbound := buildTUNInbound(vpnServerIP, platform)
	if platform.isTransparentProxy() && !transparentIngress.androidResource && !transparentIngress.nativeFlow {
		var inboundErr error
		inbound, inboundErr = buildTransparentProxyInbound(*transparentIngress, activeApplicationSelectors)
		if inboundErr != nil {
			return nil, inboundErr
		}
	}
	var inbounds []map[string]interface{}
	if transparentIngress == nil || (!transparentIngress.androidResource && !transparentIngress.nativeFlow) {
		inbounds = []map[string]interface{}{inbound}
	}

	cfg := SingBoxConfig{
		Log: map[string]interface{}{
			"level": "info",
		},
		DNS:          dnsConfig,
		Endpoints:    endpoints,
		Inbounds:     inbounds,
		Outbounds:    outbounds,
		Route:        route,
		Experimental: buildExperimental(platform, basePath),
	}

	return json.MarshalIndent(cfg, "", "  ")
}

func buildTransparentProxyInbound(
	ingress transparentProxyIngress,
	applicationSelectors []ApplicationProcessSelector,
) (map[string]interface{}, error) {
	users := []map[string]interface{}{{
		"username": ingress.username,
		"password": ingress.password,
	}}
	seen := map[string]bool{ingress.username: true}
	for _, selector := range applicationSelectors {
		username := ApplicationSOCKSUsername(ingress.username, selector)
		if len(username) > 255 {
			return nil, fmt.Errorf("transparent proxy session username is too long for application rules")
		}
		if seen[username] {
			continue
		}
		seen[username] = true
		users = append(users, map[string]interface{}{
			"username": username,
			"password": ingress.password,
		})
	}
	inbound := map[string]interface{}{
		"type":                "socks",
		"tag":                 "transparent-proxy-in",
		"listen":              "127.0.0.1",
		"listen_port":         ingress.port,
		"xdial_flow_metadata": true,
		"users":               users,
	}
	return inbound, nil
}

// ApplicationSOCKSUsername derives a per-flow SOCKS username from the session
// credential and one canonical Surge-style process selector. Raw paths and
// process names never enter the sing-box route config; SOCKS authentication is
// the narrow join between platform attribution and sing-box routing.
func ApplicationSOCKSUsername(baseUsername string, selector ApplicationProcessSelector) string {
	sum := sha256.Sum256([]byte(string(selector.Kind) + "\x00" + selector.Value))
	return baseUsername + "." + hex.EncodeToString(sum[:])
}

// effectiveActiveTargetIDs 只返回活动场景真正引用的线路和订阅。未使用但 enabled 的
// 半成品节点不应进入 sing-box：否则它们即使永远不会承载流量，也可能在 box.New 时
// 让整个活动场景启动失败。
func effectiveActiveTargetIDs(profile *Profile, scenario *Scenario) (map[string]bool, map[string]bool) {
	lineIDs := make(map[string]bool)
	subscriptionIDs := make(map[string]bool)
	addTarget := func(lineID, subscriptionID string) {
		if lineID != "" {
			lineIDs[lineID] = true
		}
		if subscriptionID != "" {
			subscriptionIDs[subscriptionID] = true
		}
	}

	addTarget(scenario.DefaultLineID, scenario.DefaultSubscriptionID)
	for _, binding := range scenario.Bindings {
		ruleSet := profile.FindRuleSet(binding.RuleSetID)
		if ruleSet == nil || !ruleSet.Enabled {
			continue
		}
		addTarget(binding.LineID, binding.SubscriptionID)
	}
	return lineIDs, subscriptionIDs
}

// activeApplicationRuleSetSelectors returns only process selectors that are
// both enabled and bound by the active Scenario. Unbound rules must create neither
// route entries nor additional accepted SOCKS credentials. Order follows the
// Scenario binding list so overlapping selectors preserve visible priority.
func activeApplicationRuleSetSelectors(profile *Profile, scenario *Scenario) []ApplicationProcessSelector {
	seen := make(map[string]struct{})
	var selectors []ApplicationProcessSelector
	for _, binding := range scenario.Bindings {
		ruleSet := profile.FindRuleSet(binding.RuleSetID)
		if ruleSet == nil || !ruleSet.Enabled || ruleSet.Type != RuleSetTypeApplication {
			continue
		}
		for _, selector := range applicationRuleSetSelectors(ruleSet) {
			key := selector.key()
			if _, exists := seen[key]; exists {
				continue
			}
			seen[key] = struct{}{}
			selectors = append(selectors, selector)
		}
	}
	return selectors
}

// ApplicationSOCKSCredential is one ordered Surge-style process selector →
// derived SOCKS username pair carried only in the macOS session envelope.
type ApplicationSOCKSCredential struct {
	Kind           ApplicationProcessSelectorKind `json:"kind"`
	Value          string                         `json:"value"`
	Username       string                         `json:"username"`
	RuleSetID      string                         `json:"rule_set_id"`
	LineID         string                         `json:"line_id,omitempty"`
	SubscriptionID string                         `json:"subscription_id,omitempty"`
}

// ActiveApplicationSOCKSCredentials exposes the active Scenario's ordered process
// selector → derived SOCKS username list to the macOS session envelope. It
// follows the exact same Scenario boundary and derivation used by the generated
// inbound and route rules, so Swift never reproduces the hash algorithm.
func ActiveApplicationSOCKSCredentials(profile *Profile, baseUsername string) ([]ApplicationSOCKSCredential, error) {
	var groupErr error
	profile, groupErr = ExpandRuleSetGroups(profile)
	if groupErr != nil {
		return nil, groupErr
	}
	if profile == nil {
		return nil, fmt.Errorf("profile is nil")
	}
	scenario := profile.ActiveScenario()
	if scenario == nil {
		return nil, fmt.Errorf("no active scenario")
	}
	if _, err := inspectScenarioReferences(profile, scenario); err != nil {
		return nil, err
	}
	baseUsername = strings.TrimSpace(baseUsername)
	if baseUsername == "" {
		return nil, fmt.Errorf("transparent proxy session username is invalid for application rules")
	}
	selectors := activeApplicationRuleSetSelectors(profile, scenario)
	if len(selectors) > 0 && len(baseUsername)+1+sha256.Size*2 > 255 {
		return nil, fmt.Errorf("transparent proxy session username is too long for application rules")
	}
	credentials := make([]ApplicationSOCKSCredential, 0, len(selectors))
	seen := make(map[string]struct{})
	for _, binding := range scenario.Bindings {
		ruleSet := profile.FindRuleSet(binding.RuleSetID)
		if ruleSet == nil || !ruleSet.Enabled || ruleSet.Type != RuleSetTypeApplication {
			continue
		}
		for _, selector := range applicationRuleSetSelectors(ruleSet) {
			if _, exists := seen[selector.key()]; exists {
				continue
			}
			seen[selector.key()] = struct{}{}
			credentials = append(credentials, ApplicationSOCKSCredential{
				Kind:           selector.Kind,
				Value:          selector.Value,
				Username:       ApplicationSOCKSUsername(baseUsername, selector),
				RuleSetID:      binding.RuleSetID,
				LineID:         binding.LineID,
				SubscriptionID: binding.SubscriptionID,
			})
		}
	}
	return credentials, nil
}

func effectiveActiveVPNLineIDs(profile *Profile, scenario *Scenario) map[string]bool {
	activeLineIDs, _ := effectiveActiveTargetIDs(profile, scenario)
	ids := make(map[string]bool)
	for lineID := range activeLineIDs {
		line := profile.FindLine(lineID)
		if line != nil && line.Enabled && line.Type == LineTypeVPN {
			ids[line.ID] = true
		}
	}
	return ids
}

func effectiveActiveTailscaleLineIDs(profile *Profile, scenario *Scenario) map[string]bool {
	activeLineIDs, _ := effectiveActiveTargetIDs(profile, scenario)
	ids := make(map[string]bool)
	for lineID := range activeLineIDs {
		line := profile.FindLine(lineID)
		if line != nil && line.Enabled && line.Type == LineTypeTailscale {
			ids[line.ID] = true
		}
	}
	return ids
}

// effectiveActiveMagicDNSEndpointTags 只返回 active Scenario 实际引用，
// 且用户在 Line 上显式勾选 MagicDNS 的 Tailscale endpoint。单纯声明、
// 启用或勾选一条未被 active Scenario 引用的 Line 仍然是零副作用。
func effectiveActiveMagicDNSEndpointTags(profile *Profile, scenario *Scenario) []string {
	var tags []string
	activeLineIDs := effectiveActiveTailscaleLineIDs(profile, scenario)
	for index := range profile.Lines {
		line := &profile.Lines[index]
		if !activeLineIDs[line.ID] || !line.TailscaleMagicDNS {
			continue
		}
		tags = append(tags, tailscaleEndpointTag(line))
	}
	return tags
}

// ActiveTailscaleLine returns the one enabled Tailscale Line referenced by the active
// Scenario. The desktop helper uses this same decision boundary for login/exit-node
// preflight before it starts the external sing-box data plane.
func ActiveTailscaleLine(profile *Profile) (*Line, error) {
	var groupErr error
	profile, groupErr = ExpandRuleSetGroups(profile)
	if groupErr != nil {
		return nil, groupErr
	}
	if profile == nil {
		return nil, fmt.Errorf("profile is nil")
	}
	scenario := profile.ActiveScenario()
	if scenario == nil {
		return nil, fmt.Errorf("no active scenario")
	}
	if _, err := inspectScenarioReferences(profile, scenario); err != nil {
		return nil, err
	}
	ids := effectiveActiveTailscaleLineIDs(profile, scenario)
	if len(ids) > 1 {
		return nil, fmt.Errorf("only one active Tailscale line is supported: %d active lines would share one identity", len(ids))
	}
	for index := range profile.Lines {
		if ids[profile.Lines[index].ID] {
			return &profile.Lines[index], nil
		}
	}
	return nil, nil
}

// buildExperimental 组装 experimental 块。
//
// macOS 模式:clash_api(TCP controller)+ cache_file(相对路径,子进程 cwd 下)。
// NE 模式:扩展进程内存预算极紧(~15MB),不开 clash_api;cache_file 用沙盒内绝对
// 路径,库内运行没有子进程 cwd,相对路径会落到只读的 app bundle 目录。
func buildExperimental(platform Platform, basePath string) map[string]interface{} {
	cachePath := "cache.db"
	if platform.isNetworkExtension() {
		cachePath = path.Join(basePath, "cache.db")
	}
	exp := map[string]interface{}{
		"cache_file": map[string]interface{}{
			"enabled": true,
			"path":    cachePath,
		},
	}
	if platform == PlatformMacOS {
		exp["clash_api"] = map[string]interface{}{
			"external_controller": clashAPIController,
		}
	}
	return exp
}

func buildTUNInbound(vpnServerIP string, platform Platform) map[string]interface{} {
	// IPv4 与 IPv6 地址都必须给：
	// NE 端决定哪些族的包进 packetFlow；桌面端 sing-tun 的 auto_route 把整段
	// IPv6 路由构造包在 len(Inet6Address) > 0 里，没有 v6 地址就一条 v6 路由都
	// 不装，IPv6 流量会整体绕过 XDial，Scenario 里的 IPv6 规则永不求值，DNS 经指定
	// 出口得到的 AAAA 也可能被系统 Happy Eyeballs 从盒外连接。AnyConnect bridge
	// 当前仅支持 IPv4，纯 IPv6 目标会在 vpn outbound 明确失败；关键是不能绕过
	// 数据面直出。
	addresses := []string{"198.18.0.1/15", "fd00::1/126"}
	inbound := map[string]interface{}{
		"type":    "tun",
		"tag":     "tun-in",
		"address": addresses,
		"mtu":     9000,
	}
	// NE 模式由 gVisor 在进程内终止来自 packetFlow 的连接。明确指定 stack，确保
	// 发布包若漏掉 with_gvisor 构建标签会在启动阶段直接失败，而不是静默退回到
	// 依赖系统接口名称的 system stack 后假连接。
	if platform.isNetworkExtension() {
		inbound["stack"] = "gvisor"
		return inbound
	}
	inbound["auto_route"] = true
	inbound["strict_route"] = false
	inbound["stack"] = "system"
	if vpnServerIP != "" {
		inbound["route_exclude_address"] = []string{vpnServerIP + "/32"}
	}
	return inbound
}

// desktopPublicDNSTag 是桌面端的默认解析器：IP 直连的 DoH（阿里 223.5.5.5）。
// 不能用 type:local（系统 DNS）当默认——启动前 Underlay 的 resolver 可能只在
// 下层虚拟接口中可达，XDial 接管路由后再把原始查询强制直出会形成解析黑洞。
// DoH 使用 IP 地址，不需要 bootstrap 解析；其 detour 仍由 sing-box 按当前
// Underlay 选择，不由 XDial 绑定接口。
const desktopPublicDNSTag = "public-dns"
const desktopEnterpriseDNSTag = "enterprise-dns"

// desktopProxyDNSTag 给"经某条代理线路解析"的 DoH server 命名，一条线路一个。
func desktopProxyDNSTag(lineTag string) string {
	return "proxy-dns-" + lineTag
}

// proxyDNSTarget 描述"这些域名的解析要经 lineTag 这条线路出去"。
// domains 与 ruleSetTag 二选一：手动规则集直接内联域名后缀，URL 规则集复用
// route.rule_set 里已有的同一份资源，不重复下载。
type proxyDNSTarget struct {
	lineTag    string
	domains    []string
	ruleSetTag string
	invert     bool
}

// collectProxyBoundDNSTargets 收集活动场景里"解析必须经该线路出去"的规则集。
// 若在本地解析得到非权威或被篡改的应答，再从另一出口连接，解析视角与出口视角就会不一致。
//
// direct 不在此列：它本就要本地视角。vpn 按规则集语义二分——手动规则集是内网名，
// 归 enterprise-dns（企业 DNS 才有记录，见 collectVPNBoundDomains）；URL 规则集
// 远程策略规则通常是公网名，企业 DNS 对它没有特殊记录，走和代理线路同一套经隧道
// 的公共 DoH。少了这一支，"URL 规则集绑 VPN 线路"（预设场景"国内"就是）两边都
// 不管，域名可能落到 final 的受限解析环境并得到非权威或被篡改的应答。
func collectProxyBoundDNSTargets(
	profile *Profile,
	scenario *Scenario,
	subTagMap map[string]string,
	validTags map[string]bool,
) []proxyDNSTarget {
	var targets []proxyDNSTarget
	for _, binding := range scenario.Bindings {
		ruleSet := profile.FindRuleSet(binding.RuleSetID)
		if ruleSet == nil || !ruleSet.Enabled {
			continue
		}

		var lineTag string
		if binding.SubscriptionID != "" {
			lineTag = subTagMap[binding.SubscriptionID]
		} else {
			line := profile.FindLine(binding.LineID)
			if line == nil || !line.Enabled {
				continue
			}
			lineTag = resolveOutboundTag(line)
		}
		if lineTag == "" || lineTag == "direct" || !validTags[lineTag] {
			continue
		}
		if lineTag == "vpn" && ruleSet.Type != RuleSetTypeURL && !ruleSet.Invert {
			continue
		}

		switch ruleSet.Type {
		case RuleSetTypeManual:
			// 带 CIDR 的取反规则必须等解析后才能判定整个补集，
			// DNS 查询阶段不能只取反域名半边条件。
			if ruleSet.Invert && len(ruleSet.CIDRs) > 0 {
				continue
			}
			var domains []string
			for _, domain := range ruleSet.Domains {
				if domain = strings.TrimSpace(domain); domain != "" {
					domains = append(domains, domain)
				}
			}
			if len(domains) == 0 {
				continue
			}
			targets = append(targets, proxyDNSTarget{
				lineTag: lineTag,
				domains: domains,
				invert:  ruleSet.Invert,
			})
		case RuleSetTypeURL:
			if ruleSet.URL == "" {
				continue
			}
			targets = append(targets, proxyDNSTarget{
				lineTag:    lineTag,
				ruleSetTag: sbRuleSetTag(ruleSet),
				invert:     ruleSet.Invert,
			})
		}
	}
	return targets
}

// collectVPNBoundDomains 收集活动场景里绑定到 AnyConnect 线路的手动规则集域名。
// 这些域名的解析必须交给企业 DNS：真正的内网名（如 oa.corp.example）只在企业 DNS 有记录。
func collectVPNBoundDomains(profile *Profile, scenario *Scenario) []string {
	var domains []string
	seen := map[string]bool{}
	for _, binding := range scenario.Bindings {
		line := profile.FindLine(binding.LineID)
		if line == nil || line.Type != LineTypeVPN || !line.Enabled {
			continue
		}
		ruleSet := profile.FindRuleSet(binding.RuleSetID)
		if ruleSet == nil || !ruleSet.Enabled || ruleSet.Type != RuleSetTypeManual || ruleSet.Invert {
			continue
		}
		for _, domain := range ruleSet.Domains {
			domain = strings.TrimSpace(domain)
			if domain == "" || seen[domain] {
				continue
			}
			seen[domain] = true
			domains = append(domains, domain)
		}
	}
	return domains
}

func buildDNS(
	enterpriseDNS []string,
	enterpriseDomains []string,
	proxyTargets []proxyDNSTarget,
	magicDNSEndpointTags []string,
) map[string]interface{} {
	servers := []map[string]interface{}{
		// system 仍保留：个别场景（无网络策略偏好）可作诊断对照，但不再当默认。
		{"tag": "system", "type": "local"},
		{
			"tag":    desktopPublicDNSTag,
			"type":   "https",
			"server": "223.5.5.5",
		},
	}
	var rules []map[string]interface{}

	// 企业域名 → 企业 DNS（查询本身经 AnyConnect 隧道出去）。放在最前，
	// 绝不落到公共 DoH（那里是 NXDOMAIN）。
	if len(enterpriseDNS) > 0 && len(enterpriseDomains) > 0 {
		servers = append(servers, map[string]interface{}{
			"tag": desktopEnterpriseDNSTag,
			// 必须 TCP：桌面的 vpn outbound 是本地 go-socks5 桥，只实现了
			// CONNECT。UDP ASSOCIATE 会"成功"建立却静默丢包，而带 server 的
			// DNS 规则命中后不回落 final，结果是每个内网域名卡满超时再 SERVFAIL。
			"type":   "tcp",
			"server": enterpriseDNS[0],
			"detour": "vpn",
		})
		rules = append(rules, map[string]interface{}{
			"domain_suffix": enterpriseDomains,
			"server":        desktopEnterpriseDNSTag,
		})
	}

	// 承载线路上的域名 → 经该线路的 DoH 解析。排在企业规则之后：
	// 内网名的归属已定。
	// 统一用 DoH（TCP/443 CONNECT）而非 UDP：detour 可能是 "vpn"，桌面那头是只
	// 实现了 CONNECT 的本地 go-socks5 桥（同 enterprise-dns 的 tcp 理由）。
	seenProxyServer := map[string]bool{}
	for _, target := range proxyTargets {
		serverTag := desktopProxyDNSTag(target.lineTag)
		if !seenProxyServer[serverTag] {
			seenProxyServer[serverTag] = true
			servers = append(servers, map[string]interface{}{
				"tag":    serverTag,
				"type":   "https",
				"server": "1.1.1.1",
				"detour": target.lineTag,
			})
		}
		rule := map[string]interface{}{"server": serverTag}
		if target.ruleSetTag != "" {
			rule["rule_set"] = target.ruleSetTag
			if target.invert {
				rule["invert"] = true
			}
		} else {
			rule["domain_suffix"] = target.domains
			if target.invert {
				rule["invert"] = true
			}
		}
		rules = append(rules, rule)
	}

	// 历史外部进程路径没有 Provider Prepare 阶段的内存快照注入接口，
	// 暂保留 endpoint 原生 DNS；新的 hosts 密封语义只在 Transparent Proxy 生效。
	for _, endpointTag := range magicDNSEndpointTags {
		serverTag := mobileTailscaleDNSTag(endpointTag)
		servers = append(servers, buildTailnetDNSServer(endpointTag))
		rules = append(rules, buildTailnetDNSRules(serverTag)...)
	}

	config := map[string]interface{}{
		"servers": servers,
		"final":   desktopPublicDNSTag,
		// 按 (域名, server) 分别缓存，避免不同线路的解析视角互相混用。
		"independent_cache": true,
	}
	if len(rules) > 0 {
		config["rules"] = rules
	}
	return config
}

func buildNEDNS(tailscaleTags []string) map[string]interface{} {
	servers := []map[string]interface{}{
		{
			"type":        "udp",
			"tag":         mobilePublicDNSTag,
			"server":      "1.1.1.1",
			"server_port": 53,
		},
	}
	bindings := make([]map[string]interface{}, 0, len(tailscaleTags))
	for _, endpointTag := range tailscaleTags {
		serverTag := mobileTailscaleDNSTag(endpointTag)
		servers = append(servers, buildTailnetDNSServer(endpointTag))
		bindings = append(bindings, map[string]interface{}{
			"endpoint": endpointTag,
			"server":   serverTag,
		})
	}
	servers = append(servers, map[string]interface{}{
		"type":            "xdial-mobile",
		"tag":             mobileDispatcherDNSTag,
		"public_fallback": mobilePublicDNSTag,
		"tailscale":       bindings,
	})
	config := map[string]interface{}{
		"servers": servers,
		"final":   mobileDispatcherDNSTag,
	}
	var rules []map[string]interface{}
	for _, endpointTag := range tailscaleTags {
		rules = append(rules, buildTailnetDNSRules(mobileTailscaleDNSTag(endpointTag))...)
	}
	if len(rules) > 0 {
		config["rules"] = rules
	}
	return config
}

func buildTransparentProxyDNS(
	profile *Profile,
	scenario *Scenario,
	subTagMap map[string]string,
	subGroupTagMap map[string]map[string]string,
	validTags map[string]bool,
	magicDNSEndpointTags []string,
	systemDNS []string,
	defaultOutboundTag string,
	needsProxyEndpointBootstrap bool,
	baseUsername string,
	defaultLineID string,
	addressFamily transparentProxyAddressFamilyPolicy,
) (map[string]interface{}, error) {
	primarySystemDNS, err := validateTransparentProxySystemDNS(systemDNS)
	if err != nil {
		return nil, err
	}
	servers := []map[string]interface{}{
		{
			"type":        "udp",
			"tag":         transparentSystemDNSTag,
			"server":      primarySystemDNS,
			"server_port": 53,
		},
		{
			"type":                      "local",
			"tag":                       TransparentNativeDNSTag,
			"xdial_use_system_resolver": true,
		},
	}
	if needsProxyEndpointBootstrap {
		servers = append(servers, map[string]interface{}{
			"type":   "https",
			"tag":    desktopPublicDNSTag,
			"server": "223.5.5.5",
		})
	}
	var rules []map[string]interface{}
	seenResolver := map[string]bool{
		transparentSystemDNSTag: true,
		TransparentNativeDNSTag: true,
		desktopPublicDNSTag:     needsProxyEndpointBootstrap,
	}
	// 运行期快照归属必须先于 Scenario 中的普通 DNS 分域求值。
	// 这里只安装空的纯内存 hosts transport 与静态 preferred_by
	// 规则；精确记录和 owned suffix 由 Provider 在 sing-box instance
	// Start 之后、系统网络 Commit 之前注入。
	for _, endpointTag := range magicDNSEndpointTags {
		serverTag := TailscaleMagicDNSDNSServerTag(endpointTag)
		servers = append(servers, buildTailnetHostsDNSServer(endpointTag))
		seenResolver[serverTag] = true
		rules = append(rules, buildTailnetHostsDNSRules(serverTag)...)
	}

	ensureResolver := func(resolverTag, outTag, addressFamilyStrategy string) {
		if seenResolver[resolverTag] {
			return
		}
		seenResolver[resolverTag] = true
		if selectedGroupUsesDirect(profile, outTag) {
			servers = append(servers, map[string]interface{}{
				"type": "local", "tag": resolverTag, "xdial_use_system_resolver": true,
			})
			return
		}
		switch resolverTag {
		case transparentEnterpriseDNSTag:
			servers = append(servers, map[string]interface{}{
				"type": "xdial-anyconnect",
				"tag":  resolverTag,
			})
		default:
			server := transparentProxyDoHIPv4Server
			resolver := map[string]interface{}{
				"type":   "https",
				"tag":    resolverTag,
				"server": server,
				"detour": outTag,
				"tls": map[string]interface{}{
					"enabled":     true,
					"server_name": "one.one.one.one",
				},
			}
			if addressFamilyStrategy == "ipv6_only" {
				server = transparentProxyDoHIPv6Server
				resolver["server"] = server
			}
			servers = append(servers, resolver)
		}
	}

	// DNS 与 route 使用同一个可见的域名 binding 顺序。纯 IP 与无法安全拆分的
	// mixed 分支在名字阶段没有可求值条件，因此不参与 DNS 分域，也不能吞掉后续
	// 明确的域名归属；route 仍在地址可用后按完整 Scenario 顺序求值。
	for index := range scenario.Bindings {
		binding := &scenario.Bindings[index]
		ruleSet := profile.FindRuleSet(binding.RuleSetID)
		if ruleSet == nil || !ruleSet.Enabled {
			continue
		}
		outTag := bindingOutboundTag(profile, binding, subTagMap, validTags)
		if outTag == "" {
			continue
		}
		strategy := ""
		if binding.SubscriptionID == "" {
			strategy = addressFamily.strategy(binding.LineID)
		}
		resolverTag := transparentProxyResolverTag(ruleSet, outTag)
		switch ruleSet.Type {
		case RuleSetTypeNative:
			if !nativeRuleDomainOnly(ruleSet.NativeRule) {
				continue
			}
			ensureResolver(resolverTag, outTag, strategy)
			rule := map[string]interface{}{"rule_set": sbRuleSetTag(ruleSet), "server": resolverTag}
			applyRuleSetInvert(rule, ruleSet)
			if strategy != "" {
				rule["strategy"] = strategy
			}
			rules = append(rules, rule)
		case RuleSetTypeApplication:
			selectors := applicationRuleSetSelectors(ruleSet)
			if len(selectors) == 0 {
				continue
			}
			ensureResolver(resolverTag, outTag, strategy)
			users := make([]string, 0, len(selectors))
			for _, selector := range selectors {
				users = append(users, ApplicationSOCKSUsername(baseUsername, selector))
			}
			// DNS 包先被 route 的 hijack-dns 接入解析器，但 SOCKS
			// auth_user 会保留在 DNS 上下文中。应用规则必须同时选择
			// 对应 Line 的解析出口，否则应用连接虽走指定 Line，域名
			// 查询仍可能从普通分域解析链外溢。
			rule := map[string]interface{}{
				"auth_user": users,
				"server":    resolverTag,
			}
			if strategy != "" {
				rule["strategy"] = strategy
			}
			applyRuleSetInvert(rule, ruleSet)
			rules = append(rules, rule)
		case RuleSetTypeManual:
			if len(ruleSet.Domains) > 0 && (!ruleSet.Invert || len(ruleSet.CIDRs) == 0) {
				ensureResolver(resolverTag, outTag, strategy)
				rule := map[string]interface{}{
					"domain_suffix": ruleSet.Domains,
					"server":        resolverTag,
				}
				if strategy != "" {
					rule["strategy"] = strategy
				}
				applyRuleSetInvert(rule, ruleSet)
				rules = append(rules, rule)
			}
		case RuleSetTypeURL:
			if ruleSet.RuntimeMatchKind != RuleSetMatchDomain {
				// IP 与无法安全拆分的混合规则不参与名字阶段的分域。
				continue
			}
			ensureResolver(resolverTag, outTag, strategy)
			rule := map[string]interface{}{
				"rule_set": sbRuleSetTag(ruleSet),
				"server":   resolverTag,
			}
			if strategy != "" {
				rule["strategy"] = strategy
			}
			applyRuleSetInvert(rule, ruleSet)
			rules = append(rules, rule)
		}
	}

	// RuleSet 的获取线路只描述规则资源的供应路径，不参与上面的用户流量
	// DNS/route 裁决。如果该线路本来就在当前 Scenario 的正式数据面中，仍要把它的
	// 专用 resolver 注册进来，供提交后的缓存刷新复用同一个运行实例。未进入
	// validTags 的获取线路不会因此被带进正式数据面；它由独立的获取会话刷新，
	// 不继承正式 traffic plan 的地址族能力。
	seenRuleSetSource := make(map[string]bool)
	for index := range scenario.Bindings {
		ruleSet := profile.FindRuleSet(scenario.Bindings[index].RuleSetID)
		if ruleSet == nil || !ruleSet.Enabled ||
			ruleSet.Type != RuleSetTypeURL || seenRuleSetSource[ruleSet.ID] {
			continue
		}
		seenRuleSetSource[ruleSet.ID] = true
		fetchLineID := ruleSet.EffectiveFetchLineID()
		if fetchLineID == builtinDirectLineID {
			continue
		}
		line := profile.FindLine(fetchLineID)
		if line == nil || !line.Enabled {
			continue
		}
		outTag := resolveOutboundTag(line)
		if outTag == "" || !validTags[outTag] {
			continue
		}
		ensureResolver(
			transparentProxyResolverForOutbound(outTag),
			outTag,
			addressFamily.strategy(fetchLineID),
		)
	}

	for _, sub := range profile.Subscriptions {
		groupTags := subGroupTagMap[sub.ID]
		if groupTags == nil {
			continue
		}
		compiled, _, err := collectSubscriptionRules(&sub, groupTags)
		if err != nil {
			return nil, fmt.Errorf("compile subscription %q DNS rules: %w", sub.ID, err)
		}
		for _, rule := range compiled {
			if !rule.domain {
				continue
			}
			if rule.outTag == rejectTag {
				rules = append(rules, map[string]interface{}{
					rule.matchKey: rule.values,
					"action":      "reject",
				})
				continue
			}
			resolverTag := transparentProxyResolverForOutbound(rule.outTag)
			ensureResolver(resolverTag, rule.outTag, "")
			rules = append(rules, map[string]interface{}{
				rule.matchKey: rule.values,
				"server":      resolverTag,
			})
		}
	}

	defaultResolverTag := transparentProxyResolverForOutbound(defaultOutboundTag)
	ensureResolver(
		defaultResolverTag,
		defaultOutboundTag,
		addressFamily.strategy(defaultLineID),
	)
	if strategy := addressFamily.strategy(defaultLineID); strategy != "" {
		rules = append(rules, map[string]interface{}{
			"server":   defaultResolverTag,
			"strategy": strategy,
		})
	}
	dnsConfig := map[string]interface{}{
		"servers":           servers,
		"final":             defaultResolverTag,
		"independent_cache": true,
	}
	if len(rules) > 0 {
		dnsConfig["rules"] = rules
	}
	return dnsConfig, nil
}

func validateTransparentProxySystemDNS(systemDNS []string) (string, error) {
	seen := make(map[netip.Addr]bool)
	var primary string
	for _, raw := range systemDNS {
		raw = strings.TrimSpace(raw)
		address, err := netip.ParseAddr(raw)
		if err != nil || address.IsUnspecified() || address.IsMulticast() {
			return "", fmt.Errorf("system DNS snapshot contains an invalid resolver")
		}
		address = address.Unmap()
		if seen[address] {
			continue
		}
		seen[address] = true
		if primary == "" {
			primary = address.String()
		}
	}
	if primary == "" {
		return "", fmt.Errorf("system DNS snapshot is unavailable")
	}
	return primary, nil
}

// TailscaleMagicDNSDNSServerTag exposes the exact DNS transport tag generated
// for an active Tailscale endpoint. Platform consumers must use this exported
// value instead of reimplementing the tag rule.
func TailscaleMagicDNSDNSServerTag(endpointTag string) string {
	return "xdial-dns-" + endpointTag
}

func mobileTailscaleDNSTag(endpointTag string) string {
	return TailscaleMagicDNSDNSServerTag(endpointTag)
}

func buildTailnetDNSServer(endpointTag string) map[string]interface{} {
	return map[string]interface{}{
		"type":                     "tailscale",
		"tag":                      mobileTailscaleDNSTag(endpointTag),
		"endpoint":                 endpointTag,
		"accept_default_resolvers": false,
		"accept_search_domain":     true,
	}
}

func buildTailnetHostsDNSServer(endpointTag string) map[string]interface{} {
	return map[string]interface{}{
		"type": "hosts",
		"tag":  TailscaleMagicDNSDNSServerTag(endpointTag),
		// upstream hosts 在 path 为空时会默认读取系统 hosts 文件。
		// patched memory_only 是一个显式、跨平台的密封开关：禁止
		// 任何文件输入，只接受本次会话在内存中注入的快照。
		"memory_only": true,
		"predefined":  map[string][]string{},
	}
}

func buildTailnetDNSRules(serverTag string) []map[string]interface{} {
	return []map[string]interface{}{
		{
			"preferred_by": serverTag,
			"server":       serverTag,
		},
		{
			"domain_regex": []string{tailnetSingleLabelDomainRegex},
			"server":       serverTag,
		},
	}
}

func buildTailnetHostsDNSRules(serverTag string) []map[string]interface{} {
	return []map[string]interface{}{
		{
			"preferred_by":  serverTag,
			"server":        serverTag,
			"disable_cache": true,
		},
	}
}

func buildMagicDNSRouteRules(
	endpointTags []string,
	resolveBeforeRoute bool,
) (rules []map[string]interface{}) {
	for _, endpointTag := range endpointTags {
		if resolveBeforeRoute {
			resolverTag := TailscaleMagicDNSDNSServerTag(endpointTag)
			rules = append(rules, map[string]interface{}{
				"preferred_by":  resolverTag,
				"action":        "resolve",
				"server":        resolverTag,
				"disable_cache": true,
			})
		}
		rules = append(rules, map[string]interface{}{
			"preferred_by": endpointTag,
			"outbound":     endpointTag,
		})
	}
	return rules
}

func buildSystemRouteRules(includeDesktopDiagnostics bool) []map[string]interface{} {
	rules := []map[string]interface{}{
		{"action": "sniff"},
		// DNS 由 sing-box 拦截并自己应答（与 NE 端同款），绝不把原始 DNS 包
		// 强制直出——启动前 Underlay 的 resolver 可能只在下层虚拟接口中可达，
		// 错误选择接口会形成解析黑洞。
		{"protocol": "dns", "action": "hijack-dns"},
	}
	if includeDesktopDiagnostics {
		rules = append(rules, map[string]interface{}{
			"domain_suffix": testDomains,
			"outbound":      testSelectorTag,
		})
	}
	return rules
}

func buildNESystemRouteRules() []map[string]interface{} {
	return []map[string]interface{}{
		{"action": "sniff"},
		{"protocol": "dns", "action": "hijack-dns"},
	}
}

// buildTransparentProxyScenarioRouteRules 把每个 Scenario binding 编译成一段连续的
// “解析 + 裁决”动作，并严格保留 binding 的相对顺序。
//
// - 手动域名：目标 Line 的 DNS → 域名 route；
// - 手动 IP：启动前系统 DNS → IP route；
// - 已检查为纯域名/纯 IP 的本地规则集分别走同样两条路径；
// - 混合或无法安全分类的规则集按用户约定走保守的系统 DNS。
// - 应用身份：原生 SOCKS auth_user → route；同一身份也在 DNS 规则中选择目标 Line 的解析出口。
func buildTransparentProxyScenarioRouteRules(
	profile *Profile,
	scenario *Scenario,
	subTagMap map[string]string,
	validTags map[string]bool,
	baseUsername string,
	addressFamily transparentProxyAddressFamilyPolicy,
) (rules []map[string]interface{}) {
	for _, binding := range scenario.Bindings {
		ruleSet := profile.FindRuleSet(binding.RuleSetID)
		if ruleSet == nil || !ruleSet.Enabled {
			continue
		}
		outTag := bindingOutboundTag(profile, &binding, subTagMap, validTags)
		if outTag == "" {
			continue
		}
		strategy := ""
		if binding.SubscriptionID == "" {
			strategy = addressFamily.strategy(binding.LineID)
		}
		rules = append(rules, compileTransparentProxyRuleSet(
			ruleSet,
			outTag,
			baseUsername,
			strategy,
		)...)
	}
	return
}

func bindingOutboundTag(
	profile *Profile,
	binding *RuleBinding,
	subTagMap map[string]string,
	validTags map[string]bool,
) string {
	var outTag string
	if binding.SubscriptionID != "" {
		outTag = subTagMap[binding.SubscriptionID]
	} else {
		line := profile.FindLine(binding.LineID)
		switch {
		case line == nil:
			if binding.LineID != builtinDirectLineID {
				return ""
			}
			outTag = "direct"
		case !line.Enabled:
			return ""
		default:
			outTag = resolveOutboundTag(line)
		}
	}
	if outTag == "" || !validTags[outTag] {
		return ""
	}
	return outTag
}

func compileTransparentProxyRuleSet(
	ruleSet *RuleSet,
	outTag string,
	baseUsername string,
	addressFamilyStrategy string,
) []map[string]interface{} {
	switch ruleSet.Type {
	case RuleSetTypeNative:
		route := map[string]interface{}{"rule_set": sbRuleSetTag(ruleSet), "outbound": outTag}
		applyRuleSetInvert(route, ruleSet)
		if nativeRuleDomainOnly(ruleSet.NativeRule) {
			resolve := map[string]interface{}{"rule_set": sbRuleSetTag(ruleSet), "action": "resolve", "server": transparentProxyResolverTag(ruleSet, outTag)}
			applyRuleSetInvert(resolve, ruleSet)
			if addressFamilyStrategy != "" {
				resolve["strategy"] = addressFamilyStrategy
			}
			return []map[string]interface{}{resolve, route}
		}
		if ruleSet.NoResolve {
			return []map[string]interface{}{route}
		}
		return []map[string]interface{}{transparentProxySystemResolveRule(), route}
	case RuleSetTypeApplication:
		selectors := applicationRuleSetSelectors(ruleSet)
		if len(selectors) == 0 {
			return nil
		}
		users := make([]string, 0, len(selectors))
		for _, selector := range selectors {
			users = append(users, ApplicationSOCKSUsername(baseUsername, selector))
		}
		route := map[string]interface{}{
			"auth_user": users,
			"outbound":  outTag,
		}
		applyRuleSetInvert(route, ruleSet)
		if addressFamilyStrategy == "" && outTag == "direct" {
			return []map[string]interface{}{route}
		}
		// 非 Direct 的应用流量即使没有地址族限制，也保留一个同 Line 的
		// resolve 动作：它只在应用自带的地址需要纠正时才生效。
		resolve := map[string]interface{}{
			"auth_user": users,
			"action":    "resolve",
			"server":    transparentProxyResolverTag(ruleSet, outTag),
		}
		if addressFamilyStrategy != "" {
			resolve["strategy"] = addressFamilyStrategy
		}
		applyRuleSetInvert(resolve, ruleSet)
		return []map[string]interface{}{resolve, route}
	case RuleSetTypeManual:
		if ruleSet.Invert {
			return compileInvertedTransparentProxyManualRuleSet(
				ruleSet,
				outTag,
				addressFamilyStrategy,
			)
		}
		var rules []map[string]interface{}
		if len(ruleSet.Domains) > 0 {
			resolver := transparentProxyResolverTag(ruleSet, outTag)
			resolve := map[string]interface{}{
				"domain_suffix": ruleSet.Domains,
				"action":        "resolve",
				"server":        resolver,
			}
			if addressFamilyStrategy != "" {
				resolve["strategy"] = addressFamilyStrategy
			}
			rules = append(rules,
				resolve,
				map[string]interface{}{
					"domain_suffix": ruleSet.Domains,
					"outbound":      outTag,
				},
			)
		}
		if len(ruleSet.CIDRs) > 0 {
			rules = append(rules,
				transparentProxySystemResolveRule(),
				map[string]interface{}{
					"ip_cidr":  ruleSet.CIDRs,
					"outbound": outTag,
				},
			)
		}
		return rules
	case RuleSetTypeURL:
		if ruleSet.URL == "" {
			return nil
		}
		match := map[string]interface{}{"rule_set": sbRuleSetTag(ruleSet)}
		route := map[string]interface{}{
			"rule_set": sbRuleSetTag(ruleSet),
			"outbound": outTag,
		}
		applyRuleSetInvert(match, ruleSet)
		applyRuleSetInvert(route, ruleSet)
		switch ruleSet.RuntimeMatchKind {
		case RuleSetMatchDomain:
			match["action"] = "resolve"
			match["server"] = transparentProxyResolverTag(ruleSet, outTag)
			if addressFamilyStrategy != "" {
				match["strategy"] = addressFamilyStrategy
			}
			return []map[string]interface{}{match, route}
		case RuleSetMatchIP, RuleSetMatchMixed, RuleSetMatchUnknown:
			if ruleSet.NoResolve {
				return []map[string]interface{}{route}
			}
			return []map[string]interface{}{transparentProxySystemResolveRule(), route}
		}
	}
	return nil
}

func compileInvertedTransparentProxyManualRuleSet(
	ruleSet *RuleSet,
	outTag string,
	addressFamilyStrategy string,
) []map[string]interface{} {
	hasDomains := len(ruleSet.Domains) > 0
	hasCIDRs := len(ruleSet.CIDRs) > 0
	switch {
	case hasDomains && hasCIDRs:
		// 手动 RuleSet 的两类内容是并集；取反必须放在整个
		// logical-or 外层，不能分别取反后再按顺序匹配。
		return []map[string]interface{}{
			transparentProxySystemResolveRule(),
			{
				"type": "logical",
				"mode": "or",
				"rules": []map[string]interface{}{
					{"domain_suffix": ruleSet.Domains},
					{"ip_cidr": ruleSet.CIDRs},
				},
				"invert":   true,
				"outbound": outTag,
			},
		}
	case hasDomains:
		resolve := map[string]interface{}{
			"domain_suffix": ruleSet.Domains,
			"action":        "resolve",
			"server":        transparentProxyResolverTag(ruleSet, outTag),
		}
		if addressFamilyStrategy != "" {
			resolve["strategy"] = addressFamilyStrategy
		}
		route := map[string]interface{}{
			"domain_suffix": ruleSet.Domains,
			"outbound":      outTag,
		}
		applyRuleSetInvert(resolve, ruleSet)
		applyRuleSetInvert(route, ruleSet)
		return []map[string]interface{}{resolve, route}
	case hasCIDRs:
		route := map[string]interface{}{
			"ip_cidr":  ruleSet.CIDRs,
			"outbound": outTag,
		}
		applyRuleSetInvert(route, ruleSet)
		return []map[string]interface{}{transparentProxySystemResolveRule(), route}
	default:
		return nil
	}
}

// transparentFlowAddressCorrectionKey 是补丁 0017 的 resolve 选项：
// 已按名字归属某条 Line 的流量，若应用给出的公网地址不在该 Line 的解析
// 结果中，就改按该 Line 的结果连接。
const transparentFlowAddressCorrectionKey = "xdial_correct_flow_address"

// markLineOwnedFlowAddressCorrection 只给使用 Line 自有 resolver 的 resolve
// 动作打开地址纠正。应用自己的 DNS 可能不经过 XDial（mDNSResponder 的旧
// querier、应用内置解析器、接管前的缓存），拿到 Underlay 视角甚至被篡改的
// 地址；名字已决定 Line 时，连接地址也必须来自同一 Line 的解析视角。
//
// Direct、启动前系统 DNS 和 MagicDNS hosts 都不属于这里：Direct 本来就采用
// Underlay 解析语义，应用自己的答案就是该视角。判断依据是编译后 resolver
// 的实际类型，而不是出口 tag——选中 Direct 的选择器组仍是系统 resolver。
func markLineOwnedFlowAddressCorrection(
	routeRules []map[string]interface{},
	dnsConfig map[string]interface{},
) {
	servers, _ := dnsConfig["servers"].([]map[string]interface{})
	lineOwned := make(map[string]bool, len(servers))
	for _, server := range servers {
		tag, _ := server["tag"].(string)
		if tag == "" {
			continue
		}
		switch server["type"] {
		case "xdial-anyconnect":
			lineOwned[tag] = true
		case "https":
			if detour, _ := server["detour"].(string); detour != "" && detour != "direct" {
				lineOwned[tag] = true
			}
		}
	}
	for _, rule := range routeRules {
		if rule["action"] != "resolve" {
			continue
		}
		if server, _ := rule["server"].(string); lineOwned[server] {
			rule[transparentFlowAddressCorrectionKey] = true
		}
	}
}

func transparentProxySystemResolveRule() map[string]interface{} {
	return map[string]interface{}{
		"action": "resolve",
		"server": transparentSystemDNSTag,
	}
}

func transparentProxyResolverTag(ruleSet *RuleSet, outTag string) string {
	if outTag == "direct" {
		return TransparentNativeDNSTag
	}
	if outTag == "vpn" && ruleSet.Type == RuleSetTypeManual && !ruleSet.Invert {
		return transparentEnterpriseDNSTag
	}
	return desktopProxyDNSTag(outTag)
}

func buildScenarioRouteRules(
	profile *Profile,
	scenario *Scenario,
	subTagMap map[string]string,
	validTags map[string]bool,
) (acceptanceRules []map[string]interface{}, ordinaryRules []map[string]interface{}) {

	for _, binding := range scenario.Bindings {
		ruleSet := profile.FindRuleSet(binding.RuleSetID)
		if ruleSet == nil || !ruleSet.Enabled {
			continue
		}

		var outTag string
		if binding.SubscriptionID != "" {
			outTag = subTagMap[binding.SubscriptionID]
		} else {
			line := profile.FindLine(binding.LineID)
			switch {
			case line == nil:
				// 悬空引用已由 inspectScenarioReferences 在生成入口拒绝，能到这里
				// 的只有内建 direct（profile 里没有显式直连线路时的保留 ID）。
				if binding.LineID != builtinDirectLineID {
					continue
				}
				outTag = "direct"
			case !line.Enabled:
				// 被禁用的线路必须显式跳过：direct/vpn 这类固定 tag 恒在
				// validTags 里，不查 Enabled 就会让"已禁用的线路"悄悄把流量
				// 塞进 direct 或别人的 VPN 隧道（对应 WarningDisabledLine）。
				continue
			default:
				outTag = resolveOutboundTag(line)
			}
		}
		if outTag == "" || !validTags[outTag] {
			continue
		}

		routeRule := buildRouteRule(ruleSet, outTag)
		if routeRule != nil {
			if isConnectivityAcceptanceRuleSetID(ruleSet.ID) {
				acceptanceRules = append(acceptanceRules, routeRule)
			} else {
				ordinaryRules = append(ordinaryRules, routeRule)
			}
		}
	}

	return acceptanceRules, ordinaryRules
}

func isConnectivityAcceptanceRuleSetID(id string) bool {
	return id == connectivityDirectRuleSetID || id == connectivityOutboundRuleSetID
}

func buildRouteRule(c *RuleSet, outTag string) map[string]interface{} {
	switch c.Type {
	case RuleSetTypeNative:
		rule := map[string]interface{}{"rule_set": sbRuleSetTag(c), "outbound": outTag}
		applyRuleSetInvert(rule, c)
		return rule
	case RuleSetTypeURL:
		if c.URL == "" {
			return nil
		}
		rule := map[string]interface{}{
			"rule_set": sbRuleSetTag(c),
			"outbound": outTag,
		}
		applyRuleSetInvert(rule, c)
		return rule
	case RuleSetTypeManual:
		rule := map[string]interface{}{
			"outbound": outTag,
		}
		if len(c.Domains) > 0 {
			rule["domain_suffix"] = c.Domains
		}
		if len(c.CIDRs) > 0 {
			rule["ip_cidr"] = c.CIDRs
		}
		if len(c.Domains) == 0 && len(c.CIDRs) == 0 {
			return nil
		}
		applyRuleSetInvert(rule, c)
		return rule
	}
	return nil
}

type ApplicationProcessSelectorKind string

const (
	ApplicationProcessSelectorBundlePath ApplicationProcessSelectorKind = "bundle_path"
	ApplicationProcessSelectorBundleID   ApplicationProcessSelectorKind = "bundle_identifier"
	ApplicationProcessSelectorName       ApplicationProcessSelectorKind = "name"
	ApplicationProcessSelectorExactPath  ApplicationProcessSelectorKind = "exact_path"
	ApplicationProcessSelectorPathPrefix ApplicationProcessSelectorKind = "path_prefix"
)

// ApplicationProcessSelector is the canonical, platform-neutral envelope for
// Surge PROCESS-NAME semantics. The Provider matches it against the actual
// executable path supplied by macOS; sing-box only sees its derived username.
type ApplicationProcessSelector struct {
	Kind  ApplicationProcessSelectorKind `json:"kind"`
	Value string                         `json:"value"`
}

func (s ApplicationProcessSelector) key() string {
	return string(s.Kind) + "\x00" + s.Value
}

// applicationRuleSetSelectors flattens all user-visible App Bundle and process
// entries into one stable list. App Bundle entries retain their dedicated kind
// so the control plane can display them without turning them into opaque text.
func applicationRuleSetSelectors(ruleSet *RuleSet) []ApplicationProcessSelector {
	if ruleSet == nil {
		return nil
	}
	seen := make(map[string]struct{})
	var selectors []ApplicationProcessSelector
	appendSelector := func(selector ApplicationProcessSelector) {
		key := selector.key()
		if _, exists := seen[key]; exists {
			return
		}
		seen[key] = struct{}{}
		selectors = append(selectors, selector)
	}
	for _, application := range ruleSet.Applications {
		if bundleIdentifier, ok := canonicalApplicationBundleIdentifier(application.BundleIdentifier); ok {
			appendSelector(ApplicationProcessSelector{
				Kind: ApplicationProcessSelectorBundleID, Value: bundleIdentifier,
			})
		}
		bundlePath, ok := canonicalApplicationBundlePath(application.Path)
		if !ok {
			continue
		}
		appendSelector(ApplicationProcessSelector{
			Kind: ApplicationProcessSelectorBundlePath, Value: bundlePath,
		})
	}
	for _, expression := range ruleSet.Processes {
		selector, ok := canonicalApplicationProcessSelector(expression)
		if !ok {
			continue
		}
		appendSelector(selector)
	}
	return selectors
}

func canonicalApplicationBundleIdentifier(raw string) (string, bool) {
	if raw == "" || len(raw) > 255 || strings.TrimSpace(raw) != raw {
		return "", false
	}
	for _, value := range raw {
		if value > unicode.MaxASCII || unicode.IsControl(value) || unicode.IsSpace(value) {
			return "", false
		}
	}
	return raw, true
}

func canonicalApplicationProcessSelector(raw string) (ApplicationProcessSelector, bool) {
	if raw == "" || len(raw) > 4096 || strings.TrimSpace(raw) != raw ||
		strings.IndexFunc(raw, func(r rune) bool {
			return unicode.IsControl(r) || unicode.Is(unicode.Cf, r)
		}) >= 0 {
		return ApplicationProcessSelector{}, false
	}
	if !strings.HasPrefix(raw, "/") {
		if len(raw) > 255 || strings.Contains(raw, "/") {
			return ApplicationProcessSelector{}, false
		}
		return ApplicationProcessSelector{Kind: ApplicationProcessSelectorName, Value: raw}, true
	}
	if strings.HasSuffix(raw, "/") {
		prefix := strings.TrimSuffix(raw, "/")
		if prefix == "" || path.Clean(prefix) != prefix {
			return ApplicationProcessSelector{}, false
		}
		return ApplicationProcessSelector{Kind: ApplicationProcessSelectorPathPrefix, Value: prefix}, true
	}
	if path.Clean(raw) != raw {
		return ApplicationProcessSelector{}, false
	}
	return ApplicationProcessSelector{Kind: ApplicationProcessSelectorExactPath, Value: raw}, true
}

func applyRuleSetInvert(rule map[string]interface{}, ruleSet *RuleSet) {
	if ruleSet != nil && ruleSet.Invert {
		rule["invert"] = true
	}
}

// sbCollectRuleSets 收集 sing-box 配置层的 rule_set 资源块（route.rule_set 数组里
// 的 remote 规则集下载条目）。
//
// 命名前缀 sb 用来把这一层（sing-box 配置里的 rule_set，处理远程 .srs/.json
// 下载资源）与新的数据模型层 RuleSet（本仓库自己的“规则”概念）区分开：二者
// 语义不同，前者是 sing-box 协议字段，后者是我们的持久化数据类型。本函数遍历
// 数据模型的 RuleSet（URL 类型），为每个生成一个 sing-box rule_set 资源。
func sbCollectRuleSets(
	profile *Profile,
	scenario *Scenario,
	subTagMap map[string]string,
	validTags map[string]bool,
) []map[string]interface{} {
	seen := map[string]bool{}
	var sets []map[string]interface{}

	for _, binding := range scenario.Bindings {
		c := profile.FindRuleSet(binding.RuleSetID)
		if c == nil || !c.Enabled || (c.Type != RuleSetTypeURL && c.Type != RuleSetTypeNative) || (c.Type == RuleSetTypeURL && c.URL == "") {
			continue
		}
		tag := sbRuleSetTag(c)
		if seen[tag] {
			continue
		}
		seen[tag] = true

		if c.Type == RuleSetTypeNative {
			sets = append(sets, map[string]interface{}{"type": "inline", "tag": tag, "rules": []json.RawMessage{c.NativeRule}})
			continue
		}
		format := sbResolveRuleSetFormat(c)
		if strings.HasPrefix(c.URL, "file://") {
			sets = append(sets, map[string]interface{}{
				"type":   "local",
				"tag":    tag,
				"format": format,
				"path":   strings.TrimPrefix(c.URL, "file://"),
			})
		} else {
			sets = append(sets, map[string]interface{}{
				"type":            "remote",
				"tag":             tag,
				"format":          format,
				"url":             c.URL,
				"download_detour": sbDownloadDetour(profile, c, validTags),
			})
		}
	}
	return sets
}

// sbDownloadDetour 选 remote 规则集的下载出口。
//
// 不能一律 direct：远程规则集可能位于 Direct 不可达的受限路径，从同一路径下载会
// 失败。而首次
// 下载失败是硬失败不是降级 —— sing-box 的 router 在启动阶段直接 FATAL 退出。
//
// 但绑定线路不是都能用，能当 detour 的只有订阅节点/策略组和代理线路：
//   - 移动端 Tailscale endpoint 的 tsnet server 在 StartStatePostStart 才 Start，而
//     rule_set 首次下载发生在更早的 StartStateStart（box.preStart → Router.Start），
//     那时 endpoint 还没有 tailnet 地址和 netstack，拿它当 detour 必然失败。
//   - vpn 出口在桌面是本地 go-socks5 桥：sing-box 把域名原样 CONNECT 过去，桥用
//     启动前系统 resolver 解析，其视角可能与隧道不一致，还可能解出 IPv6 而
//     VPNBridge.DialTCP 只收 IPv4。不可靠，同样退回 direct。
//
// 桌面的 vpn/direct 绑定不会真的走到这里下载：daemon 已在启动 sing-box 前把它们
// 抓成本地文件（engine.prepareRuleSets），生成的是 type:local。这个 direct 兜底
// 主要覆盖移动端和测试调用方。
func sbDownloadDetour(
	profile *Profile,
	ruleSet *RuleSet,
	validTags map[string]bool,
) string {
	var tag string
	fetchLineID := ruleSet.EffectiveFetchLineID()
	if fetchLineID == builtinDirectLineID {
		return "direct"
	}
	line := profile.FindLine(fetchLineID)
	if line == nil || !line.Enabled || line.Type == LineTypeTailscale {
		return "direct"
	}
	tag = resolveOutboundTag(line)
	if tag == "" || tag == "direct" || tag == "vpn" || !validTags[tag] {
		return "direct"
	}
	return tag
}

// sbRuleSetTag 生成 sing-box rule_set 资源块（及引用它的 route rule）用的 tag。
// sb 前缀表明这是 sing-box 配置层的 tag，不是数据模型 RuleSet 的字段。
func sbRuleSetTag(c *RuleSet) string {
	return "ruleset-" + c.ID
}

// sbResolveRuleSetFormat 推断 sing-box rule_set 资源的 format（binary/source）。
// sb 前缀同上：处理的是 sing-box 配置层的 rule_set 下载格式。
func sbResolveRuleSetFormat(c *RuleSet) string {
	if c.Format != "" && c.Format != "auto" {
		switch c.Format {
		case "srs", "binary":
			return "binary"
		case "json", "source":
			return "source"
		}
	}
	ext := strings.ToLower(path.Ext(c.URL))
	switch ext {
	case ".srs":
		return "binary"
	case ".json":
		return "source"
	default:
		return "binary"
	}
}

func resolveOutboundTag(line *Line) string {
	switch line.Type {
	case LineTypeDirect:
		return "direct"
	case LineTypeVPN:
		return "vpn"
	case LineTypeTailscale:
		return tailscaleEndpointTag(line)
	default:
		return "proxy-" + line.ID
	}
}

func tailscaleEndpointTag(line *Line) string {
	return "tailscale-" + line.ID
}

func firstString(values []string) string {
	if len(values) == 0 {
		return ""
	}
	return values[0]
}

// rejectTag 是 groupTags 里的哨兵值：不是真实 outbound tag（含 NUL 保证永不与
// slugify 产物撞车），表示"指向该组/规则应生成 action:reject 而非 outbound 引用"。
const rejectTag = "\x00reject"

// isRejectName 判断订阅规则/组成员里的名字是否为拦截策略（Clash/Surge 内置）。
func isRejectName(name string) bool {
	switch strings.ToUpper(name) {
	case "REJECT", "REJECT-DROP", "REJECT-TINYGIF", "BLOCK":
		return true
	}
	return false
}

// buildSubscriptionOutbounds 返回所有 outbound、主 tag、以及组名→tag 映射
func buildSubscriptionOutbounds(sub *Subscription, platform Platform) ([]map[string]interface{}, string, map[string]string) {
	prefix := sub.ID + "-"

	// 1. 生成所有节点 outbound，建立 name→tag 映射
	var nodeObs []map[string]interface{}
	nameToTag := map[string]string{}
	for _, line := range sub.Lines {
		if !line.Enabled {
			continue
		}
		lineCopy := line
		lineCopy.ID = prefix + line.ID
		ob := buildProxyOutbound(&lineCopy)
		if ob != nil {
			tag := ob["tag"].(string)
			nodeObs = append(nodeObs, ob)
			nameToTag[line.Name] = tag
		}
	}
	if len(nodeObs) == 0 {
		return nil, "", nil
	}

	groupTags := map[string]string{} // groupName → tag
	var groupObs []map[string]interface{}

	if len(sub.ProxyGroups) > 0 {
		// 2a. 有策略组：先按真实可达成员做 fixpoint。不能先把所有组都当成有效
		// outbound，否则“有效节点 + 空子组”会把不存在的 tag 塞进 selector，
		// 直到 sing-box 启动时才失败。
		nameToTag["DIRECT"] = "direct"
		nameToTag["Direct"] = "direct"
		const (
			groupUnavailable = iota
			groupRejectOnly
			groupOutbound
		)
		groupDefinitions := make(map[string]ProxyGroup, len(sub.ProxyGroups))
		for _, group := range sub.ProxyGroups {
			if _, exists := groupDefinitions[group.Name]; !exists {
				groupDefinitions[group.Name] = group
			}
		}
		groupStates := make(map[string]int, len(groupDefinitions))
		for changed := true; changed; {
			changed = false
			for name, group := range groupDefinitions {
				next := groupUnavailable
				for _, member := range group.Proxies {
					if isRejectName(member) || groupStates[member] == groupRejectOnly {
						if next < groupRejectOnly {
							next = groupRejectOnly
						}
						continue
					}
					if _, ok := nameToTag[member]; ok || groupStates[member] == groupOutbound {
						next = groupOutbound
						break
					}
				}
				if next > groupStates[name] {
					groupStates[name] = next
					changed = true
				}
			}
		}

		// 为最终确实存在的 outbound 分配唯一 tag；纯拦截组映射到哨兵，
		// 完全不可用的组不进入映射。
		// slugify 把非 ASCII 全映射为 '-'，中文组名（香港节点/台湾节点→"----"）会
		// 撞成同一 tag，导致 sing-box 因 duplicate outbound tag 拒绝启动（表现为假连接）。
		// 去重：首个组保留无后缀 base（Swift NetworkInfo 只按第一个组算 tag，保持兼容），
		// 撞车/同名组追加 -N。
		usedTags := map[string]bool{}
		for _, g := range sub.ProxyGroups {
			if _, exists := groupTags[g.Name]; exists {
				continue // 同名组只保留第一个
			}
			if groupStates[g.Name] == groupRejectOnly {
				groupTags[g.Name] = rejectTag
				continue
			}
			if groupStates[g.Name] != groupOutbound {
				continue
			}
			base := "sub-" + prefix + slugify(g.Name)
			tag := base
			for i := 2; usedTags[tag]; i++ {
				tag = fmt.Sprintf("%s-%d", base, i)
			}
			usedTags[tag] = true
			groupTags[g.Name] = tag
		}
		processedGroups := map[string]bool{}
		for _, g := range sub.ProxyGroups {
			if processedGroups[g.Name] || groupStates[g.Name] != groupOutbound {
				continue
			}
			processedGroups[g.Name] = true
			var memberTags []string
			selectedTag := ""
			for _, name := range g.Proxies {
				if isRejectName(name) {
					continue
				}
				if tag, ok := nameToTag[name]; ok {
					memberTags = append(memberTags, tag)
					if name == g.Selected {
						selectedTag = tag
					}
				} else if tag, ok := groupTags[name]; ok && tag != rejectTag {
					memberTags = append(memberTags, tag)
					if name == g.Selected {
						selectedTag = tag
					}
				}
			}
			if len(memberTags) == 0 {
				delete(groupTags, g.Name)
				continue
			}

			ob := map[string]interface{}{
				"tag":       groupTags[g.Name],
				"outbounds": memberTags,
			}
			switch g.Type {
			case "url-test", "urltest":
				ob["type"] = "urltest"
				url := ""
				if !platform.isNetworkExtension() {
					url = g.URL
				}
				if url == "" {
					url = "https://www.gstatic.com/generate_204"
				}
				ob["url"] = url
				interval := g.Interval
				if interval <= 0 {
					interval = 300
				}
				if interval > 1800 {
					interval = 1800
				}
				ob["interval"] = fmt.Sprintf("%ds", interval)
			default:
				ob["type"] = "selector"
				if selectedTag != "" {
					ob["default"] = selectedTag
				}
			}
			groupObs = append(groupObs, ob)
		}
	} else {
		// 2b. 无策略组：生成一个默认 group
		var allTags []string
		for _, ob := range nodeObs {
			allTags = append(allTags, ob["tag"].(string))
		}
		groupTag := "sub-" + sub.ID
		group := map[string]interface{}{
			"tag":       groupTag,
			"outbounds": allTags,
		}
		switch sub.Strategy {
		case "selector":
			group["type"] = "selector"
			if selectedTag := nameToTag[sub.Selected]; selectedTag != "" {
				group["default"] = selectedTag
			}
		default:
			group["type"] = "urltest"
			url := ""
			if !platform.isNetworkExtension() {
				url = sub.TestURL
			}
			if url == "" {
				url = "https://www.gstatic.com/generate_204"
			}
			group["url"] = url
			interval := sub.TestInterval
			if interval <= 0 {
				interval = 300
			}
			if interval > 1800 {
				interval = 1800
			}
			group["interval"] = fmt.Sprintf("%ds", interval)
		}
		groupObs = append(groupObs, group)
		groupTags["__default__"] = groupTag
	}

	// 主 tag：第一个真正生成了 outbound 的策略组（按原顺序找），或默认组
	mainTag := ""
	if len(sub.ProxyGroups) > 0 {
		for _, g := range sub.ProxyGroups {
			if tag, ok := groupTags[g.Name]; ok && tag != rejectTag {
				mainTag = tag
				break
			}
		}
	} else {
		mainTag = groupTags["__default__"]
	}

	all := append(nodeObs, groupObs...)
	return all, mainTag, groupTags
}

// RuntimeSubscriptionCatalog exposes the exact tags generated for subscription
// nodes and groups. Mobile clients use this catalog for live selector changes and
// latency probes instead of reimplementing slug/collision rules in Swift.
type RuntimeSubscriptionCatalog struct {
	Subscriptions []RuntimeSubscription `json:"subscriptions"`
}

type RuntimeSubscription struct {
	ID       string `json:"id"`
	Name     string `json:"name"`
	Strategy string `json:"strategy"`
	// MainTag is the exact primary outbound selected by
	// buildSubscriptionOutbounds, not a tag reconstructed by a consumer.
	MainTag string `json:"main_tag"`
	// ReadinessTags contains only generated proxy groups that can affect the
	// active subscription: its primary group and groups referenced by its own
	// compiled rules. Direct/reject targets and unused declared groups are
	// intentionally excluded.
	ReadinessTags []string        `json:"readiness_tags"`
	Nodes         []RuntimeMember `json:"nodes"`
	Groups        []RuntimeGroup  `json:"groups"`
}

type RuntimeGroup struct {
	Name     string          `json:"name"`
	Tag      string          `json:"tag"`
	Type     string          `json:"type"`
	Selected string          `json:"selected,omitempty"`
	Members  []RuntimeMember `json:"members"`
}

type RuntimeMember struct {
	ID   string `json:"id,omitempty"`
	Name string `json:"name"`
	Tag  string `json:"tag"`
}

type RuntimeLineCatalog struct {
	Lines []RuntimeMember `json:"lines"`
}

// BuildLineRuntimeCatalog exports the exact Line tags generated by Go. Desktop
// diagnostics consume this instead of extending Swift's legacy tag reimplementation.
func BuildLineRuntimeCatalog(profile *Profile) RuntimeLineCatalog {
	catalog := RuntimeLineCatalog{Lines: []RuntimeMember{}}
	if profile == nil {
		return catalog
	}
	for index := range profile.Lines {
		line := &profile.Lines[index]
		if !line.Enabled {
			continue
		}
		catalog.Lines = append(catalog.Lines, RuntimeMember{
			ID:   line.ID,
			Name: line.Name,
			Tag:  resolveOutboundTag(line),
		})
	}
	return catalog
}

func BuildSubscriptionRuntimeCatalog(profile *Profile, platform Platform) RuntimeSubscriptionCatalog {
	catalog := RuntimeSubscriptionCatalog{Subscriptions: []RuntimeSubscription{}}
	for index := range profile.Subscriptions {
		subscription := &profile.Subscriptions[index]
		if !subscription.Enabled {
			continue
		}
		generated, mainTag, groupTags := buildSubscriptionOutbounds(subscription, platform)
		if len(generated) == 0 {
			continue
		}
		generatedTags := make(map[string]bool, len(generated))
		for _, outbound := range generated {
			if tag, ok := outbound["tag"].(string); ok {
				generatedTags[tag] = true
			}
		}

		entry := RuntimeSubscription{
			ID: subscription.ID, Name: subscription.Name, Strategy: subscription.Strategy,
			MainTag: mainTag,
			ReadinessTags: subscriptionReadinessTags(
				subscription,
				mainTag,
				groupTags,
				generatedTags,
			),
			Nodes:  []RuntimeMember{},
			Groups: []RuntimeGroup{},
		}
		memberTags := make(map[string]string)
		for _, line := range subscription.Lines {
			if !line.Enabled {
				continue
			}
			lineCopy := line
			lineCopy.ID = subscription.ID + "-" + line.ID
			outbound := buildProxyOutbound(&lineCopy)
			if outbound == nil {
				continue
			}
			tag, _ := outbound["tag"].(string)
			if tag == "" || !generatedTags[tag] {
				continue
			}
			memberTags[line.Name] = tag
			entry.Nodes = append(entry.Nodes, RuntimeMember{ID: line.ID, Name: line.Name, Tag: tag})
		}
		memberTags["DIRECT"] = "direct"
		memberTags["Direct"] = "direct"
		for name, tag := range groupTags {
			if name != "__default__" && tag != rejectTag {
				memberTags[name] = tag
			}
		}

		if len(subscription.ProxyGroups) == 0 {
			if tag := groupTags["__default__"]; tag != "" {
				members := append([]RuntimeMember(nil), entry.Nodes...)
				entry.Groups = append(entry.Groups, RuntimeGroup{
					Name: "__default__", Tag: tag, Type: subscription.Strategy,
					Selected: subscription.Selected, Members: members,
				})
			}
		} else {
			seenGroups := make(map[string]bool)
			for _, group := range subscription.ProxyGroups {
				if seenGroups[group.Name] {
					continue
				}
				seenGroups[group.Name] = true
				tag := groupTags[group.Name]
				if tag == "" || tag == rejectTag || !generatedTags[tag] {
					continue
				}
				members := []RuntimeMember{}
				for _, memberName := range group.Proxies {
					memberTag := memberTags[memberName]
					if memberTag == "" || memberTag == rejectTag {
						continue
					}
					members = append(members, RuntimeMember{Name: memberName, Tag: memberTag})
				}
				entry.Groups = append(entry.Groups, RuntimeGroup{
					Name: group.Name, Tag: tag, Type: group.Type, Selected: group.Selected, Members: members,
				})
			}
		}
		catalog.Subscriptions = append(catalog.Subscriptions, entry)
	}
	return catalog
}

func subscriptionReadinessTags(
	subscription *Subscription,
	mainTag string,
	groupTags map[string]string,
	generatedTags map[string]bool,
) []string {
	tags := make([]string, 0, len(groupTags))
	seen := make(map[string]bool, len(groupTags))
	appendTag := func(tag string) {
		tag = strings.TrimSpace(tag)
		if tag == "" ||
			tag == "direct" ||
			tag == rejectTag ||
			!generatedTags[tag] ||
			seen[tag] {
			return
		}
		seen[tag] = true
		tags = append(tags, tag)
	}

	appendTag(mainTag)
	compiled, _, _ := collectSubscriptionRules(subscription, groupTags)
	for _, rule := range compiled {
		appendTag(rule.outTag)
	}
	return tags
}

type subscriptionCompiledRule struct {
	matchKey string
	values   interface{}
	outTag   string
	domain   bool
}

func subscriptionRuleOutboundTag(
	group string,
	groupTags map[string]string,
) (string, bool) {
	if outTag := groupTags[group]; outTag != "" {
		return outTag, true
	}
	// 这些名称属于订阅语法本身，不依赖生成出来的策略组 outbound。
	switch strings.ToUpper(group) {
	case "DIRECT":
		return "direct", true
	case "REJECT", "REJECT-DROP", "REJECT-TINYGIF", "BLOCK":
		return rejectTag, true
	default:
		return "", false
	}
}

// collectSubscriptionRules 把订阅语法规范化成有序 matcher；桌面旧路径与
// Transparent Proxy 的分阶段 DNS 编译共享这一份顺序事实。
func collectSubscriptionRules(
	sub *Subscription,
	groupTags map[string]string,
) ([]subscriptionCompiledRule, []map[string]interface{}, error) {
	var rules []subscriptionCompiledRule
	var sets []map[string]interface{}
	seenGeoIP := map[string]bool{}
	effectiveGeoIPRules, err := collectEffectiveSubscriptionGeoIPRules(
		sub,
		groupTags,
	)
	if err != nil {
		return nil, nil, err
	}
	geoIPByRuleIndex := make(map[int]effectiveSubscriptionGeoIPRule, len(effectiveGeoIPRules))
	for _, rule := range effectiveGeoIPRules {
		geoIPByRuleIndex[rule.ruleIndex] = rule
	}

	for index, r := range sub.Rules {
		outTag, effective := subscriptionRuleOutboundTag(r.Group, groupTags)
		if !effective {
			// 组名解析不到时：DIRECT→直连，REJECT 系→拦截哨兵，其余（含引用了被删的
			// 空组）才丢弃。此前 REJECT 走 else 分支被静默丢弃，广告/追踪拦截规则整体失效。
			continue
		}

		switch strings.ToUpper(strings.TrimSpace(r.Type)) {
		case "RULE-SET":
			// 原始未展开的 RULE-SET 占位（真正的展开在 subscription.ExpandRulesets
			// 解析期就地完成）。这里出现的都是残留占位，跳过。
			continue
		case "DOMAIN-SUFFIX":
			rules = append(rules, subscriptionCompiledRule{
				matchKey: "domain_suffix", values: []string{r.Value}, outTag: outTag, domain: true,
			})
		case "DOMAIN":
			rules = append(rules, subscriptionCompiledRule{
				matchKey: "domain", values: []string{r.Value}, outTag: outTag, domain: true,
			})
		case "DOMAIN-KEYWORD":
			rules = append(rules, subscriptionCompiledRule{
				matchKey: "domain_keyword", values: []string{r.Value}, outTag: outTag, domain: true,
			})
		case "IP-CIDR", "IP-CIDR6":
			rules = append(rules, subscriptionCompiledRule{
				matchKey: "ip_cidr", values: []string{r.Value}, outTag: outTag,
			})
		case "GEOIP":
			// sing-box 1.12 移除了内置 geoip，转换为显式本地或远程 rule-set。
			geoIPRule, exists := geoIPByRuleIndex[index]
			if !exists {
				return nil, nil, fmt.Errorf(
					"subscription %q GEOIP rule #%d was not compiled",
					sub.ID,
					index+1,
				)
			}
			if geoIPRule.private {
				// Clash 常用 GEOIP,LAN 表达私有地址；sing-box 对应原生
				// ip_is_private，不应为它构造一个不存在的远程国家规则集。
				rules = append(rules, subscriptionCompiledRule{
					matchKey: "ip_is_private", values: true, outTag: outTag,
				})
				continue
			}
			resource := geoIPRule.resource
			if !seenGeoIP[resource.tag] {
				seenGeoIP[resource.tag] = true
				set := map[string]interface{}{
					"tag":    resource.tag,
					"format": "binary",
				}
				if resource.local {
					set["type"] = "local"
					set["path"] = resource.path
				} else {
					set["type"] = "remote"
					set["url"] = resource.url
					set["download_detour"] = "direct"
				}
				sets = append(sets, set)
			}
			rules = append(rules, subscriptionCompiledRule{
				matchKey: "rule_set", values: resource.tag, outTag: outTag,
			})
		case "FINAL":
			// FINAL 不生成 route rule，由 sing-box 的 "final" 字段处理
			continue
		}
	}
	return rules, sets, nil
}

// buildSubscriptionRules 将订阅的规则转换为 sing-box route rules 和 rule_sets。
func buildSubscriptionRules(sub *Subscription, groupTags map[string]string) ([]map[string]interface{}, []map[string]interface{}, error) {
	compiled, sets, err := collectSubscriptionRules(sub, groupTags)
	if err != nil {
		return nil, nil, err
	}
	rules := make([]map[string]interface{}, 0, len(compiled))
	for _, rule := range compiled {
		rules = append(rules, subRouteRule(rule.matchKey, rule.values, rule.outTag))
	}
	return rules, sets, nil
}

func buildTransparentProxySubscriptionRules(
	sub *Subscription,
	groupTags map[string]string,
) ([]map[string]interface{}, []map[string]interface{}, error) {
	compiled, sets, err := collectSubscriptionRules(sub, groupTags)
	if err != nil {
		return nil, nil, err
	}
	var rules []map[string]interface{}
	for _, rule := range compiled {
		route := subRouteRule(rule.matchKey, rule.values, rule.outTag)
		if rule.domain {
			// 域名拦截不需要解析；其余目标先从目标订阅组/Line 的出口视角解析。
			if rule.outTag != rejectTag {
				rules = append(rules, map[string]interface{}{
					rule.matchKey: rule.values,
					"action":      "resolve",
					"server":      transparentProxyResolverForOutbound(rule.outTag),
				})
			}
			rules = append(rules, route)
			continue
		}
		rules = append(rules, transparentProxySystemResolveRule(), route)
	}
	return rules, sets, nil
}

func transparentProxyResolverForOutbound(outTag string) string {
	if outTag == "direct" {
		return TransparentNativeDNSTag
	}
	return desktopProxyDNSTag(outTag)
}

// subRouteRule 组装单条订阅 route rule。outTag 为拦截哨兵时生成 action:reject
// （sing-box 1.11+ 的现代拦截做法），否则生成常规 outbound 引用。
func subRouteRule(matchKey string, values interface{}, outTag string) map[string]interface{} {
	rule := map[string]interface{}{matchKey: values}
	if outTag == rejectTag {
		rule["action"] = "reject"
	} else {
		rule["outbound"] = outTag
	}
	return rule
}

func slugify(s string) string {
	// 简单 slug：取前 16 字符，替换非字母数字为 -
	r := strings.Map(func(c rune) rune {
		if (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9') {
			return c
		}
		return '-'
	}, s)
	if len(r) > 16 {
		r = r[:16]
	}
	return strings.ToLower(r)
}

func applyTransport(ob map[string]interface{}, line *Line) {
	if line.TFO {
		ob["tcp_fast_open"] = true
	}
	if line.UDP {
		ob["udp_over_tcp"] = true
	}
}

func validAnyTLSOptions(line *Line) bool {
	if (line.AnyTLSIdleSessionCheckInterval != 0 &&
		(line.AnyTLSIdleSessionCheckInterval < minAnyTLSDurationSeconds ||
			line.AnyTLSIdleSessionCheckInterval > maxAnyTLSDurationSeconds)) ||
		(line.AnyTLSIdleSessionTimeout != 0 &&
			(line.AnyTLSIdleSessionTimeout < minAnyTLSDurationSeconds ||
				line.AnyTLSIdleSessionTimeout > maxAnyTLSDurationSeconds)) ||
		line.AnyTLSMinIdleSession < 0 ||
		line.AnyTLSMinIdleSession > maxAnyTLSMinIdleSession {
		return false
	}
	if line.AnyTLSClientFingerprint != "" {
		if _, exists := anyTLSClientFingerprints[line.AnyTLSClientFingerprint]; !exists {
			return false
		}
	}
	if len(line.AnyTLSALPN) > maxAnyTLSALPNProtocols {
		return false
	}
	seenALPN := make(map[string]struct{}, len(line.AnyTLSALPN))
	for _, protocol := range line.AnyTLSALPN {
		if protocol == "" ||
			len(protocol) > maxAnyTLSALPNProtocolBytes ||
			!utf8.ValidString(protocol) ||
			strings.IndexFunc(protocol, unicode.IsControl) >= 0 {
			return false
		}
		if _, duplicate := seenALPN[protocol]; duplicate {
			return false
		}
		seenALPN[protocol] = struct{}{}
	}
	return true
}

// configureTransparentProxyEndpointBootstrap isolates proxy endpoint lookup from
// user-traffic DNS ownership. Only concrete proxy outbounds generated from the
// active Scenario are present here; selectors and infrastructure outbounds have no
// server field and must never acquire this resolver implicitly.
func configureTransparentProxyEndpointBootstrap(outbounds []map[string]interface{}) bool {
	needed := false
	for _, outbound := range outbounds {
		outboundType, _ := outbound["type"].(string)
		switch outboundType {
		case "trojan", "shadowsocks", "vmess", "anytls":
		default:
			continue
		}
		server, _ := outbound["server"].(string)
		server = strings.TrimSpace(server)
		if server == "" {
			continue
		}
		if _, err := netip.ParseAddr(server); err == nil {
			continue
		}
		outbound["domain_resolver"] = desktopPublicDNSTag
		needed = true
	}
	return needed
}

func buildProxyOutbound(line *Line) map[string]interface{} {
	return nativeOutboundWithEdits(line, buildEditableProxyOutbound(line))
}

func buildEditableProxyOutbound(line *Line) map[string]interface{} {
	switch line.Type {
	case LineTypeSelector, LineTypeURLTest:
		return groupOutbound(line)
	case LineTypeTrojan:
		if line.TrojanServer == "" || line.TrojanPort <= 0 || line.TrojanPort > 65535 || line.TrojanPassword == "" {
			return nil
		}
		tls := map[string]interface{}{
			"enabled":     true,
			"server_name": line.TrojanSNI,
		}
		// sing-box 用 server_name(SNI) 做证书校验，SNI 与连接地址不同是正常场景，
		// 不该据此关闭校验。仅在用户/订阅显式 opt-in（自签节点）时才跳过。
		if line.AllowInsecure {
			tls["insecure"] = true
		}
		ob := map[string]interface{}{
			"type":        "trojan",
			"tag":         "proxy-" + line.ID,
			"server":      line.TrojanServer,
			"server_port": line.TrojanPort,
			"password":    line.TrojanPassword,
			"tls":         tls,
		}
		applyTransport(ob, line)
		return ob
	case LineTypeShadowsocks:
		if line.SSServer == "" || line.SSPort <= 0 || line.SSPort > 65535 || line.SSMethod == "" || line.SSPass == "" {
			return nil
		}
		ob := map[string]interface{}{
			"type":        "shadowsocks",
			"tag":         "proxy-" + line.ID,
			"server":      line.SSServer,
			"server_port": line.SSPort,
			"method":      line.SSMethod,
			"password":    line.SSPass,
		}
		applyTransport(ob, line)
		return ob
	case LineTypeVMess:
		if line.VMessServer == "" || line.VMessPort <= 0 || line.VMessPort > 65535 {
			return nil
		}
		if _, err := uuid.Parse(line.VMessUUID); err != nil {
			return nil
		}
		ob := map[string]interface{}{
			"type":        "vmess",
			"tag":         "proxy-" + line.ID,
			"server":      line.VMessServer,
			"server_port": line.VMessPort,
			"uuid":        line.VMessUUID,
			"alter_id":    line.VMessAltID,
		}
		applyTransport(ob, line)
		return ob
	case LineTypeAnyTLS:
		// AnyTLS 会在握手期间读取已经建立连接的远端地址，而 TCP Fast Open
		// 返回的是延迟建立连接。sing-box 明确拒绝这个组合；在配置编译阶段就把
		// 线路判为不可用，避免数据面启动时崩溃或才暴露错误。
		if line.TFO ||
			line.AnyTLSServer == "" ||
			line.AnyTLSPort <= 0 ||
			line.AnyTLSPort > 65535 ||
			line.AnyTLSPassword == "" ||
			!validAnyTLSOptions(line) {
			return nil
		}
		serverName := line.AnyTLSSNI
		if serverName == "" {
			serverName = line.AnyTLSServer
		}
		tls := map[string]interface{}{
			"enabled":     true,
			"server_name": serverName,
		}
		if line.AllowInsecure {
			tls["insecure"] = true
		}
		if len(line.AnyTLSALPN) > 0 {
			tls["alpn"] = line.AnyTLSALPN
		}
		if line.AnyTLSClientFingerprint != "" {
			tls["utls"] = map[string]interface{}{
				"enabled":     true,
				"fingerprint": line.AnyTLSClientFingerprint,
			}
		}
		ob := map[string]interface{}{
			"type":        "anytls",
			"tag":         "proxy-" + line.ID,
			"server":      line.AnyTLSServer,
			"server_port": line.AnyTLSPort,
			"password":    line.AnyTLSPassword,
			"tls":         tls,
		}
		if line.AnyTLSIdleSessionCheckInterval > 0 {
			ob["idle_session_check_interval"] = fmt.Sprintf(
				"%ds",
				line.AnyTLSIdleSessionCheckInterval,
			)
		}
		if line.AnyTLSIdleSessionTimeout > 0 {
			ob["idle_session_timeout"] = fmt.Sprintf("%ds", line.AnyTLSIdleSessionTimeout)
		}
		if line.AnyTLSMinIdleSession > 0 {
			ob["min_idle_session"] = line.AnyTLSMinIdleSession
		}
		// AnyTLS 原生用 UoT 承载 UDP；不能套用通用 udp_over_tcp 字段。
		return ob
	}
	return nil
}
