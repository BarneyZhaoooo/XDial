package config

import (
	"encoding/json"
	"net/netip"
	"reflect"
	"strings"
	"testing"
)

func TestTransparentProxyDNSRejectsMissingOrInvalidSystemSnapshot(t *testing.T) {
	profile := &Profile{
		Lines:            []Line{{ID: "direct", Type: LineTypeDirect, Enabled: true}},
		Scenarios:        []Scenario{{ID: "scenario", DefaultLineID: "direct"}},
		ActiveScenarioID: "scenario",
	}
	tests := []struct {
		name      string
		systemDNS []string
	}{
		{name: "missing"},
		{name: "empty", systemDNS: []string{}},
		{name: "not an address", systemDNS: []string{"resolver.example"}},
		{name: "unspecified IPv4", systemDNS: []string{"0.0.0.0"}},
		{name: "unspecified IPv6", systemDNS: []string{"::"}},
		{name: "multicast", systemDNS: []string{"224.0.0.251"}},
	}
	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			_, err := GenerateSingBoxTransparentProxy(
				profile,
				29876,
				"session-user",
				"session-password",
				t.TempDir(),
				"utun-underlay",
				test.systemDNS,
			)
			if err == nil || !strings.Contains(err.Error(), "system DNS snapshot") {
				t.Fatalf("system DNS snapshot %v was accepted: %v", test.systemDNS, err)
			}
		})
	}
}

func TestTransparentProxyDirectDomainsUseMacOSNativeResolver(t *testing.T) {
	profile := &Profile{
		Lines: []Line{{ID: "direct", Type: LineTypeDirect, Enabled: true}},
		RuleSets: []RuleSet{{
			ID: "public-direct", Type: RuleSetTypeManual, Enabled: true,
			Domains: []string{"service.example"},
		}},
		Scenarios: []Scenario{{
			ID: "scenario",
			Bindings: []RuleBinding{{
				RuleSetID: "public-direct", LineID: "direct",
			}},
			DefaultLineID: "direct",
		}},
		ActiveScenarioID: "scenario",
	}

	cfg, raw := generateTransparentProxyDNSTestConfig(t, profile)
	native := transparentProxyDNSServerByTag(
		t, cfg, TransparentNativeDNSTag,
	)
	if native["type"] != "local" ||
		native["xdial_use_system_resolver"] != true {
		t.Fatalf("Direct resolver does not use macOS native resolution: %v", native)
	}
	for _, forbidden := range []string{"server", "server_port", "detour"} {
		if _, exists := native[forbidden]; exists {
			t.Fatalf("native Direct resolver contains %s: %v", forbidden, native)
		}
	}
	if cfg.DNS["final"] != TransparentNativeDNSTag {
		t.Fatalf("Direct default lost native resolver ownership: %v", cfg.DNS)
	}
	assertTransparentProxyRules(t, transparentProxyUserRules(t, cfg), []string{
		`{"action":"resolve","domain_suffix":["service.example"],"server":"xdial-native-dns"}`,
		`{"domain_suffix":["service.example"],"outbound":"direct"}`,
		`{"action":"resolve","server":"xdial-native-dns"}`,
	})
	singboxCheckConfig(t, raw, "transparent-direct-native-dns")
}

func TestTransparentProxyUnavailableDirectIPv6NarrowsOnlyDirectResolution(t *testing.T) {
	profile := &Profile{
		Lines: []Line{
			{ID: "direct", Type: LineTypeDirect, Enabled: true},
			{
				ID:             "proxy",
				Type:           LineTypeAnyTLS,
				Enabled:        true,
				AnyTLSServer:   "192.0.2.10",
				AnyTLSPort:     443,
				AnyTLSPassword: "secret",
			},
		},
		RuleSets: []RuleSet{{
			ID: "proxied", Type: RuleSetTypeManual, Enabled: true,
			Domains: []string{"proxied.example"},
		}},
		Scenarios: []Scenario{{
			ID: "scenario",
			Bindings: []RuleBinding{{
				RuleSetID: "proxied", LineID: "proxy",
			}},
			DefaultLineID: "direct",
		}},
		ActiveScenarioID: "scenario",
	}

	raw, err := GenerateSingBoxTransparentProxyWithCapabilities(
		profile,
		29876,
		"session-user",
		"session-password",
		t.TempDir(),
		"utun-underlay",
		[]string{"100.100.100.100"},
		false,
	)
	if err != nil {
		t.Fatal(err)
	}
	var cfg SingBoxConfig
	if err := json.Unmarshal(raw, &cfg); err != nil {
		t.Fatal(err)
	}

	directResolver, ok := transparentProxyOutboundByTag(
		t, cfg, "direct",
	)["domain_resolver"].(map[string]interface{})
	if !ok || directResolver["server"] != TransparentNativeDNSTag ||
		directResolver["strategy"] != "ipv4_only" {
		t.Fatalf("Direct outbound did not inherit IPv4-only capability: %v", directResolver)
	}
	if len(cfg.Inbounds) != 1 {
		t.Fatalf("unexpected transparent proxy inbound count: %v", cfg.Inbounds)
	}
	if cfg.Inbounds[0]["xdial_reresolve_ipv4_flow_domains"] != nil ||
		cfg.Inbounds[0]["xdial_reresolve_ipv6_flow_domains"] != nil {
		t.Fatalf("Direct capability leaked into the shared ingress: %v", cfg.Inbounds)
	}

	proxyResolverTag := desktopProxyDNSTag("proxy-proxy")
	var sawDirectDNS, sawProxyDNS bool
	for _, rawRule := range cfg.DNS["rules"].([]interface{}) {
		rule := rawRule.(map[string]interface{})
		switch rule["server"] {
		case TransparentNativeDNSTag:
			sawDirectDNS = true
			if rule["strategy"] != "ipv4_only" {
				t.Fatalf("Direct DNS rule did not suppress unusable AAAA: %v", rule)
			}
		case proxyResolverTag:
			sawProxyDNS = true
			if _, exists := rule["strategy"]; exists {
				t.Fatalf("proxy-owned DNS inherited Direct capability: %v", rule)
			}
		}
	}
	if !sawDirectDNS || !sawProxyDNS {
		t.Fatalf("missing resolver ownership rules: %v", cfg.DNS["rules"])
	}

	routeRules := transparentProxyUserRules(t, cfg)
	var sawDirectResolve, sawProxyResolve bool
	for _, rawRule := range routeRules {
		rule := rawRule.(map[string]interface{})
		guardedServer, _ := rule["server"].(string)
		if rule["action"] != "resolve" {
			continue
		}
		switch guardedServer {
		case TransparentNativeDNSTag:
			sawDirectResolve = true
			if rule["strategy"] != "ipv4_only" {
				t.Fatalf("Direct route resolve did not use IPv4-only: %v", rule)
			}
		case proxyResolverTag:
			sawProxyResolve = true
			if _, exists := rule["strategy"]; exists {
				t.Fatalf("proxy route resolve inherited Direct capability: %v", rule)
			}
		}
	}
	if !sawDirectResolve || !sawProxyResolve {
		t.Fatalf("missing route resolution ownership: %v", routeRules)
	}
	singboxCheckConfig(t, raw, "transparent-direct-ipv4-only")
}

func TestTransparentProxyDomainEndpointUsesIsolatedBootstrapResolver(t *testing.T) {
	profile := &Profile{
		Lines: []Line{
			{ID: "direct", Type: LineTypeDirect, Enabled: true},
			{
				ID:             "taiwan",
				Type:           LineTypeAnyTLS,
				Enabled:        true,
				AnyTLSServer:   "node.example.com",
				AnyTLSPort:     3489,
				AnyTLSPassword: "secret",
				AnyTLSSNI:      "cover.example.com",
			},
		},
		Scenarios:        []Scenario{{ID: "scenario", DefaultLineID: "taiwan"}},
		ActiveScenarioID: "scenario",
	}

	cfg, _ := generateTransparentProxyDNSTestConfig(t, profile)
	outbound := transparentProxyOutboundByTag(t, cfg, "proxy-taiwan")
	if outbound["domain_resolver"] != desktopPublicDNSTag {
		t.Fatalf("domain proxy endpoint did not use the bootstrap resolver: %v", outbound)
	}

	bootstrap := transparentProxyDNSServerByTag(t, cfg, desktopPublicDNSTag)
	if bootstrap["type"] != "https" || bootstrap["server"] != "223.5.5.5" {
		t.Fatalf("unexpected proxy endpoint bootstrap resolver: %v", bootstrap)
	}
	if _, err := netip.ParseAddr(bootstrap["server"].(string)); err != nil {
		t.Fatalf("bootstrap resolver must not require another DNS lookup: %v", bootstrap)
	}
	if _, exists := bootstrap["detour"]; exists {
		t.Fatalf("bootstrap resolver must not detour through the proxy it starts: %v", bootstrap)
	}

	lineResolver := desktopProxyDNSTag("proxy-taiwan")
	if cfg.Route["default_domain_resolver"] != transparentSystemDNSTag {
		t.Fatalf("proxy endpoint bootstrap changed the Underlay resolver: %v", cfg.Route)
	}
	if cfg.DNS["final"] != lineResolver {
		t.Fatalf("Scenario default Line lost user-traffic DNS ownership: %v", cfg.DNS)
	}
	assertTransparentProxyRules(t, transparentProxyUserRules(t, cfg), []string{
		`{"action":"resolve","server":"` + lineResolver + `","xdial_correct_flow_address":true}`,
	})
}

func TestTransparentProxyEndpointBootstrapOnlyCoversActiveDomainServers(t *testing.T) {
	t.Run("numeric active endpoint", func(t *testing.T) {
		profile := &Profile{
			Lines: []Line{
				{ID: "direct", Type: LineTypeDirect, Enabled: true},
				{
					ID:             "taiwan",
					Type:           LineTypeAnyTLS,
					Enabled:        true,
					AnyTLSServer:   "192.0.2.10",
					AnyTLSPort:     3489,
					AnyTLSPassword: "secret",
					AnyTLSSNI:      "cover.example.com",
				},
			},
			Scenarios:        []Scenario{{ID: "scenario", DefaultLineID: "taiwan"}},
			ActiveScenarioID: "scenario",
		}

		cfg, _ := generateTransparentProxyDNSTestConfig(t, profile)
		outbound := transparentProxyOutboundByTag(t, cfg, "proxy-taiwan")
		if _, exists := outbound["domain_resolver"]; exists {
			t.Fatalf("numeric endpoint unexpectedly acquired a resolver: %v", outbound)
		}
		assertTransparentProxyNoDNSServerTag(t, cfg, desktopPublicDNSTag)
	})

	t.Run("unreferenced domain endpoint", func(t *testing.T) {
		profile := &Profile{
			Lines: []Line{
				{ID: "direct", Type: LineTypeDirect, Enabled: true},
				{
					ID:             "unused",
					Type:           LineTypeAnyTLS,
					Enabled:        true,
					AnyTLSServer:   "unused.example.com",
					AnyTLSPort:     3489,
					AnyTLSPassword: "secret",
				},
			},
			Scenarios:        []Scenario{{ID: "scenario", DefaultLineID: "direct"}},
			ActiveScenarioID: "scenario",
		}

		cfg, _ := generateTransparentProxyDNSTestConfig(t, profile)
		for _, outbound := range cfg.Outbounds {
			if outbound["tag"] == "proxy-unused" {
				t.Fatalf("unreferenced Line leaked into active outbounds: %v", outbound)
			}
		}
		assertTransparentProxyNoDNSServerTag(t, cfg, desktopPublicDNSTag)
	})
}

func TestTransparentProxySubscriptionNodeDomainEndpointsUseBootstrapResolver(t *testing.T) {
	profile := &Profile{
		Lines: []Line{{ID: "direct", Type: LineTypeDirect, Enabled: true}},
		RuleSets: []RuleSet{{
			ID:      "stream",
			Type:    RuleSetTypeManual,
			Enabled: true,
			Domains: []string{"video.example"},
		}},
		Subscriptions: []Subscription{{
			ID:       "sub",
			Enabled:  true,
			Strategy: "selector",
			Lines: []Line{
				{
					ID:             "domain-node",
					Name:           "Domain node",
					Type:           LineTypeAnyTLS,
					Enabled:        true,
					AnyTLSServer:   "node.example.com",
					AnyTLSPort:     3489,
					AnyTLSPassword: "secret",
				},
				{
					ID:             "ip-node",
					Name:           "IP node",
					Type:           LineTypeAnyTLS,
					Enabled:        true,
					AnyTLSServer:   "192.0.2.20",
					AnyTLSPort:     3489,
					AnyTLSPassword: "secret",
				},
			},
		}},
		Scenarios: []Scenario{{
			ID: "scenario",
			Bindings: []RuleBinding{{
				RuleSetID:      "stream",
				SubscriptionID: "sub",
			}},
			DefaultLineID: "direct",
		}},
		ActiveScenarioID: "scenario",
	}

	cfg, _ := generateTransparentProxyDNSTestConfig(t, profile)
	domainNode := transparentProxyOutboundByTag(t, cfg, "proxy-sub-domain-node")
	if domainNode["domain_resolver"] != desktopPublicDNSTag {
		t.Fatalf("subscription domain endpoint did not use bootstrap resolver: %v", domainNode)
	}
	ipNode := transparentProxyOutboundByTag(t, cfg, "proxy-sub-ip-node")
	if _, exists := ipNode["domain_resolver"]; exists {
		t.Fatalf("subscription numeric endpoint unexpectedly acquired a resolver: %v", ipNode)
	}
	transparentProxyDNSServerByTag(t, cfg, desktopPublicDNSTag)
}

func TestTransparentProxyDNSCompilesManualDomainThenCIDRInCausalOrder(t *testing.T) {
	profile := &Profile{
		Lines: []Line{
			{ID: "direct", Type: LineTypeDirect, Enabled: true},
			{ID: "company", Type: LineTypeVPN, Enabled: true},
		},
		RuleSets: []RuleSet{{
			ID:      "company",
			Type:    RuleSetTypeManual,
			Enabled: true,
			Domains: []string{"corp.example"},
			CIDRs:   []string{"10.0.0.0/8"},
		}},
		Scenarios: []Scenario{{
			ID: "scenario",
			Bindings: []RuleBinding{{
				RuleSetID: "company",
				LineID:    "company",
			}},
			DefaultLineID: "direct",
		}},
		ActiveScenarioID: "scenario",
	}

	cfg, raw := generateTransparentProxyDNSTestConfig(t, profile)
	rules := transparentProxyUserRules(t, cfg)
	assertTransparentProxyRules(t, rules, []string{
		`{"action":"resolve","domain_suffix":["corp.example"],"server":"xdial-anyconnect-dns","xdial_correct_flow_address":true}`,
		`{"domain_suffix":["corp.example"],"outbound":"vpn"}`,
		`{"action":"resolve","server":"xdial-system-dns"}`,
		`{"ip_cidr":["10.0.0.0/8"],"outbound":"vpn"}`,
		`{"action":"resolve","server":"xdial-native-dns"}`,
	})

	servers := cfg.DNS["servers"].([]interface{})
	if len(servers) != 3 {
		t.Fatalf("unexpected DNS servers: %v", servers)
	}
	system := transparentProxyDNSServerByTag(t, cfg, transparentSystemDNSTag)
	native := transparentProxyDNSServerByTag(t, cfg, TransparentNativeDNSTag)
	enterprise := transparentProxyDNSServerByTag(t, cfg, transparentEnterpriseDNSTag)
	if system["tag"] != transparentSystemDNSTag ||
		system["server"] != "100.100.100.100" ||
		native["type"] != "local" ||
		native["xdial_use_system_resolver"] != true ||
		enterprise["type"] != "xdial-anyconnect" ||
		enterprise["tag"] != transparentEnterpriseDNSTag {
		t.Fatalf("manual domain resolvers do not match their routes: %v", servers)
	}
	assertTransparentProxyHasNoMobileDNSFallback(t, raw)
}

func TestTransparentProxyDNSClassifiesURLRulesAndPreservesBindingOrder(t *testing.T) {
	profile := &Profile{
		Lines: []Line{
			{ID: "direct", Type: LineTypeDirect, Enabled: true},
			{
				ID:             "japan",
				Type:           LineTypeTrojan,
				Enabled:        true,
				TrojanServer:   "192.0.2.10",
				TrojanPort:     443,
				TrojanPassword: "secret",
				TrojanSNI:      "proxy.example",
			},
		},
		RuleSets: []RuleSet{
			{
				ID: "domain", Type: RuleSetTypeURL, Enabled: true,
				URL: "file:///tmp/domain.srs", Format: "binary",
				RuntimeMatchKind: RuleSetMatchDomain,
			},
			{
				ID: "ip", Type: RuleSetTypeURL, Enabled: true,
				URL: "file:///tmp/ip.srs", Format: "binary",
				RuntimeMatchKind: RuleSetMatchIP,
			},
			{
				ID: "mixed", Type: RuleSetTypeURL, Enabled: true,
				URL: "file:///tmp/mixed.srs", Format: "binary",
				RuntimeMatchKind: RuleSetMatchMixed,
			},
		},
		Scenarios: []Scenario{{
			ID: "scenario",
			// 故意与 RuleSets 声明顺序不同，锁定唯一合法顺序来源是 Scenario bindings。
			Bindings: []RuleBinding{
				{RuleSetID: "mixed", LineID: "japan"},
				{RuleSetID: "domain", LineID: "japan"},
				{RuleSetID: "ip", LineID: "japan"},
			},
			DefaultLineID: "direct",
		}},
		ActiveScenarioID: "scenario",
	}

	cfg, raw := generateTransparentProxyDNSTestConfig(t, profile)
	rules := transparentProxyUserRules(t, cfg)
	assertTransparentProxyRules(t, rules, []string{
		`{"action":"resolve","server":"xdial-system-dns"}`,
		`{"outbound":"proxy-japan","rule_set":"ruleset-mixed"}`,
		`{"action":"resolve","rule_set":"ruleset-domain","server":"proxy-dns-proxy-japan","xdial_correct_flow_address":true}`,
		`{"outbound":"proxy-japan","rule_set":"ruleset-domain"}`,
		`{"action":"resolve","server":"xdial-system-dns"}`,
		`{"outbound":"proxy-japan","rule_set":"ruleset-ip"}`,
		`{"action":"resolve","server":"xdial-native-dns"}`,
	})

	dnsRules, ok := cfg.DNS["rules"].([]interface{})
	if !ok || len(dnsRules) != 1 {
		t.Fatalf("IP and mixed rules must not swallow later domain DNS ownership: %v", cfg.DNS["rules"])
	}
	domainDNS := dnsRules[0].(map[string]interface{})
	if domainDNS["rule_set"] != "ruleset-domain" ||
		domainDNS["server"] != "proxy-dns-proxy-japan" {
		t.Fatalf("later domain DNS ownership drifted from Scenario: %v", domainDNS)
	}

	servers := cfg.DNS["servers"].([]interface{})
	if len(servers) != 3 {
		t.Fatalf("route-time domain resolution is missing its Line resolver: %v", servers)
	}
	lineResolver := transparentProxyDNSServerByTag(t, cfg, "proxy-dns-proxy-japan")
	if lineResolver["tag"] != "proxy-dns-proxy-japan" ||
		lineResolver["type"] != "https" ||
		lineResolver["detour"] != "proxy-japan" {
		t.Fatalf("pure-domain URL rule did not resolve through its target Line: %v", lineResolver)
	}
	if cfg.DNS["final"] != TransparentNativeDNSTag {
		t.Fatalf("the Direct default must use macOS native DNS: %v", cfg.DNS)
	}
	assertTransparentProxyHasNoMobileDNSFallback(t, raw)
}

func TestTransparentProxyMixedBindingDoesNotSwallowLaterDirectDomainDNS(t *testing.T) {
	profile := &Profile{
		Lines: []Line{
			{ID: "direct", Type: LineTypeDirect, Enabled: true},
			{
				ID: "proxy", Type: LineTypeTrojan, Enabled: true,
				TrojanServer: "192.0.2.10", TrojanPort: 443,
				TrojanPassword: "secret", TrojanSNI: "proxy.example",
			},
		},
		RuleSets: []RuleSet{
			{
				ID: "internal", Type: RuleSetTypeManual, Enabled: true,
				Domains: []string{"corp.example"}, CIDRs: []string{"10.0.0.0/8"},
			},
			{
				ID: "domestic", Type: RuleSetTypeURL, Enabled: true,
				URL: "file:///tmp/domestic.srs", Format: "binary",
				RuntimeMatchKind: RuleSetMatchDomain,
			},
		},
		Scenarios: []Scenario{{
			ID: "scenario",
			Bindings: []RuleBinding{
				{RuleSetID: "internal", LineID: "proxy"},
				{RuleSetID: "domestic", LineID: "direct"},
			},
			DefaultLineID: "proxy",
		}},
		ActiveScenarioID: "scenario",
	}

	cfg, _ := generateTransparentProxyDNSTestConfig(t, profile)
	assertTransparentProxyRules(t, cfg.DNS["rules"].([]interface{}), []string{
		`{"domain_suffix":["corp.example"],"server":"proxy-dns-proxy-proxy"}`,
		`{"rule_set":"ruleset-domestic","server":"xdial-native-dns"}`,
	})
	if cfg.DNS["final"] != "proxy-dns-proxy-proxy" {
		t.Fatalf("default proxy DNS changed: %v", cfg.DNS)
	}
}

func TestTransparentProxyDefaultLineOwnsFinalResolution(t *testing.T) {
	profile := &Profile{
		Lines: []Line{
			{ID: "direct", Type: LineTypeDirect, Enabled: true},
			{
				ID:                "tailnet",
				Type:              LineTypeTailscale,
				Enabled:           true,
				TailscaleExitNode: "100.118.7.9",
			},
		},
		RuleSets: []RuleSet{{
			ID:               "cnip",
			Type:             RuleSetTypeURL,
			Enabled:          true,
			URL:              "file:///tmp/cnip.srs",
			Format:           "binary",
			RuntimeMatchKind: RuleSetMatchIP,
		}},
		Scenarios: []Scenario{{
			ID: "scenario",
			Bindings: []RuleBinding{{
				RuleSetID: "cnip",
				LineID:    "direct",
			}},
			DefaultLineID: "tailnet",
		}},
		ActiveScenarioID: "scenario",
	}

	cfg, raw := generateTransparentProxyDNSTestConfig(t, profile)
	defaultResolver := desktopProxyDNSTag("tailscale-tailnet")
	if cfg.DNS["final"] != defaultResolver {
		t.Fatalf("default Line does not own DNS final: %v", cfg.DNS)
	}

	var foundDefaultResolver bool
	for _, rawServer := range cfg.DNS["servers"].([]interface{}) {
		server := rawServer.(map[string]interface{})
		if server["tag"] != defaultResolver {
			continue
		}
		foundDefaultResolver = true
		if server["type"] != "https" ||
			server["server"] != "1.1.1.1" ||
			server["detour"] != "tailscale-tailnet" {
			t.Fatalf("unexpected default Line resolver: %v", server)
		}
	}
	if !foundDefaultResolver {
		t.Fatalf("default Line resolver is missing: %v", cfg.DNS["servers"])
	}

	assertTransparentProxyRules(t, transparentProxyUserRules(t, cfg), []string{
		`{"action":"resolve","server":"xdial-system-dns"}`,
		`{"outbound":"direct","rule_set":"ruleset-cnip"}`,
		`{"action":"resolve","server":"proxy-dns-tailscale-tailnet","xdial_correct_flow_address":true}`,
	})
	assertTransparentProxyHasNoMobileDNSFallback(t, raw)
}

func TestTransparentProxyMagicDNSToggleCompilesDynamicDNSAndPeerRoutes(t *testing.T) {
	profile := &Profile{
		Lines: []Line{
			{ID: "direct", Type: LineTypeDirect, Enabled: true},
			{
				ID: "tailnet", Type: LineTypeTailscale, Enabled: true,
				TailscaleExitNode: "100.118.7.9", TailscaleMagicDNS: true,
			},
		},
		RuleSets: []RuleSet{
			{
				ID: "ip-first", Name: "IP First", Type: RuleSetTypeManual,
				Enabled: true, CIDRs: []string{"203.0.113.0/24"},
			},
			{
				ID: "cdn", Name: "CDN", Type: RuleSetTypeManual,
				Enabled: true, Domains: []string{"cdn.example.com"},
			},
		},
		Scenarios: []Scenario{{
			ID: "scenario",
			Bindings: []RuleBinding{
				{RuleSetID: "cdn", LineID: "direct"},
				{RuleSetID: "ip-first", LineID: "direct"},
			},
			DefaultLineID: "tailnet",
		}},
		ActiveScenarioID: "scenario",
	}

	profile.Lines[1].TailscaleMagicDNS = false
	withoutMagicDNS, _ := generateTransparentProxyDNSTestConfig(t, profile)
	profile.Lines[1].TailscaleMagicDNS = true
	cfg, raw := generateTransparentProxyDNSTestConfig(t, profile)
	resolverTag := TailscaleMagicDNSDNSServerTag("tailscale-tailnet")
	assertTransparentProxyRules(t, transparentProxyUserRules(t, cfg), []string{
		`{"action":"resolve","domain_suffix":["cdn.example.com"],"server":"xdial-native-dns"}`,
		`{"domain_suffix":["cdn.example.com"],"outbound":"direct"}`,
		`{"action":"resolve","server":"xdial-system-dns"}`,
		`{"ip_cidr":["203.0.113.0/24"],"outbound":"direct"}`,
		`{"action":"resolve","disable_cache":true,"preferred_by":"` + resolverTag + `","server":"` + resolverTag + `"}`,
		`{"outbound":"tailscale-tailnet","preferred_by":"tailscale-tailnet"}`,
		`{"action":"resolve","server":"proxy-dns-tailscale-tailnet","xdial_correct_flow_address":true}`,
	})

	servers := cfg.DNS["servers"].([]interface{})
	if len(servers) != 4 {
		t.Fatalf("expected system, Tailscale, and default-Line DNS servers, got %v", servers)
	}
	for _, rawServer := range servers {
		server := rawServer.(map[string]interface{})
		if server["type"] == "tailscale" {
			t.Fatalf("MagicDNS must not instantiate the inline Tailscale DNS service: %v", server)
		}
	}
	tailnetDNS := transparentProxyDNSServerByTag(t, cfg, resolverTag)
	if tailnetDNS["type"] != "hosts" ||
		tailnetDNS["tag"] != resolverTag ||
		tailnetDNS["memory_only"] != true {
		t.Fatalf("unexpected in-memory Tailnet hosts server: %v", tailnetDNS)
	}
	if _, exists := tailnetDNS["path"]; exists {
		t.Fatalf("in-memory Tailnet hosts server must not read files: %v", tailnetDNS)
	}
	if predefined, ok := tailnetDNS["predefined"].(map[string]interface{}); !ok || len(predefined) != 0 {
		t.Fatalf("generated Tailnet hosts snapshot must start empty: %v", tailnetDNS)
	}
	dnsRules := cfg.DNS["rules"].([]interface{})
	if len(dnsRules) != 2 {
		t.Fatalf("expected highest-priority MagicDNS followed by explicit CDN DNS, got %v", dnsRules)
	}
	first := dnsRules[0].(map[string]interface{})
	second := dnsRules[1].(map[string]interface{})
	if first["preferred_by"] != resolverTag || first["server"] != resolverTag || first["disable_cache"] != true {
		t.Fatalf("MagicDNS ownership must be first, dynamic, and uncached: %v", first)
	}
	if second["server"] != TransparentNativeDNSTag ||
		!reflect.DeepEqual(second["domain_suffix"], []interface{}{"cdn.example.com"}) {
		t.Fatalf("ordinary Scenario DNS ownership must follow MagicDNS: %v", dnsRules)
	}
	ordinaryDNS := func(source SingBoxConfig) map[string]interface{} {
		servers := make([]interface{}, 0)
		for _, rawServer := range source.DNS["servers"].([]interface{}) {
			server := rawServer.(map[string]interface{})
			if server["tag"] != resolverTag {
				servers = append(servers, server)
			}
		}
		rules := make([]interface{}, 0)
		for _, rawRule := range source.DNS["rules"].([]interface{}) {
			rule := rawRule.(map[string]interface{})
			if rule["preferred_by"] != resolverTag {
				rules = append(rules, rule)
			}
		}
		return map[string]interface{}{
			"servers":           servers,
			"rules":             rules,
			"final":             source.DNS["final"],
			"independent_cache": source.DNS["independent_cache"],
		}
	}
	if before, after := ordinaryDNS(withoutMagicDNS), ordinaryDNS(cfg); !reflect.DeepEqual(before, after) {
		t.Fatalf("enabling MagicDNS changed unrelated DNS behavior:\n--- before ---\n%v\n--- after ---\n%v", before, after)
	}
	for _, forbidden := range []string{"100.64.0.0/10", "fd7a:115c:a1e0::/48"} {
		if strings.Contains(string(raw), forbidden) {
			t.Fatalf("MagicDNS must not hard-code Tailnet ranges (%s):\n%s", forbidden, raw)
		}
	}
}

func TestTransparentProxyInvertedURLIPRuleKeepsSystemResolutionAndInvertsRoute(t *testing.T) {
	profile := &Profile{
		Lines: []Line{
			{ID: "direct", Type: LineTypeDirect, Enabled: true},
			{
				ID:             "japan",
				Type:           LineTypeTrojan,
				Enabled:        true,
				TrojanServer:   "192.0.2.10",
				TrojanPort:     443,
				TrojanPassword: "secret",
				TrojanSNI:      "proxy.example",
			},
		},
		RuleSets: []RuleSet{{
			ID:               "outside-cn",
			Type:             RuleSetTypeURL,
			Enabled:          true,
			URL:              "file:///tmp/cn.srs",
			Format:           "binary",
			Invert:           true,
			RuntimeMatchKind: RuleSetMatchIP,
		}},
		Scenarios: []Scenario{{
			ID: "scenario",
			Bindings: []RuleBinding{{
				RuleSetID: "outside-cn",
				LineID:    "japan",
			}},
			DefaultLineID: "direct",
		}},
		ActiveScenarioID: "scenario",
	}

	cfg, _ := generateTransparentProxyDNSTestConfig(t, profile)
	assertTransparentProxyRules(t, transparentProxyUserRules(t, cfg), []string{
		`{"action":"resolve","server":"xdial-system-dns"}`,
		`{"invert":true,"outbound":"proxy-japan","rule_set":"ruleset-outside-cn"}`,
		`{"action":"resolve","server":"xdial-native-dns"}`,
	})
}

func TestTransparentProxyInvertedManualDomainRuleInvertsDNSAndRouteTogether(t *testing.T) {
	profile := &Profile{
		Lines: []Line{
			{ID: "direct", Type: LineTypeDirect, Enabled: true},
			{
				ID:             "japan",
				Type:           LineTypeTrojan,
				Enabled:        true,
				TrojanServer:   "192.0.2.10",
				TrojanPort:     443,
				TrojanPassword: "secret",
				TrojanSNI:      "proxy.example",
			},
		},
		RuleSets: []RuleSet{{
			ID:      "outside-corp",
			Type:    RuleSetTypeManual,
			Enabled: true,
			Invert:  true,
			Domains: []string{"corp.example"},
		}},
		Scenarios: []Scenario{{
			ID: "scenario",
			Bindings: []RuleBinding{{
				RuleSetID: "outside-corp",
				LineID:    "japan",
			}},
			DefaultLineID: "direct",
		}},
		ActiveScenarioID: "scenario",
	}

	cfg, _ := generateTransparentProxyDNSTestConfig(t, profile)
	assertTransparentProxyRules(t, transparentProxyUserRules(t, cfg), []string{
		`{"action":"resolve","domain_suffix":["corp.example"],"invert":true,"server":"proxy-dns-proxy-japan","xdial_correct_flow_address":true}`,
		`{"domain_suffix":["corp.example"],"invert":true,"outbound":"proxy-japan"}`,
		`{"action":"resolve","server":"xdial-native-dns"}`,
	})

	found := false
	for _, rawRule := range cfg.DNS["rules"].([]interface{}) {
		rule := rawRule.(map[string]interface{})
		if reflect.DeepEqual(rule["domain_suffix"], []interface{}{"corp.example"}) {
			found = true
			if rule["invert"] != true || rule["server"] != "proxy-dns-proxy-japan" {
				t.Fatalf("inverted manual DNS rule drifted from route: %v", rule)
			}
		}
	}
	if !found {
		t.Fatal("inverted manual domain rule did not compile a DNS rule")
	}
}

func TestTransparentProxyInvertedManualMixedRuleComplementsWholeUnion(t *testing.T) {
	profile := &Profile{
		Lines: []Line{
			{ID: "direct", Type: LineTypeDirect, Enabled: true},
			{
				ID:             "japan",
				Type:           LineTypeTrojan,
				Enabled:        true,
				TrojanServer:   "192.0.2.10",
				TrojanPort:     443,
				TrojanPassword: "secret",
				TrojanSNI:      "proxy.example",
			},
		},
		RuleSets: []RuleSet{{
			ID:      "outside-company",
			Type:    RuleSetTypeManual,
			Enabled: true,
			Invert:  true,
			Domains: []string{"corp.example"},
			CIDRs:   []string{"10.0.0.0/8"},
		}},
		Scenarios: []Scenario{{
			ID: "scenario",
			Bindings: []RuleBinding{{
				RuleSetID: "outside-company",
				LineID:    "japan",
			}},
			DefaultLineID: "direct",
		}},
		ActiveScenarioID: "scenario",
	}

	cfg, raw := generateTransparentProxyDNSTestConfig(t, profile)
	assertTransparentProxyRules(t, transparentProxyUserRules(t, cfg), []string{
		`{"action":"resolve","server":"xdial-system-dns"}`,
		`{"invert":true,"mode":"or","outbound":"proxy-japan","rules":[{"domain_suffix":["corp.example"]},{"ip_cidr":["10.0.0.0/8"]}],"type":"logical"}`,
		`{"action":"resolve","server":"xdial-native-dns"}`,
	})
	singboxCheckConfig(t, raw, "transparent-inverted-manual-mixed")
}

func generateTransparentProxyDNSTestConfig(t *testing.T, profile *Profile) (SingBoxConfig, []byte) {
	t.Helper()
	raw, err := GenerateSingBoxTransparentProxy(
		profile,
		29876,
		"session-user",
		"session-password",
		t.TempDir(),
		"utun-underlay",
		[]string{"100.100.100.100", "172.20.1.1"},
	)
	if err != nil {
		t.Fatal(err)
	}
	var cfg SingBoxConfig
	if err := json.Unmarshal(raw, &cfg); err != nil {
		t.Fatal(err)
	}
	return cfg, raw
}

func transparentProxyOutboundByTag(t *testing.T, cfg SingBoxConfig, tag string) map[string]interface{} {
	t.Helper()
	for _, outbound := range cfg.Outbounds {
		if outbound["tag"] == tag {
			return outbound
		}
	}
	t.Fatalf("outbound %q is missing: %v", tag, cfg.Outbounds)
	return nil
}

func transparentProxyDNSServerByTag(t *testing.T, cfg SingBoxConfig, tag string) map[string]interface{} {
	t.Helper()
	servers, ok := cfg.DNS["servers"].([]interface{})
	if !ok {
		t.Fatalf("invalid DNS servers: %v", cfg.DNS["servers"])
	}
	for _, rawServer := range servers {
		server := rawServer.(map[string]interface{})
		if server["tag"] == tag {
			return server
		}
	}
	t.Fatalf("DNS server %q is missing: %v", tag, servers)
	return nil
}

func assertTransparentProxyNoDNSServerTag(t *testing.T, cfg SingBoxConfig, tag string) {
	t.Helper()
	servers, ok := cfg.DNS["servers"].([]interface{})
	if !ok {
		t.Fatalf("invalid DNS servers: %v", cfg.DNS["servers"])
	}
	for _, rawServer := range servers {
		server := rawServer.(map[string]interface{})
		if server["tag"] == tag {
			t.Fatalf("unexpected DNS server %q: %v", tag, server)
		}
	}
}

func transparentProxyUserRules(t *testing.T, cfg SingBoxConfig) []interface{} {
	t.Helper()
	rules, ok := cfg.Route["rules"].([]interface{})
	if !ok || len(rules) < 2 {
		t.Fatalf("invalid Transparent Proxy route rules: %v", cfg.Route["rules"])
	}
	for index, action := range []string{"sniff", "hijack-dns"} {
		rule, ok := rules[index].(map[string]interface{})
		if !ok || rule["action"] != action {
			t.Fatalf("invalid system route rule %d: %v", index, rules[index])
		}
	}
	return rules[2:]
}

func assertTransparentProxyRules(t *testing.T, got []interface{}, want []string) {
	t.Helper()
	if len(got) != len(want) {
		t.Fatalf("unexpected rule count: got=%d want=%d\nrules=%v", len(got), len(want), got)
	}
	for index := range want {
		encoded, err := json.Marshal(got[index])
		if err != nil {
			t.Fatal(err)
		}
		if string(encoded) != want[index] {
			t.Fatalf("rule %d mismatch:\n got %s\nwant %s", index, encoded, want[index])
		}
	}
}

func assertTransparentProxyHasNoMobileDNSFallback(t *testing.T, raw []byte) {
	t.Helper()
	for _, forbidden := range []string{"xdial-mobile", "public_fallback"} {
		if strings.Contains(string(raw), forbidden) {
			t.Fatalf("Transparent Proxy config contains mobile DNS fallback %q:\n%s", forbidden, raw)
		}
	}
}

// 应用自己的 DNS 可能没经过 XDial（mDNSResponder 旧 querier、应用内置解析、
// 接管前缓存），拿着 Underlay 甚至被篡改的地址来连接。名字已决定的非 Direct
// Line 必须用自己的解析视角核对这个地址；Direct、启动前系统 DNS 与选中
// Direct 的选择器组不核对——应用的答案本来就是它们的视角。
func TestTransparentProxyCorrectsFlowAddressOnlyThroughLineOwnedResolvers(t *testing.T) {
	profile := &Profile{
		Lines: []Line{
			{ID: "direct", Type: LineTypeDirect, Enabled: true},
			{
				ID: "japan", Type: LineTypeTrojan, Enabled: true,
				TrojanServer: "192.0.2.10", TrojanPort: 443,
				TrojanPassword: "secret", TrojanSNI: "node.example",
			},
			{
				ID: "local-policy", Name: "Local", Type: LineTypeSelector, Enabled: true,
				GroupMembers: []string{"direct", "japan"},
			},
		},
		RuleSets: []RuleSet{
			{ID: "overseas", Type: RuleSetTypeManual, Enabled: true, Domains: []string{"chatgpt.com"}},
			{ID: "local-names", Type: RuleSetTypeManual, Enabled: true, Domains: []string{"local.example"}},
			{ID: "nearby", Type: RuleSetTypeManual, Enabled: true, Domains: []string{"cdn.example"}},
			{ID: "office", Type: RuleSetTypeManual, Enabled: true, CIDRs: []string{"198.51.100.0/24"}},
			{
				ID: "codex", Type: RuleSetTypeApplication, Enabled: true,
				Applications: []ApplicationMatch{{Path: "/Applications/Codex.app"}},
			},
			{
				ID: "terminal", Type: RuleSetTypeApplication, Enabled: true,
				Applications: []ApplicationMatch{{Path: "/System/Applications/Utilities/Terminal.app"}},
			},
		},
		Scenarios: []Scenario{{
			ID: "scenario",
			Bindings: []RuleBinding{
				{RuleSetID: "overseas", LineID: "japan"},
				{RuleSetID: "local-names", LineID: "direct"},
				{RuleSetID: "nearby", LineID: "local-policy"},
				{RuleSetID: "office", LineID: "japan"},
				{RuleSetID: "codex", LineID: "japan"},
				{RuleSetID: "terminal", LineID: "direct"},
			},
			DefaultLineID: "japan",
		}},
		ActiveScenarioID: "scenario",
	}

	cfg, raw := generateTransparentProxyDNSTestConfig(t, profile)
	lineResolver := desktopProxyDNSTag("proxy-japan")
	if server := transparentProxyDNSServerByTag(t, cfg, lineResolver); server["detour"] != "proxy-japan" {
		t.Fatalf("Line resolver must leave through its Line: %v", server)
	}

	corrected := map[string]int{}
	uncorrected := map[string]int{}
	applicationResolves := 0
	for _, value := range cfg.Route["rules"].([]interface{}) {
		rule := value.(map[string]interface{})
		if rule["action"] != "resolve" {
			if _, exists := rule[transparentFlowAddressCorrectionKey]; exists {
				t.Fatalf("only resolve actions may correct addresses: %v", rule)
			}
			continue
		}
		server, _ := rule["server"].(string)
		if rule[transparentFlowAddressCorrectionKey] == true {
			corrected[server]++
		} else {
			uncorrected[server]++
		}
		if _, exists := rule["auth_user"]; exists {
			applicationResolves++
		}
	}

	// chatgpt.com 规则、Codex 应用规则与默认 Line 各一条。
	if corrected[lineResolver] != 3 || len(corrected) != 1 {
		t.Fatalf("Line-owned resolves must all correct flow addresses: corrected=%v uncorrected=%v", corrected, uncorrected)
	}
	if uncorrected[lineResolver] != 0 {
		t.Fatalf("a Line-owned resolve was left uncorrected: %v", uncorrected)
	}
	// Direct 域名、IP 规则前的系统解析、选中 Direct 的选择器组都保持原样；
	// Direct 应用规则不生成 resolve。
	if uncorrected[TransparentNativeDNSTag] != 1 ||
		uncorrected[transparentSystemDNSTag] != 1 ||
		uncorrected[desktopProxyDNSTag("proxy-local-policy")] != 1 {
		t.Fatalf("non-Line resolvers must keep the application's address: %v", uncorrected)
	}
	if applicationResolves != 1 {
		t.Fatalf("only the non-Direct application binding may resolve: %d", applicationResolves)
	}
	singboxCheckConfig(t, raw, "transparent-flow-address-correction")
}
