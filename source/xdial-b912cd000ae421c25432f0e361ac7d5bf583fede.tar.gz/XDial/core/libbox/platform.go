package libbox

import (
	stdjson "encoding/json"
	"net"
	"net/netip"
	"runtime"
	"sync"
	"sync/atomic"

	"github.com/sagernet/sing-box/adapter"
	C "github.com/sagernet/sing-box/constant"
	"github.com/sagernet/sing-box/option"
	tun "github.com/sagernet/sing-tun"
	"github.com/sagernet/sing/common/control"
	E "github.com/sagernet/sing/common/exceptions"
	"github.com/sagernet/sing/common/logger"
	"github.com/sagernet/sing/common/x/list"
)

// platform.go 把 XDial 的进程内 sing-box 接到 Apple NetworkExtension 的 packetFlow。
//
// sing-box 通过 ctx 里的 adapter.PlatformInterface 决定 TUN inbound 怎么拿到底层
// 设备:当 UsePlatformInterface() 返回 true 时,它不会自己去 tun.New 打开一个新
// utun,而是回调 OpenInterface,让平台把 NE 已经建立好的 packetFlow 对应的文件
// 描述符交给 sing-box。iOS/tvOS/macOS 扩展进程都复用 NE 给的 fd。
//
// 除 OpenInterface 外，默认接口和全部候选接口也必须来自 NWPath。这里不能把
// utun/ipsec/ppp 一概当成“隧道”删掉：它们可能是 XDial 启动前已经存在的 Underlay。
// 唯一应排除的是当前会话自己创建、由 RegisterMyInterface 明确登记的接口。

// TunOpener 是"打开 TUN 设备"这一步的可替换缝隙。
//
// 默认实现(defaultTunOpener)走真实路径:把 Swift 侧通过 Libbox.SetTunFD 传入的
// NE packetFlow 文件描述符 dup 一份,写进 options.FileDescriptor,再交给 tun.New。
// 之所以要 dup:tun.New/tun 对象拿到 fd 后会在 Close 时关掉它,而原始 fd 的所有权
// 属于 NEPacketTunnelProvider(packetFlow),不能被 sing-box 关掉;dup 出独立 fd 让
// 两边生命周期解耦。
//
// 离线 Go 测试(无 NE、无真实 fd)可以通过 Libbox.SetTunOpener 注入一个 fake:
// 比如返回一个基于 os.Pipe / socketpair 的假 tun.Tun,从而在桌面上跑通
// "sing-box 构建 + 启动 + 经 TUN inbound 收发包"的集成测试。这个 setter 参数是
// 函数类型,gomobile 绑定时会自动跳过它(不影响 tvOS 侧导出面),仅供包外测试代码用。
type TunOpener func(options *tun.Options, platformOptions option.TunPlatformOptions) (tun.Tun, error)

// xdPlatformInterface 是喂给 sing-box 的 adapter.PlatformInterface 精简实现。
// 有意保持 unexported:它的方法签名带 *tun.Options 等复杂类型,gomobile 无法绑定;
// 未导出后 gomobile 直接忽略整个类型,不会因此报错。
type xdPlatformInterface struct {
	// tunFD 是 Swift 侧传入的 NE packetFlow 文件描述符(见 Libbox.SetTunFD)。
	tunFD int
	// opener 是可替换的 TUN 打开器;nil 时用 defaultTunOpener(真实 dup+tun.New)。
	opener TunOpener

	mu                 sync.Mutex
	networkManager     adapter.NetworkManager
	defaultInterface   *control.Interface
	networkInterfaces  []adapter.NetworkInterface
	ownInterfaceName   string
	monitor            *platformInterfaceMonitor
	bindUnderlaySocket bool
	// Linux marked sockets leave destination-specific Underlay choice to the kernel.
	kernelRoutedUnderlay bool
	socketProtector      SocketProtector
	secureStateStore     SecureStateStore
	lineEpoch            string
	lineRevision         uint64
	tunInPackets         atomic.Uint64
	tunInBytes           atomic.Uint64
	tunOutPackets        atomic.Uint64
	tunOutBytes          atomic.Uint64
}

var _ adapter.PlatformInterface = (*xdPlatformInterface)(nil)

// UsePlatformInterface 返回 true,让 sing-box 走 OpenInterface 回调而不是自己开 utun。
func (p *xdPlatformInterface) UsePlatformInterface() bool { return true }

// OpenInterface 是本文件的核心:把 NE 的 fd 交给 sing-box 的 TUN inbound。
func (p *xdPlatformInterface) OpenInterface(options *tun.Options, platformOptions option.TunPlatformOptions) (tun.Tun, error) {
	opener := p.opener
	if opener == nil {
		opener = p.defaultTunOpener
	}
	return opener(options, platformOptions)
}

func (p *xdPlatformInterface) ProcessPlatformOptions(option.TunPlatformOptions) error {
	return nil
}

func (p *xdPlatformInterface) UnderNetworkExtension() bool {
	return runtime.GOOS == "darwin" || runtime.GOOS == "ios"
}

// 默认接口/接口列表用于 direct 与 DNS 出站；其余 Wi-Fi 详情、进程归属、通知等
// 非数据面能力暂不提供，让 sing-box 回退到通用逻辑。

func (p *xdPlatformInterface) Initialize(networkManager adapter.NetworkManager) error {
	p.mu.Lock()
	p.networkManager = networkManager
	p.mu.Unlock()
	return nil
}

func (p *xdPlatformInterface) UsePlatformAutoDetectInterfaceControl() bool {
	p.mu.Lock()
	defer p.mu.Unlock()
	return p.bindUnderlaySocket || p.socketProtector != nil || runtime.GOOS == "android"
}

func (p *xdPlatformInterface) AutoDetectInterfaceControl(fd int) error {
	p.mu.Lock()
	enabled := p.bindUnderlaySocket
	protector := p.socketProtector
	defaultInterface := cloneInterface(p.defaultInterface)
	p.mu.Unlock()
	if protector != nil {
		return protector.ProtectSocket(fd)
	}
	if runtime.GOOS == "android" {
		return E.New("platform: Android socket protector is required")
	}
	if !enabled {
		return nil
	}
	if defaultInterface == nil || defaultInterface.Index <= 0 {
		return E.New("platform: default Underlay interface is unavailable")
	}
	return bindSocketToInterface(fd, defaultInterface.Index)
}

func (p *xdPlatformInterface) UsePlatformDefaultInterfaceMonitor() bool { return true }

// CreateDefaultInterfaceMonitor 必须返回非 nil:NetworkManager 会在返回值上注册
// 回调。monitor 的初始值及后续更新来自 Swift NWPathMonitor。
func (p *xdPlatformInterface) CreateDefaultInterfaceMonitor(logger logger.Logger) tun.DefaultInterfaceMonitor {
	p.mu.Lock()
	defer p.mu.Unlock()
	if p.monitor == nil {
		p.monitor = &platformInterfaceMonitor{platform: p, logger: logger}
	}
	return p.monitor
}

func (p *xdPlatformInterface) UsePlatformNetworkInterfaces() bool { return true }

func (p *xdPlatformInterface) NetworkInterfaces() ([]adapter.NetworkInterface, error) {
	p.mu.Lock()
	defaultInterface := cloneInterface(p.defaultInterface)
	ownInterfaceName := p.ownInterfaceName
	networkInterfaces := append([]adapter.NetworkInterface(nil), p.networkInterfaces...)
	p.mu.Unlock()

	if len(networkInterfaces) > 0 {
		filtered := networkInterfaces[:0]
		for _, networkInterface := range networkInterfaces {
			if networkInterface.Name == ownInterfaceName {
				continue
			}
			filtered = append(filtered, networkInterface)
		}
		return filtered, nil
	}
	if defaultInterface == nil || defaultInterface.Name == ownInterfaceName {
		return nil, nil
	}
	return []adapter.NetworkInterface{{Interface: *defaultInterface}}, nil
}

func (p *xdPlatformInterface) NetworkExtensionIncludeAllNetworks() bool { return false }

func (p *xdPlatformInterface) ClearDNSCache() {}

func (p *xdPlatformInterface) RequestPermissionForWIFIState() error { return nil }

func (p *xdPlatformInterface) ReadWIFIState() adapter.WIFIState { return adapter.WIFIState{} }

func (p *xdPlatformInterface) SystemCertificates() []string { return nil }

func (p *xdPlatformInterface) UsePlatformConnectionOwnerFinder() bool { return false }

func (p *xdPlatformInterface) FindConnectionOwner(request *adapter.FindConnectionOwnerRequest) (*adapter.ConnectionOwner, error) {
	return nil, nil
}

func (p *xdPlatformInterface) UsePlatformWIFIMonitor() bool { return false }

func (p *xdPlatformInterface) UsePlatformNotification() bool { return false }

func (p *xdPlatformInterface) SendNotification(notification *adapter.Notification) error { return nil }

func (p *xdPlatformInterface) MyInterfaceAddress() []netip.Addr { return nil }

func (p *xdPlatformInterface) UsePlatformNeighborResolver() bool { return false }

func (p *xdPlatformInterface) StartNeighborMonitor(adapter.NeighborUpdateListener) error {
	return E.New("platform neighbor monitor is unavailable")
}

func (p *xdPlatformInterface) CloseNeighborMonitor(adapter.NeighborUpdateListener) error {
	return nil
}

func (p *xdPlatformInterface) UsePlatformShell() bool { return false }

func (p *xdPlatformInterface) CheckPlatformShell() error {
	return E.New("platform shell is unavailable")
}

func (p *xdPlatformInterface) OpenShellSession(
	*adapter.PlatformUser,
	string,
	[]string,
	string,
	int32,
	int32,
) (adapter.ShellSession, error) {
	return nil, E.New("platform shell is unavailable")
}

func (p *xdPlatformInterface) LookupUser(string) (*adapter.PlatformUser, error) {
	return nil, E.New("platform user lookup is unavailable")
}

func (p *xdPlatformInterface) LookupSFTPServer() (string, error) {
	return "", E.New("platform SFTP server is unavailable")
}

func (p *xdPlatformInterface) ReadSystemSSHHostKey() ([]byte, error) {
	return nil, E.New("platform SSH host key is unavailable")
}

func (p *xdPlatformInterface) TailscaleHostname() string { return "" }

func (p *xdPlatformInterface) UsePlatformBridge() bool { return false }

func (p *xdPlatformInterface) CreateBridge(adapter.BridgeOptions) (adapter.BridgeSession, error) {
	return nil, E.New("platform bridge is unavailable")
}

// platformInterfaceMonitor 把 Swift NWPathMonitor 报告的默认 Underlay 接口桥接给
// sing-box。它必须在 Start 时先刷新全部接口列表，再发布初始接口，否则
// auto_detect_interface 会看到 "no available network interface"。
type platformInterfaceMonitor struct {
	platform    *xdPlatformInterface
	logger      logger.Logger
	mu          sync.Mutex
	callbacks   list.List[tun.DefaultInterfaceUpdateCallback]
	myInterface string
}

var _ tun.DefaultInterfaceMonitor = (*platformInterfaceMonitor)(nil)

func (m *platformInterfaceMonitor) Start() error {
	m.platform.mu.Lock()
	networkManager := m.platform.networkManager
	defaultInterface := cloneInterface(m.platform.defaultInterface)
	kernelRouted := m.platform.kernelRoutedUnderlay
	m.platform.mu.Unlock()
	if networkManager != nil {
		if err := networkManager.UpdateInterfaces(); err != nil {
			return E.Cause(err, "update platform interfaces")
		}
	}
	if defaultInterface == nil {
		if kernelRouted {
			return nil
		}
		return E.New("platform: default interface not set")
	}
	m.notify(defaultInterface)
	return nil
}

func (m *platformInterfaceMonitor) Close() error { return nil }

func (m *platformInterfaceMonitor) DefaultInterface() *control.Interface {
	m.platform.mu.Lock()
	defer m.platform.mu.Unlock()
	return cloneInterface(m.platform.defaultInterface)
}

func (m *platformInterfaceMonitor) OverrideAndroidVPN() bool { return false }

func (m *platformInterfaceMonitor) AndroidVPNEnabled() bool { return false }

func (m *platformInterfaceMonitor) RegisterCallback(callback tun.DefaultInterfaceUpdateCallback) *list.Element[tun.DefaultInterfaceUpdateCallback] {
	m.mu.Lock()
	defer m.mu.Unlock()
	return m.callbacks.PushBack(callback)
}

func (m *platformInterfaceMonitor) UnregisterCallback(element *list.Element[tun.DefaultInterfaceUpdateCallback]) {
	m.mu.Lock()
	defer m.mu.Unlock()
	m.callbacks.Remove(element)
}

func (m *platformInterfaceMonitor) RegisterMyInterface(interfaceName string) {
	m.mu.Lock()
	m.myInterface = interfaceName
	m.mu.Unlock()
	m.platform.setOwnInterface(interfaceName)
}

func (m *platformInterfaceMonitor) MyInterfaces() []string {
	m.mu.Lock()
	defer m.mu.Unlock()
	if m.myInterface == "" {
		return nil
	}
	return []string{m.myInterface}
}

func (m *platformInterfaceMonitor) MyInterface() string {
	m.mu.Lock()
	defer m.mu.Unlock()
	return m.myInterface
}

func (m *platformInterfaceMonitor) notify(defaultInterface *control.Interface) {
	m.mu.Lock()
	callbacks := m.callbacks.Array()
	m.mu.Unlock()
	for _, callback := range callbacks {
		callback(defaultInterface, 0)
	}
}

func (p *xdPlatformInterface) setDefaultInterface(name string, index int) {
	p.mu.Lock()
	var updated *control.Interface
	if name != "" && index > 0 {
		if name == p.ownInterfaceName {
			updated = p.firstUsableInterfaceLocked()
		} else {
			resolved := resolvePlatformInterface(name, index)
			for _, snapshot := range p.networkInterfaces {
				if snapshot.Name == name && snapshot.Index == index {
					resolved = snapshot.Interface
					break
				}
			}
			updated = &resolved
		}
	}
	old := p.defaultInterface
	if old != nil && updated != nil && old.Equals(*updated) {
		p.mu.Unlock()
		return
	}
	p.defaultInterface = updated
	networkManager := p.networkManager
	monitor := p.monitor
	p.mu.Unlock()

	if networkManager != nil {
		if err := networkManager.UpdateInterfaces(); err != nil && monitor != nil && monitor.logger != nil {
			monitor.logger.Error(E.Cause(err, "update platform interfaces"))
		}
	}
	if monitor != nil {
		monitor.notify(cloneInterface(updated))
	}
}

func (p *xdPlatformInterface) setUnderlayInterfaceBinding(enabled bool) {
	p.mu.Lock()
	p.bindUnderlaySocket = enabled
	p.mu.Unlock()
}

// switchCandidate returns an isolated PlatformInterface for an unpublished
// Box generation. The source Box keeps its original NWPath snapshot until the
// switch commits; mutating one shared platform object during prepare would
// silently change the old generation's socket binding and DNS routing facts.
func (p *xdPlatformInterface) switchCandidate(
	interfacesJSON,
	defaultInterfaceName string,
	defaultInterfaceIndex int,
) (*xdPlatformInterface, error) {
	p.mu.Lock()
	kernelRouted := p.kernelRoutedUnderlay
	p.mu.Unlock()
	if !kernelRouted && (defaultInterfaceName == "" || defaultInterfaceIndex <= 0) {
		return nil, E.New("platform: default Underlay interface is unavailable")
	}
	var snapshots []platformNetworkInterfaceSnapshot
	if err := stdjson.Unmarshal([]byte(interfacesJSON), &snapshots); err != nil {
		return nil, E.Cause(err, "decode platform network interfaces")
	}
	if len(snapshots) == 0 {
		return nil, E.New("platform: Underlay interface snapshot is empty")
	}
	defaultFound := false
	for _, snapshot := range snapshots {
		if snapshot.Name == defaultInterfaceName &&
			snapshot.Index == defaultInterfaceIndex {
			defaultFound = true
			break
		}
	}
	if !defaultFound && !kernelRouted {
		return nil, E.New(
			"platform: default Underlay is absent from interface snapshot",
		)
	}

	p.mu.Lock()
	candidate := &xdPlatformInterface{
		tunFD:                p.tunFD,
		opener:               p.opener,
		ownInterfaceName:     p.ownInterfaceName,
		bindUnderlaySocket:   p.bindUnderlaySocket,
		kernelRoutedUnderlay: p.kernelRoutedUnderlay,
		socketProtector:      p.socketProtector,
		secureStateStore:     p.secureStateStore,
	}
	p.mu.Unlock()
	if err := candidate.setNetworkInterfaces(snapshots); err != nil {
		return nil, err
	}
	candidate.setDefaultInterface(
		defaultInterfaceName,
		defaultInterfaceIndex,
	)
	return candidate, nil
}

// lineRuntimeCapability returns a PlatformInterface snapshot owned by a
// process-level Line capability. It must not share networkManager or monitor
// ownership with the consumer Box that happened to create the capability:
// that Box is retired after a successful Switch while the capability may keep
// serving later generations.
func (p *xdPlatformInterface) lineRuntimeCapability() *xdPlatformInterface {
	p.mu.Lock()
	defer p.mu.Unlock()
	return &xdPlatformInterface{
		tunFD:                p.tunFD,
		opener:               p.opener,
		defaultInterface:     cloneInterface(p.defaultInterface),
		networkInterfaces:    cloneNetworkInterfaces(p.networkInterfaces),
		ownInterfaceName:     p.ownInterfaceName,
		bindUnderlaySocket:   p.bindUnderlaySocket,
		kernelRoutedUnderlay: p.kernelRoutedUnderlay,
		socketProtector:      p.socketProtector,
		secureStateStore:     p.secureStateStore,
	}
}

// syncLineRuntimeUnderlayFrom moves a shared process-level Line capability to
// the latest host NWPath snapshot before candidate readiness. The capability
// is shared by source and candidate, so this is a Line-level Underlay update,
// not a second endpoint or a mutation of either immutable consumer Box.
func (p *xdPlatformInterface) syncLineRuntimeUnderlayFrom(
	source *xdPlatformInterface,
	force bool,
) {
	if p == nil || source == nil || p == source {
		return
	}
	source.mu.Lock()
	updatedDefault := cloneInterface(source.defaultInterface)
	updatedInterfaces := cloneNetworkInterfaces(source.networkInterfaces)
	updatedOwnInterface := source.ownInterfaceName
	updatedBinding := source.bindUnderlaySocket
	source.mu.Unlock()

	p.mu.Lock()
	changed := !samePlatformDefaultInterface(
		p.defaultInterface,
		updatedDefault,
	) || !samePlatformNetworkInterfaces(
		p.networkInterfaces,
		updatedInterfaces,
	) || p.ownInterfaceName != updatedOwnInterface ||
		p.bindUnderlaySocket != updatedBinding
	if !changed && !force {
		p.mu.Unlock()
		return
	}
	p.defaultInterface = updatedDefault
	p.networkInterfaces = updatedInterfaces
	p.ownInterfaceName = updatedOwnInterface
	p.bindUnderlaySocket = updatedBinding
	p.lineRevision++
	networkManager := p.networkManager
	monitor := p.monitor
	p.mu.Unlock()

	if networkManager != nil {
		if err := networkManager.UpdateInterfaces(); err != nil &&
			monitor != nil && monitor.logger != nil {
			monitor.logger.Error(E.Cause(
				err,
				"update Line runtime platform interfaces",
			))
		}
	}
	if monitor != nil {
		monitor.notify(cloneInterface(updatedDefault))
	}
}

func (p *xdPlatformInterface) lineNetworkRevision() uint64 {
	p.mu.Lock()
	defer p.mu.Unlock()
	return p.lineRevision
}

// A host network epoch is observed once by the process-owned endpoint, even
// if several candidate generations are built for address-family convergence.
func (p *xdPlatformInterface) observeLineNetwork(source *xdPlatformInterface, epoch string) {
	p.mu.Lock()
	if p.lineEpoch == epoch {
		p.mu.Unlock()
		return
	}
	p.lineEpoch = epoch
	p.mu.Unlock()
	p.syncLineRuntimeUnderlayFrom(source, true)
}

func cloneNetworkInterfaces(
	interfaces []adapter.NetworkInterface,
) []adapter.NetworkInterface {
	cloned := make([]adapter.NetworkInterface, len(interfaces))
	for index, networkInterface := range interfaces {
		cloned[index] = networkInterface
		if clonedInterface := cloneInterface(&networkInterface.Interface); clonedInterface != nil {
			cloned[index].Interface = *clonedInterface
		}
		cloned[index].DNSServers = append(
			[]string(nil),
			networkInterface.DNSServers...,
		)
	}
	return cloned
}

func samePlatformDefaultInterface(left, right *control.Interface) bool {
	if left == nil || right == nil {
		return left == nil && right == nil
	}
	return left.Equals(*right)
}

func samePlatformNetworkInterfaces(
	left,
	right []adapter.NetworkInterface,
) bool {
	if len(left) != len(right) {
		return false
	}
	for index := range left {
		if !left[index].Interface.Equals(right[index].Interface) ||
			left[index].Type != right[index].Type ||
			left[index].Expensive != right[index].Expensive ||
			left[index].Constrained != right[index].Constrained {
			return false
		}
	}
	return true
}

type platformNetworkInterfaceSnapshot struct {
	Name  string                  `json:"name"`
	Index int                     `json:"index"`
	Type  string                  `json:"type"`
	Facts *platformInterfaceFacts `json:"facts,omitempty"`
}

// Android cannot query interface facts through Go's netlink path. The host
// may supply an atomic OS snapshot; omitted facts preserve Apple behavior.
type platformInterfaceFacts struct {
	MTU       int            `json:"mtu"`
	Flags     uint32         `json:"flags"`
	Addresses []netip.Prefix `json:"addresses"`
}

func (p *xdPlatformInterface) setNetworkInterfaces(snapshots []platformNetworkInterfaceSnapshot) error {
	seen := make(map[string]struct{}, len(snapshots))
	interfaces := make([]adapter.NetworkInterface, 0, len(snapshots))
	for _, snapshot := range snapshots {
		if snapshot.Name == "" || snapshot.Index <= 0 {
			return E.New("platform: invalid network interface snapshot")
		}
		if _, exists := seen[snapshot.Name]; exists {
			return E.New("platform: duplicate network interface: ", snapshot.Name)
		}
		seen[snapshot.Name] = struct{}{}
		interfaceType, loaded := C.StringToInterfaceType[snapshot.Type]
		if !loaded {
			return E.New("platform: unsupported network interface type: ", snapshot.Type)
		}
		resolved := resolvePlatformInterface(snapshot.Name, snapshot.Index)
		if snapshot.Facts != nil {
			if snapshot.Facts.MTU <= 0 {
				return E.New("platform: invalid interface MTU")
			}
			for _, address := range snapshot.Facts.Addresses {
				if !address.IsValid() {
					return E.New("platform: invalid interface address")
				}
			}
			resolved.MTU = snapshot.Facts.MTU
			resolved.Flags = net.Flags(snapshot.Facts.Flags)
			resolved.Addresses = append([]netip.Prefix(nil), snapshot.Facts.Addresses...)
		}
		interfaces = append(interfaces, adapter.NetworkInterface{
			Interface: resolved,
			Type:      interfaceType,
		})
	}

	p.mu.Lock()
	p.networkInterfaces = interfaces
	networkManager := p.networkManager
	monitor := p.monitor
	p.mu.Unlock()
	if networkManager != nil {
		if err := networkManager.UpdateInterfaces(); err != nil {
			return E.Cause(err, "update platform interfaces")
		}
	}
	if monitor != nil && monitor.logger != nil {
		monitor.logger.Debug("updated platform network interfaces: ", len(interfaces))
	}
	return nil
}

func (p *xdPlatformInterface) setOwnInterface(name string) {
	p.mu.Lock()
	if p.ownInterfaceName == name {
		p.mu.Unlock()
		return
	}
	p.ownInterfaceName = name
	if p.defaultInterface != nil && p.defaultInterface.Name == name {
		p.defaultInterface = p.firstUsableInterfaceLocked()
	}
	networkManager := p.networkManager
	monitor := p.monitor
	defaultInterface := cloneInterface(p.defaultInterface)
	p.mu.Unlock()

	if networkManager != nil {
		if err := networkManager.UpdateInterfaces(); err != nil && monitor != nil && monitor.logger != nil {
			monitor.logger.Error(E.Cause(err, "remove own interface from platform interfaces"))
		}
	}
	if monitor != nil {
		monitor.notify(defaultInterface)
	}
}

// resolvePlatformInterface 补齐 sing-box 与内置 Tailscale 需要的系统接口事实。
// NWPath 决定候选顺序和默认接口；这里不做选择，只按它给出的名称读取同一接口的
// MTU、状态标志和地址。接口若在快照后消失，保留原快照让后续启动明确失败。
func resolvePlatformInterface(name string, index int) control.Interface {
	fallback := control.Interface{Name: name, Index: index}
	systemInterface, err := net.InterfaceByName(name)
	if err != nil {
		return fallback
	}
	resolved, err := control.InterfaceFromNet(*systemInterface)
	if err != nil {
		return fallback
	}
	resolved.Name = name
	resolved.Index = index
	return resolved
}

// firstUsableInterfaceLocked 返回 NWPath 顺序中的第一个下层接口。
// 调用方必须持有 p.mu。只跳过当前 XDial 会话自己的接口，不按名字猜测产品或协议。
func (p *xdPlatformInterface) firstUsableInterfaceLocked() *control.Interface {
	for _, networkInterface := range p.networkInterfaces {
		if networkInterface.Name == p.ownInterfaceName {
			continue
		}
		return cloneInterface(&networkInterface.Interface)
	}
	return nil
}

func cloneInterface(value *control.Interface) *control.Interface {
	if value == nil {
		return nil
	}
	copy := *value
	return &copy
}

type platformDiagnostics struct {
	TunFD                 int
	TunName               string
	DefaultInterfaceName  string
	DefaultInterfaceIndex int
	TunInPackets          uint64
	TunInBytes            uint64
	TunOutPackets         uint64
	TunOutBytes           uint64
}

func (p *xdPlatformInterface) diagnostics() platformDiagnostics {
	p.mu.Lock()
	defaultInterface := cloneInterface(p.defaultInterface)
	monitor := p.monitor
	p.mu.Unlock()

	result := platformDiagnostics{
		TunFD:         p.tunFD,
		TunInPackets:  p.tunInPackets.Load(),
		TunInBytes:    p.tunInBytes.Load(),
		TunOutPackets: p.tunOutPackets.Load(),
		TunOutBytes:   p.tunOutBytes.Load(),
	}
	if defaultInterface != nil {
		result.DefaultInterfaceName = defaultInterface.Name
		result.DefaultInterfaceIndex = defaultInterface.Index
	}
	if monitor != nil {
		result.TunName = monitor.MyInterface()
	}
	return result
}
