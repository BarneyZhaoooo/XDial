//go:build !with_gvisor || mobile_no_tailscale

package libbox

import "fmt"

// TailscaleStatus 保留 gomobile API 形状；未包含 gVisor/Tailscale 的构建明确失败。
func (l *Libbox) TailscaleStatus(_ string) (string, error) {
	return "", fmt.Errorf("Tailscale is unavailable in this build")
}

func (l *Libbox) PreparedSwitchTailscaleStatus(_ string) (string, error) {
	return "", fmt.Errorf("Tailscale is unavailable in this build")
}

func (l *Libbox) TailscaleDNSCaptureDomains(_ string) (string, error) {
	return "", fmt.Errorf("Tailscale is unavailable in this build")
}

func (l *Libbox) PrepareTailscaleDNS(_, _ string) (string, error) {
	return "", fmt.Errorf("Tailscale is unavailable in this build")
}

func (l *Libbox) PreparePreparedSwitchTailscaleDNS(_, _ string) (string, error) {
	return "", fmt.Errorf("Tailscale is unavailable in this build")
}

func (l *Libbox) ProbeTailscalePeer(_, _ string, _ int) (string, error) {
	return "", fmt.Errorf("Tailscale is unavailable in this build")
}

func (l *Libbox) ProbePreparedSwitchTailscalePeer(_, _ string, _ int) (string, error) {
	return "", fmt.Errorf("Tailscale is unavailable in this build")
}

func (l *Libbox) ReselectTailscaleHomeDERP(_ string, _ int) (string, error) {
	return "", fmt.Errorf("Tailscale is unavailable in this build")
}

func (l *Libbox) ReleaseNonHomeDERP(_ string) (string, error) {
	return "", fmt.Errorf("Tailscale is unavailable in this build")
}

func (l *Libbox) ReleasePreparedSwitchNonHomeDERP(_ string) (string, error) {
	return "", fmt.Errorf("Tailscale is unavailable in this build")
}

func (l *Libbox) BeginTailscaleLogin(_ string) (string, error) {
	return "", fmt.Errorf("Tailscale is unavailable in this build")
}

func (l *Libbox) TailscaleLogout(_ string) error {
	return fmt.Errorf("Tailscale is unavailable in this build")
}

func (l *Libbox) preparedSwitchTailscaleDNSCaptureDomains(_ string) (string, error) {
	return "", fmt.Errorf("Tailscale is unavailable in this build")
}
