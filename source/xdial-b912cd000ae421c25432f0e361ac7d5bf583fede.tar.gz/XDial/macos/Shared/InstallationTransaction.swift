import Foundation

enum SystemExtensionBundleNaming {
    static func matches(
        bundleIdentifier: String,
        bundleURL: URL
    ) -> Bool {
        bundleURL.pathExtension == "systemextension"
            && bundleURL.deletingPathExtension().lastPathComponent
                == bundleIdentifier
    }
}

enum InstallationTransactionState: String, Codable, Equatable {
    case checking
    case installing
    case waitingForApproval = "waiting_for_approval"
    case ready
    case failed
}

enum InstallationTaskState: String, Codable, Equatable {
    case pending
    case running
    case waitingForApproval = "waiting_for_approval"
    case ready
    case failed
}

struct InstallationReportError: Codable, Equatable {
    let code: String
    let message: String
    let taskID: String

    enum CodingKeys: String, CodingKey {
        case code
        case message
        case taskID = "task_id"
    }
}

struct InstallationTaskReport: Codable, Equatable, Identifiable {
    let id: String
    let name: String
    let detail: String
    var state: InstallationTaskState
    var error: InstallationReportError?
}

struct InstallationReportEvent: Codable, Equatable {
    let sequence: Int
    let timestamp: Date
    let taskID: String
    let state: String
    let code: String
    let message: String

    enum CodingKeys: String, CodingKey {
        case sequence
        case timestamp
        case taskID = "task_id"
        case state
        case code
        case message
    }
}

struct InstallationReport: Codable, Equatable {
    static let schemaVersion = 4

    let schemaVersion: Int
    let transactionID: String
    var state: InstallationTransactionState
    var tasks: [InstallationTaskReport]
    var error: InstallationReportError?
    var events: [InstallationReportEvent]

    enum CodingKeys: String, CodingKey {
        case schemaVersion = "schema_version"
        case transactionID = "transaction_id"
        case state
        case tasks
        case error
        case events
    }

    static func fresh(
        applicationAlreadyInstalled: Bool
    ) -> InstallationReport {
        InstallationReport(
            schemaVersion: schemaVersion,
            transactionID: UUID().uuidString.lowercased(),
            state: .checking,
            tasks: [
                InstallationTaskReport(
                    id: "application",
                    name: "安装 XDial",
                    detail: "验证并运行 \(XDialBuildIdentity.applicationDestinationURL.path)",
                    state: applicationAlreadyInstalled ? .ready : .pending,
                    error: nil
                ),
                InstallationTaskReport(
                    id: "bundle",
                    name: "验证安装包",
                    detail: "核对签名、helper 和网络扩展",
                    state: .pending,
                    error: nil
                ),
                InstallationTaskReport(
                    id: "helper",
                    name: "配置后台服务",
                    detail: "注册并验证特权 helper",
                    state: .pending,
                    error: nil
                ),
                InstallationTaskReport(
                    id: "system-extension",
                    name: "启用网络扩展",
                    detail: "激活后复核当前版本与启用状态",
                    state: .pending,
                    error: nil
                ),
            ],
            error: nil,
            events: []
        )
    }

    var isReady: Bool {
        state == .ready && tasks.allSatisfy { $0.state == .ready }
    }

    var currentTask: InstallationTaskReport? {
        tasks.first {
            $0.state == .running || $0.state == .waitingForApproval
        }
    }

    /// Waiting for the user in System Settings changes nothing locally, so a quit
    /// need not wait for the installation to stop; the next launch resumes it.
    var allowsTermination: Bool {
        state == .waitingForApproval
    }

    mutating func updateTask(
        id: String,
        state: InstallationTaskState
    ) {
        guard let index = tasks.firstIndex(where: { $0.id == id }) else {
            return
        }
        guard tasks[index].state != state else { return }
        tasks[index].state = state
        if state != .failed {
            tasks[index].error = nil
        }
        switch state {
        case .waitingForApproval:
            self.state = .waitingForApproval
        case .running:
            self.state = .installing
        case .ready, .pending, .failed:
            break
        }
        appendEvent(
            taskID: id,
            state: state.rawValue,
            code: "",
            message: ""
        )
    }

    mutating func fail(
        code: String,
        message: String,
        taskID: String
    ) {
        let failure = InstallationReportError(
            code: code,
            message: message,
            taskID: taskID
        )
        error = failure
        state = .failed
        if let index = tasks.firstIndex(where: { $0.id == taskID }) {
            tasks[index].state = .failed
            tasks[index].error = failure
        }
        appendEvent(
            taskID: taskID,
            state: InstallationTaskState.failed.rawValue,
            code: code,
            message: message
        )
    }

    mutating func finish() {
        guard tasks.allSatisfy({ $0.state == .ready }) else {
            return
        }
        error = nil
        state = .ready
        appendEvent(
            taskID: "",
            state: InstallationTransactionState.ready.rawValue,
            code: "installation-ready",
            message: ""
        )
    }

    private mutating func appendEvent(
        taskID: String,
        state: String,
        code: String,
        message: String
    ) {
        events.append(
            InstallationReportEvent(
                sequence: events.count + 1,
                timestamp: Date(),
                taskID: taskID,
                state: state,
                code: code,
                message: message
            )
        )
    }
}

/// CFBundleVersion is the order macOS uses to replace an active System
/// Extension. Both release channels share one increasing sequence.
enum BundleBuildNumber {
    /// Orders two canonical positive decimals without overflowing; nil when
    /// either value is not one.
    static func compare(_ lhs: String, _ rhs: String) -> ComparisonResult? {
        guard isCanonical(lhs), isCanonical(rhs) else { return nil }
        if lhs.utf8.count != rhs.utf8.count {
            return lhs.utf8.count < rhs.utf8.count
                ? .orderedAscending : .orderedDescending
        }
        if lhs == rhs { return .orderedSame }
        return lhs < rhs ? .orderedAscending : .orderedDescending
    }

    static func isCanonical(_ value: String) -> Bool {
        guard let first = value.utf8.first, (49 ... 57).contains(first)
        else { return false }
        return value.utf8.allSatisfy { (48 ... 57).contains($0) }
    }

    static func read(at bundleURL: URL) -> String? {
        ApplicationBundleInfo.string(forKey: "CFBundleVersion", at: bundleURL)
    }

    /// An unreadable or non-canonical build is not evidence of a downgrade.
    static func lowers(_ source: String?, below destination: String?) -> Bool {
        guard let source, let destination else { return false }
        return compare(source, destination) == .orderedAscending
    }

    /// Whether installing the bundle at `sourceURL` over the one at
    /// `destinationURL` would put an older host beside a newer extension.
    static func installationLowersBuild(
        from sourceURL: URL,
        over destinationURL: URL
    ) -> Bool {
        lowers(read(at: sourceURL), below: read(at: destinationURL))
    }
}

enum ApplicationRelocationDecision: Equatable {
    case continueLaunch
    case install
    case replace
    case rejectExisting
    /// The installed bundle has a higher build, possibly a beta. Replacing it
    /// would leave its newer System Extension active beside an older host.
    case rejectDowngrade

    /// Reads both builds from the bundles themselves: the same values macOS
    /// compares before it replaces the active System Extension.
    static func decide(
        currentIsCanonical: Bool,
        sourceURL: URL,
        destinationURL: URL,
        destinationExists: Bool,
        destinationMatchesIdentity: Bool,
        destinationIsRecognizedProduct: Bool
    ) -> ApplicationRelocationDecision {
        decide(
            currentIsCanonical: currentIsCanonical,
            destinationExists: destinationExists,
            destinationMatchesIdentity: destinationMatchesIdentity,
            destinationIsRecognizedProduct: destinationIsRecognizedProduct,
            sourceBuild: BundleBuildNumber.read(at: sourceURL),
            destinationBuild: destinationExists
                ? BundleBuildNumber.read(at: destinationURL) : nil
        )
    }

    static func decide(
        currentIsCanonical: Bool,
        destinationExists: Bool,
        destinationMatchesIdentity: Bool,
        destinationIsRecognizedProduct: Bool = false,
        sourceBuild: String? = nil,
        destinationBuild: String? = nil
    ) -> ApplicationRelocationDecision {
        if currentIsCanonical {
            return .continueLaunch
        }
        guard destinationExists else {
            return .install
        }
        guard destinationMatchesIdentity
            || destinationIsRecognizedProduct else {
            return .rejectExisting
        }
        if BundleBuildNumber.lowers(sourceBuild, below: destinationBuild) {
            return .rejectDowngrade
        }
        return .replace
    }
}

enum SystemExtensionInstallationEvent: Equatable {
    case submitted
    case waitingForApproval
    case completed
    case failed(String)
}

enum InstallationBuildMarker {
    /// Replacement unregisters the outgoing helper before moving its bundle.
    /// A missing helper is therefore not evidence of a fresh installation.
    /// The user's request to install outlives the process: quitting while
    /// approval is pending, or an update replacing the app, unregisters nothing
    /// the user asked for, so a requested installation resumes on next launch.
    static let requestedInstallationKey = "xdial.installation.requested"

    static func shouldPrepareAtLaunch(
        serviceRegistered: Bool,
        registrationRecoveryPending: Bool,
        previousCompletedInstallation: String?,
        bundleIdentifier: String,
        requestedInstallation: String? = nil
    ) -> Bool {
        if serviceRegistered || registrationRecoveryPending { return true }
        if requestedInstallation == bundleIdentifier { return true }
        guard let marker = previousCompletedInstallation else { return false }
        let parts = marker.split(separator: ":", omittingEmptySubsequences: false)
        return parts.count == 3 && parts[0] == bundleIdentifier
            && !parts[1].isEmpty && parts[2].hasPrefix("installation-v")
    }

    static func make(
        bundleIdentifier: String,
        bundleVersion: String
    ) -> String {
        "\(bundleIdentifier):\(bundleVersion)"
            + ":installation-v\(InstallationReport.schemaVersion)"
    }
}

struct SystemExtensionPropertySnapshot: Equatable {
    let bundleIdentifier: String
    let bundleVersion: String
    let isEnabled: Bool
    let isAwaitingUserApproval: Bool
    let isUninstalling: Bool
}

enum SystemExtensionActivationVerifier {
    enum Phase {
        case installationPreflight
        case installationCompletion
        case connection
    }

    enum Action: Equatable {
        case ready
        case activate
        case unavailable
        /// A higher build of this extension stays active, typically a beta
        /// whose app was replaced by an older one. macOS does not replace it
        /// with a lower build, so only an uninstall can clear it.
        case newerActive(bundleVersion: String)
    }

    static func action(
        for properties: [SystemExtensionPropertySnapshot],
        expectedIdentifier: String,
        expectedVersion: String,
        phase: Phase
    ) -> Action {
        if containsReadyCurrentVersion(
            properties,
            expectedIdentifier: expectedIdentifier,
            expectedVersion: expectedVersion
        ) {
            return .ready
        }
        // Whatever installed the older host, activation cannot replace a
        // newer extension; say so instead of reporting a missing one.
        if let newer = newerVersion(
            properties,
            expectedIdentifier: expectedIdentifier,
            expectedVersion: expectedVersion
        ) {
            return .newerActive(bundleVersion: newer)
        }
        // Only installation may repair a missing/disabled/outdated extension.
        // A failed post-activation verification must not resubmit indefinitely.
        return phase == .installationPreflight ? .activate : .unavailable
    }

    /// The highest build of this extension above the bundled one that is not
    /// already being uninstalled.
    static func newerVersion(
        _ properties: [SystemExtensionPropertySnapshot],
        expectedIdentifier: String,
        expectedVersion: String
    ) -> String? {
        properties
            .filter {
                $0.bundleIdentifier == expectedIdentifier
                    && !$0.isUninstalling
                    && BundleBuildNumber.compare(
                        $0.bundleVersion,
                        expectedVersion
                    ) == .orderedDescending
            }
            .map(\.bundleVersion)
            .max {
                BundleBuildNumber.compare($0, $1) == .orderedAscending
            }
    }

    static func containsReadyCurrentVersion(
        _ properties: [SystemExtensionPropertySnapshot],
        expectedIdentifier: String,
        expectedVersion: String
    ) -> Bool {
        properties.contains {
            $0.bundleIdentifier == expectedIdentifier
                && $0.bundleVersion == expectedVersion
                && $0.isEnabled
                && !$0.isAwaitingUserApproval
                && !$0.isUninstalling
        }
    }
}

enum XDialApplicationIdentifierPolicy {
    // Migration-only identity from old local builds. It is accepted only as
    // the installed predecessor of the canonical app and can never be an
    // incoming replacement identity.
    static let legacyProbe =
        XDialBuildIdentity.legacyProbeApplicationIdentifier
    static let legacyRelease =
        XDialBuildIdentity.legacyApplicationIdentifier
    static let release = XDialBuildIdentity.formalApplicationIdentifier
    static let development =
        XDialBuildIdentity.developmentApplicationIdentifier
    static let legacyProbeSettingsUI =
        XDialBuildIdentity.legacyProbeSettingsUIIdentifier
    static let legacyReleaseSettingsUI =
        XDialBuildIdentity.legacySettingsUIIdentifier
    static let releaseSettingsUI =
        XDialBuildIdentity.formalSettingsUIIdentifier
    static let developmentSettingsUI =
        XDialBuildIdentity.developmentSettingsUIIdentifier

    static func settingsUIIdentifier(
        forApplicationIdentifier identifier: String
    ) -> String? {
        switch identifier {
        case legacyProbe: legacyProbeSettingsUI
        case legacyRelease: legacyReleaseSettingsUI
        case release: releaseSettingsUI
        case development: developmentSettingsUI
        default: nil
        }
    }

    static func permitsIncomingInstallation(identifier: String) -> Bool {
        identifier == XDialBuildIdentity.applicationIdentifier
    }

    static func permitsReplacement(
        existingIdentifier: String,
        incomingIdentifier: String,
        teamIdentifiersMatch: Bool
    ) -> Bool {
        guard teamIdentifiersMatch else { return false }
        guard incomingIdentifier == XDialBuildIdentity.applicationIdentifier
        else { return false }
        let replaceableExistingIdentifiers: Set<String>
        if XDialBuildIdentity.isDevelopment {
            replaceableExistingIdentifiers = [XDialBuildIdentity.applicationIdentifier]
        } else {
            replaceableExistingIdentifiers = [
                legacyProbe,
                legacyRelease,
                release,
            ]
        }
        return replaceableExistingIdentifiers.contains(existingIdentifier)
    }

    static func obsoleteIdentifiers(
        forInstalledIdentifier identifier: String
    ) -> Set<String> {
        guard XDialBuildIdentity.allowsFormalDataMigration,
              identifier == release else { return [] }
        return [legacyProbe, legacyRelease]
    }
}

enum OutgoingApplicationCleanup {
    static let timeout: TimeInterval = 5 * 60
    static let helperReplacementArgument = "--prepare-helper-for-replacement"
    static let replacementArgument =
        "--prepare-owned-components-for-replacement"

    struct Plan: Equatable {
        let executableURL: URL
        let arguments: [String]
        let timeout: TimeInterval
    }

    static func plan(
        existingBundleURL: URL,
        existingIdentifier: String,
        incomingIdentifier: String,
        teamIdentifiersMatch: Bool,
        requiresComponentCleanup: Bool = false
    ) -> Plan? {
        guard
            existingIdentifier != incomingIdentifier
                || requiresComponentCleanup,
            XDialApplicationIdentifierPolicy.permitsReplacement(
                existingIdentifier: existingIdentifier,
                incomingIdentifier: incomingIdentifier,
                teamIdentifiersMatch: teamIdentifiersMatch
            )
        else {
            return nil
        }
        return Plan(
            executableURL: existingBundleURL.appendingPathComponent(
                "Contents/MacOS/XDial"
            ),
            arguments: [replacementArgument],
            timeout: timeout
        )
    }

    static func run(
        _ plan: Plan,
        execute: (URL, [String], TimeInterval) throws -> Bool
    ) throws {
        guard try execute(
            plan.executableURL,
            plan.arguments,
            plan.timeout
        ) else {
            throw CleanupError.failed
        }
    }

    private enum CleanupError: LocalizedError {
        case failed

        var errorDescription: String? {
            "旧版 XDial 的后台服务或网络扩展未能完整清理，"
                + "正式版尚未替换，请重试"
        }
    }
}

enum ApplicationBundleReplacer {
    static func replace(
        fileManager: FileManager = .default,
        destinationURL: URL,
        newBundleURL: URL,
        backupName: String,
        retainBackupForRecovery: Bool = false,
        beforeRemovingBackup: (URL) throws -> Void = { _ in },
        validate: (URL) throws -> Bool
    ) throws {
        let backupURL = destinationURL
            .deletingLastPathComponent()
            .appendingPathComponent(
                backupName,
                isDirectory: true
            )
        _ = try fileManager.replaceItemAt(
            destinationURL,
            withItemAt: newBundleURL,
            backupItemName: backupName,
            options: [.withoutDeletingBackupItem]
        )
        guard fileManager.fileExists(atPath: backupURL.path) else {
            throw ApplicationBundleReplacementError.backupMissing
        }
        do {
            guard try validate(destinationURL) else {
                throw ApplicationBundleReplacementError
                    .validationFailed
            }
        } catch {
            do {
                guard fileManager.fileExists(atPath: backupURL.path)
                else {
                    throw ApplicationBundleReplacementError
                        .backupMissing
                }
                if fileManager.fileExists(
                    atPath: destinationURL.path
                ) {
                    try fileManager.removeItem(at: destinationURL)
                }
                try fileManager.moveItem(
                    at: backupURL,
                    to: destinationURL
                )
            } catch let rollbackError {
                throw ApplicationBundleReplacementError
                    .rollbackFailed(
                        original: error.localizedDescription,
                        rollback: rollbackError.localizedDescription
                    )
            }
            throw error
        }

        if !retainBackupForRecovery, fileManager.fileExists(atPath: backupURL.path) {
            try beforeRemovingBackup(backupURL)
            try fileManager.removeItem(at: backupURL)
        }
    }

    private enum ApplicationBundleReplacementError:
        LocalizedError {
        case validationFailed
        case backupMissing
        case rollbackFailed(original: String, rollback: String)

        var errorDescription: String? {
            switch self {
            case .validationFailed:
                "替换后的应用未通过验证"
            case .backupMissing:
                "替换失败后找不到旧版备份"
            case let .rollbackFailed(original, rollback):
                "应用替换失败（\(original)），恢复旧版也失败（\(rollback)）"
            }
        }
    }
}
